# اتاق صفر | ROOM 0

این پروژه یک پایه‌ی واقعی برای Mini App تلگرام به نام «اتاق صفر | ROOM 0» است. هدف، ساخت یک بازی استنتاجی چندنفره با میزهای رزرو، نقش‌های مخفی، بازی‌های زنده، تماشاچی‌ها، پنل مدیریت، و معماری قابل توسعه است.

## ساختار پروژه

- `backend/` — سرویس FastAPI، احراز هویت، موتور بازی، مدل‌های دیتابیس، و API
- `bot/` — ربات رسمی Telegram Bot API با polling تک‌نمونه‌ای و قفل Redis
- `frontend/` — رابط React + TypeScript + Vite + Tailwind
- `deploy/` — فایل‌های استقرار و تنظیمات VPS
- `scripts/` — اسکریپت‌های پشتیبان‌گیری و مدیریت
- `docs/` — مستندات و نقشه راه
- `docker-compose.yml` — اجرای هم‌زمان سرویس‌ها
- `.env.example` — نمونه تنظیمات محیطی
- `README.md` — راهنمای اصلی فارسی

## معماری کلی

- احراز هویت تنها در بک‌اند با اعتبارسنجی `initData` تلگرام انجام می‌شود.
- منطق بازی و قانون برد در سرور اجرا می‌شود.
- فرانت‌اند فقط نماینده‌ی وضعیت معتبر سرور است.
- داده‌های خصوصی نقش‌ها در API عمومی منتشر نمی‌شوند.
- WebSocket/رویدادهای لحظه‌ای برای وضعیت میز و بازی استفاده می‌شوند.
- بک‌اند دارای endpoint صدور LiveKit token است، اما اتصال صوتی هنوز در رابط Mini App پیاده نشده؛ UI این محدودیت را صریح نشان می‌دهد.

## فازهای اجرا

1. زیرساخت و احراز هویت
2. رابط کاربری و فهرست میزها
3. رزرو، تأیید حضور و انتظار
4. موتور بازی و قانون برد
5. رویدادهای زنده و بازیابی وضعیت
6. صدا و تماشاچی
7. پنل مدیریت
8. امنیت، تست‌ها و استقرار
9. تست یکپارچه و مستندات فارسی

## اجرای محلی (توسعه)

پیش‌نیاز: Python 3.12، Node 20، PostgreSQL 16 و Redis 7 (یا `docker compose up` برای استک توسعه؛ polling ربات را با `--profile telegram` فعال کنید).

```bash
cp .env.example .env            # برای توسعه، ENVIRONMENT=development و ENABLE_DEMO_MODE=true تنظیم کنید
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements-dev.txt
# برای polling ربات نیز یک محیط جدا بسازید و از bot/requirements.txt نصب کنید
cd backend && alembic upgrade head && uvicorn app.main:app --reload --port 8000
```

```bash
cd frontend && npm ci && npm run dev     # http://localhost:5173 ، پروکسی /api و /ws به localhost:8000
```

ربات با `/start` کاربر را شناسایی می‌کند و دکمهٔ HTTPS Mini App را می‌دهد؛ ورود بازی فقط با `initData` امضاشده داخل تلگرام انجام می‌شود. ربات در Compose یک سرویس polling جداست و قفل Redis مانع polling هم‌زمان چند نمونه می‌شود. در توسعه، Compose حالت demo را فعال می‌کند؛ در production خاموش و اجباری است. برای تست محلی، initData را با `make_init_data` در `backend/tests/conftest.py` بسازید و آن را در آدرس به‌صورت `#tgWebAppData=...` قرار دهید.

## استقرار روی VPS

راهنمای کامل فارسی، هم برای Docker و هم برای نصب مستقیم با systemd، شامل HTTPS، لاگ، به‌روزرسانی، پشتیبان‌گیری و مدیریت از گوشی: [`docs/deploy.md`](docs/deploy.md)

```bash
docker compose -f docker-compose.prod.yml up -d --build  # production: bot هم با همان فرمان بالا می‌آید
```

## تست‌ها

```bash
cd backend && pytest -q                                   # SQLite
TEST_DATABASE_URL=postgresql+psycopg://postgres:pass@localhost:5432/room0_test pytest -q   # PostgreSQL واقعی (جدول‌ها پاک و دوباره ساخته می‌شوند؛ فقط دیتابیس تست!)
cd ../frontend && npm run build

برای تست فرمان‌های ربات: `pip install -r bot/requirements-dev.txt && pytest bot/tests -q`.
```

## ساخت مدیر

یکی از این دو راه را انتخاب کنید: `ADMIN_IDS=<id>` را در `.env` بگذارید، یا این دستور را اجرا کنید: `python scripts/create_admin.py <telegram_id>`. نقش بقیه‌ی کاربران را مدیر کل از پنل مدیریت تعیین می‌کند.

## نقش‌های مدیریتی

| نقش | دسترسی |
|---|---|
| `analyst` و `support` | مشاهده‌ی آمار، کاربران، میزها، بازی‌ها، گزارش اقدامات و وضعیت سرویس |
| `moderator` | موارد بالا، به‌علاوه‌ی مسدودسازی و رفع مسدودی کاربر با ثبت دلیل و بستن میز در حال انتظار |
| `game_admin` | موارد بالا، به‌علاوه‌ی لغو بازی در جریان (بدون ثبت آمار) و شروع بازی روی هر میز |
| `super_admin` | همه‌ی دسترسی‌ها، به‌علاوه‌ی تغییر نقش کاربران |

همه‌ی مجوزها در سرور بررسی می‌شوند و هر اقدام مدیریتی در جدول `admin_actions` ثبت می‌شود.

## وضعیت پروژه

قوانین بازی در `docs/game_rules.md`، پروتکل زنده در `docs/realtime.md` و معماری در `docs/architecture.md` آمده است. هیچ توکن یا رمز واقعی در سورس قرار ندارد.
