# شروع سریع VPS (production)

1. دامنه را به IP سرور وصل کنید، پورت‌های TCP 80/443 را باز کنید و در BotFather یک Mini App با همان URL بسازید.
2. سورس را در VPS extract کنید و تنظیمات بسازید:

```bash
cp .env.example .env
chmod 600 .env
python3 -c 'import secrets; print(secrets.token_urlsafe(48))' # مقدار JWT_SECRET_KEY و BOT_API_SECRET را جداگانه بسازید
openssl rand -hex 32 # برای POSTGRES_PASSWORD
nano .env
```

3. در `.env` این مقادیر را با مقدار واقعی پر کنید: `DOMAIN`، `BOT_TOKEN`، `BOT_USERNAME`، `TELEGRAM_APP_URL`، `JWT_SECRET_KEY`، `BOT_API_SECRET`، `POSTGRES_PASSWORD`، `ADMIN_IDS` و `CORS_ORIGINS`/`TELEGRAM_ALLOWED_ORIGINS`. برای production حتماً `ENVIRONMENT=production`، `DEBUG=false` و `ENABLE_DEMO_MODE=false` بماند. آدرس Mini App باید HTTPS و origin آن در هر دو لیست مجاز باشد.
4. پیش‌نمایش تنظیمات و بالا آوردن stack:

```bash
docker compose -f docker-compose.prod.yml config
docker compose -f docker-compose.prod.yml up -d --build
docker compose -f docker-compose.prod.yml ps
curl -fsS https://YOUR_DOMAIN/api/v1/ready
```

5. در تلگرام به `@BOT_USERNAME` پیام `/start` بدهید. بررسی لاگ:

```bash
docker compose -f docker-compose.prod.yml logs --tail=100 backend bot
```

داده‌ها در volume نام‌دار PostgreSQL هستند؛ برای به‌روزرسانی `docker compose down -v` نزنید. دستورهای پشتیبان‌گیری و بازیابی در `docs/deploy.md` آمده‌اند.

## پیش از انتشار

```bash
cd backend && pip install -r requirements-dev.txt && pytest -q
cd ../bot && pip install -r requirements-dev.txt && pytest -q
cd ../frontend && npm ci && npm run build
```

تست PostgreSQL را فقط با `TEST_DATABASE_URL` روی دیتابیس تست خالی اجرا کنید؛ fixture تست تمام جدول‌های دیتابیس مقصد را حذف و دوباره می‌سازد.

## بررسی ربات و تست فرمان

```bash
docker compose -f docker-compose.prod.yml ps
docker compose -f docker-compose.prod.yml logs --tail=100 bot
```

سرویس bot وقتی healthy می‌شود که Bot API identity check، ثبت command/menu و شروع polling موفق شده باشند. خطای منو چند بار retry می‌شود؛ در صورت تداوم، container restart می‌شود. سپس در چت خصوصی با ربات `/start` بفرستید و دکمهٔ «ورود به ROOM 0» را لمس کنید. برای صحت Mini App، URL HTTPS در BotFather و `TELEGRAM_APP_URL` باید یکی باشند.

در خروجی `docker compose ps` وضعیت bot باید `healthy` شود؛ اگر healthy نشد، لاگ bot را ببینید. خطای تنظیم commands/menu در startup تا پنج بار retry می‌شود و بعد container restart خواهد شد. پس از healthy شدن، `/start` را در پیام خصوصی بفرستید.
