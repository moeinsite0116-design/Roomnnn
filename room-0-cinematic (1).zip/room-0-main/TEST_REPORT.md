# گزارش تست و محدودیت اعتبارسنجی

## کنترل‌هایی که واقعاً اجرا شدند

- `python -m compileall -q backend/app backend/alembic backend/tests bot`: موفق.
- فایل‌های `package.json` و `package-lock.json`: JSON قابل‌خواندن.
- دستورات SQL پاک‌سازی دادهٔ صف انتظار و تماشاچی در SQLite خام به‌صورت ایزوله smoke-test شدند.
- مرور ایستای سورس و اسکن برای placeholderهای امنیتی/secret انجام شد؛ هیچ توکن یا رمز واقعی داخل bundle نیست.

## اجرا نشدند

- تست‌های pytest بک‌اند و ربات: در محیط `pytest`، `SQLAlchemy` و FastAPI موجود نبودند؛ نصب پکیج/دسترسی اینترنت در sandbox در دسترس نبود.
- build فرانت‌اند: Node موجود بود اما `npm` و `node_modules` نبودند.
- parse/build Docker Compose و migration Alembic واقعی: Docker/وابستگی‌های لازم موجود نبودند.
- تست end-to-end تلگرام: به `BOT_TOKEN` واقعی و Bot API نیاز دارد؛ در ZIP هیچ token واقعی قرار ندارد.
- بررسی کامل آسیب‌پذیری وابستگی‌ها با `pip-audit`: اجرا نشد.

پس `compileall` به‌تنهایی به معنی اجرای کامل یا تایید production نیست. پیش از راه‌اندازی عمومی، بخش «تست‌های پیش از انتشار» در راهنمای VPS را اجرا کنید.

## تغییرات نسخهٔ پیگیری

- تست‌های جدیدی برای `configure_bot()`، retry موفق/ناموفق، بارگذاری env، HTTPS نامعتبر، `/start` و ساخت Web App button اضافه شدند.
- باگ `cfg` آزاد در `configure_bot()` با ورودی صریح `Config` رفع شد.
- اجرای واقعی این تست‌ها همچنان در این محیط ممکن نشد: `pytest` و پکیج‌های Telegram bot در sandbox موجود نبودند؛ بنابراین نتیجهٔ تست آن‌ها «اجرا نشده» است، نه PASS.

## اجرای این مرحله

- `python -m compileall -q backend/app backend/alembic backend/tests bot`: PASS.
- AST check: `configure_bot(application, cfg)` می‌گیرد و تنها call-site آن در retry با دو آرگومان است: PASS.
- `python -m pytest bot/tests/test_main.py -q`: اجرا نشد، `No module named pytest`.
- `python -m pytest backend/tests -q`: اجرا نشد، `No module named pytest`.
- `npm run build`: اجرا نشد، `npm: command not found`.
- Bot API واقعی، Compose و migration database: اجرا نشدند؛ ابزار شبکه/سرویس/توکن واقعی در محیط نداریم.
