#!/usr/bin/env bash
# PostgreSQL backup (gzip). Never modifies the database.
#   Docker:  BACKUP_MODE=docker ./scripts/backup.sh
#   Direct:  ./scripts/backup.sh            (uses DATABASE_URL from .env)
# Old backups beyond KEEP_DAYS (default 14) are removed from BACKUP_DIR only.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && set -a && . ./.env && set +a

DATE=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="${BACKUP_DIR:-./backups}"
KEEP_DAYS="${KEEP_DAYS:-14}"
OUT="$BACKUP_DIR/room0-$DATE.sql.gz"
mkdir -p "$BACKUP_DIR"
umask 077

if [ "${BACKUP_MODE:-direct}" = "docker" ]; then
  docker compose -f docker-compose.prod.yml exec -T postgres \
    pg_dump -U "${POSTGRES_USER:-postgres}" -d "${POSTGRES_DB:-room0}" --clean --if-exists | gzip > "$OUT"
else
  command -v pg_dump >/dev/null || { echo "pg_dump not found: sudo apt install postgresql-client"; exit 1; }
  URL="${DATABASE_URL:?DATABASE_URL is not set}"
  pg_dump "${URL/+psycopg/}" --clean --if-exists | gzip > "$OUT"
fi

[ -s "$OUT" ] || { echo "Backup failed (empty file)"; rm -f "$OUT"; exit 1; }
ln -sf "$(basename "$OUT")" "$BACKUP_DIR/latest.sql.gz"
find "$BACKUP_DIR" -name 'room0-*.sql.gz' -mtime +"$KEEP_DAYS" -delete
echo "Backup created: $OUT"
