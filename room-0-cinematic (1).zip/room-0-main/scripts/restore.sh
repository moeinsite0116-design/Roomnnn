#!/usr/bin/env bash
# Restore a backup made by backup.sh. A safety backup of the current database is taken first.
#   Docker:  BACKUP_MODE=docker ./scripts/restore.sh backups/room0-YYYYmmdd-HHMMSS.sql.gz
#   Direct:  ./scripts/restore.sh backups/latest.sql.gz
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && set -a && . ./.env && set +a

FILE="${1:?usage: restore.sh <backup.sql.gz>}"
[ -f "$FILE" ] || { echo "File not found: $FILE"; exit 1; }

if [ "${FORCE:-}" != "yes" ]; then
  read -r -p "This replaces the current database with $FILE. Type RESTORE to continue: " answer
  [ "$answer" = "RESTORE" ] || { echo "Cancelled."; exit 1; }
fi

echo "Taking a safety backup first..."
./scripts/backup.sh

reader="cat"; case "$FILE" in *.gz) reader="gunzip -c";; esac
if [ "${BACKUP_MODE:-direct}" = "docker" ]; then
  $reader "$FILE" | docker compose -f docker-compose.prod.yml exec -T postgres \
    psql -v ON_ERROR_STOP=1 -U "${POSTGRES_USER:-postgres}" -d "${POSTGRES_DB:-room0}"
else
  URL="${DATABASE_URL:?DATABASE_URL is not set}"
  $reader "$FILE" | psql -v ON_ERROR_STOP=1 "${URL/+psycopg/}"
fi
echo "Database restored from $FILE"
