"""Install a curated case file as a published case (idempotent by slug, never deletes data).

    python scripts/seed_case.py                       # bundled «آرشیو خاموش» case
    python scripts/seed_case.py path/to/case.json
Docker: docker compose -f docker-compose.prod.yml exec backend python /app/scripts/seed_case.py
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))

from app.db.session import async_session  # noqa: E402
from app.services.case_loader import DEFAULT_CASE, load_case_file  # noqa: E402


async def main(path: Path) -> None:
    async with async_session() as db:
        case = await load_case_file(db, path, published=True)
        await db.commit()
        print(f'case ready: id={case.id} slug={case.slug}')


if __name__ == '__main__':
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_CASE
    asyncio.run(main(target))
