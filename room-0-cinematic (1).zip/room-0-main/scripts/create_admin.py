"""Promote a Telegram user to super admin: python scripts/create_admin.py <telegram_id>

Run after `alembic upgrade head`. Alternative without a shell: ADMIN_IDS in .env.
Docker: docker compose -f docker-compose.prod.yml exec backend python /app/scripts/create_admin.py <id>
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))

from sqlalchemy import select  # noqa: E402

from app.db.models import User  # noqa: E402
from app.db.session import async_session  # noqa: E402


async def main(telegram_id: int) -> None:
    async with async_session() as db:
        user = (await db.execute(select(User).where(User.telegram_id == telegram_id))).scalar_one_or_none()
        if user is None:
            user = User(telegram_id=telegram_id)
            db.add(user)
        user.is_admin = True
        user.role = 'super_admin'
        await db.commit()
        print(f'User {telegram_id} is now admin')


if __name__ == '__main__':
    if len(sys.argv) != 2 or not sys.argv[1].isdigit():
        sys.exit('usage: python scripts/create_admin.py <telegram_id>')
    asyncio.run(main(int(sys.argv[1])))
