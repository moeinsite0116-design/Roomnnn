export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Vazirmatn Variable"', 'Vazirmatn', 'Tahoma', 'sans-serif'],
        display: ['Lalezar', '"Vazirmatn Variable"', 'sans-serif'],
        type: ['"Special Elite"', '"Vazirmatn Variable"', 'monospace'],
      },
      colors: {
        midnight: '#05060a',
        ink: '#0b0d14',
        panel: '#11131c',
        neon: '#5eead4',
        gold: '#e8c26a',
        blood: '#e11d48',
        danger: '#ef4444',
        paper: '#e9dfc7',
        navy: '#0a1428',
        signal: '#38bdf8',
        alarm: '#ff3b4e',
      },
      boxShadow: {
        glow: '0 0 30px rgba(94,234,212,0.25)',
        gold: '0 0 24px rgba(232,194,106,0.35)',
        blood: '0 0 24px rgba(225,29,72,0.45)',
        signal: '0 0 10px rgba(56,189,248,0.65)',
      },
      keyframes: {
        flicker: {
          '0%,19%,21%,23%,25%,54%,56%,100%': { opacity: '1', textShadow: '0 0 6px #5eead4, 0 0 18px #5eead4, 0 0 42px rgba(94,234,212,.6)' },
          '20%,24%,55%': { opacity: '.55', textShadow: 'none' },
        },
        rise: { from: { opacity: '0', transform: 'translateY(14px)' }, to: { opacity: '1', transform: 'none' } },
        stamp: {
          '0%': { opacity: '0', transform: 'scale(2.4) rotate(-14deg)' },
          '60%': { opacity: '1', transform: 'scale(.92) rotate(-14deg)' },
          '100%': { opacity: '1', transform: 'scale(1) rotate(-14deg)' },
        },
        sweep: { from: { transform: 'translateX(120%)' }, to: { transform: 'translateX(-120%)' } },
        shake: {
          '0%,100%': { transform: 'translateX(0)' },
          '20%,60%': { transform: 'translateX(-5px)' },
          '40%,80%': { transform: 'translateX(5px)' },
        },
        pulseRing: { '0%': { boxShadow: '0 0 0 0 rgba(225,29,72,.55)' }, '100%': { boxShadow: '0 0 0 14px rgba(225,29,72,0)' } },
        drift: { '0%,100%': { transform: 'translate(0,0)' }, '50%': { transform: 'translate(-3%,2%)' } },
      },
      animation: {
        flicker: 'flicker 4s infinite',
        rise: 'rise .5s cubic-bezier(.2,.8,.2,1) both',
        stamp: 'stamp .45s cubic-bezier(.2,.8,.2,1) both',
        sweep: 'sweep 3.5s linear infinite',
        shake: 'shake .4s ease-in-out',
        pulseRing: 'pulseRing 1.2s ease-out infinite',
        drift: 'drift 18s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
