import { useEffect, useRef, useState } from 'react';
import { getToken, GameEvent, parseUtc, Snapshot } from './api';

export type ConnState = 'connecting' | 'open' | 'reconnecting' | 'closed';

interface Result {
  state: ConnState;
  snapshot: Snapshot | null;
  events: GameEvent[];
  error: string;
  clockOffset: number; // serverNow - localNow (ms)
  resync: () => void;
}

const CLOSE_TEXT: Record<number, string> = {
  4401: 'نشست شما منقضی شده است؛ دوباره وارد شوید.',
  4403: 'دسترسی به این میز مجاز نیست.',
  4404: 'این میز وجود ندارد.',
  1008: 'پیام‌های زیادی ارسال شد؛ اتصال قطع شد.',
};

/** Live table state. Server snapshots are the only source of truth; reconnects resume from the last event id. */
export function useTableSocket(tableId: number | null, onAuthLost: () => void): Result {
  const [state, setState] = useState<ConnState>('connecting');
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [events, setEvents] = useState<GameEvent[]>([]);
  const [error, setError] = useState('');
  const [clockOffset, setClockOffset] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);
  const lastEventId = useRef(0);
  const authLost = useRef(onAuthLost);
  authLost.current = onAuthLost;

  useEffect(() => {
    if (tableId == null) return;
    let stopped = false;
    let attempt = 0;
    let pingTimer: number | undefined;
    let retryTimer: number | undefined;
    lastEventId.current = 0;
    setSnapshot(null);
    setEvents([]);
    setError('');

    const connect = () => {
      const token = getToken();
      if (!token) return;
      setState(attempt === 0 ? 'connecting' : 'reconnecting');
      const proto = location.protocol === 'https:' ? 'wss' : 'ws';
      const ws = new WebSocket(`${proto}://${location.host}/ws/table/${tableId}`);
      wsRef.current = ws;
      ws.onopen = () => {
        ws.send(JSON.stringify({ type: 'auth', token, after_event_id: lastEventId.current }));
      };
      ws.onmessage = (msg) => {
        let data: any;
        try {
          data = JSON.parse(msg.data);
        } catch {
          return;
        }
        if (data.server_time) setClockOffset(parseUtc(data.server_time) - Date.now());
        if (data.event === 'ready') {
          attempt = 0;
          setState('open');
          setError('');
          window.clearInterval(pingTimer);
          pingTimer = window.setInterval(() => ws.readyState === WebSocket.OPEN && ws.send('{"type":"ping"}'), 20000);
        } else if (data.event === 'snapshot') {
          const { event: _e, ...snap } = data;
          setSnapshot(snap as Snapshot);
          if (snap.game?.server_time) setClockOffset(parseUtc(snap.game.server_time) - Date.now());
          if (snap.game?.last_event_id && snap.game.last_event_id < lastEventId.current) lastEventId.current = 0;
        } else if (data.event === 'events') {
          const items: GameEvent[] = data.items ?? [];
          if (items.length) {
            lastEventId.current = Math.max(lastEventId.current, ...items.map((i) => i.id));
            setEvents((prev) => {
              const seen = new Set(prev.map((e) => e.id));
              return [...prev, ...items.filter((i) => !seen.has(i.id))].slice(-200);
            });
          }
        }
      };
      ws.onclose = (ev) => {
        window.clearInterval(pingTimer);
        if (stopped) return;
        if (ev.code === 4401) {
          setState('closed');
          setError(CLOSE_TEXT[4401]);
          authLost.current();
          return;
        }
        if (ev.code === 4403 || ev.code === 4404) {
          setState('closed');
          setError(CLOSE_TEXT[ev.code]);
          return;
        }
        if (CLOSE_TEXT[ev.code]) setError(CLOSE_TEXT[ev.code]);
        attempt += 1;
        setState('reconnecting');
        retryTimer = window.setTimeout(connect, Math.min(15000, 500 * 2 ** Math.min(attempt, 5)));
      };
    };

    const onVisible = () => {
      const ws = wsRef.current;
      if (document.visibilityState === 'visible' && ws?.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'resync', after_event_id: lastEventId.current }));
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    connect();
    return () => {
      stopped = true;
      document.removeEventListener('visibilitychange', onVisible);
      window.clearInterval(pingTimer);
      window.clearTimeout(retryTimer);
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [tableId]);

  const resync = () => {
    const ws = wsRef.current;
    if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'resync', after_event_id: lastEventId.current }));
  };

  return { state, snapshot, events, error, clockOffset, resync };
}
