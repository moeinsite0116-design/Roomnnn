/**
 * Cinematic effects layer: user preferences, device tier and a synthesized sound kit.
 * Every sound is generated with the Web Audio API (no audio files, no licensing questions) and only
 * starts after a user gesture, as browsers require. The game is fully playable with sound off.
 */
import { useEffect, useState } from 'react';

export type MotionPref = 'auto' | 'reduced' | 'full';
export interface Prefs { sound: boolean; ambient: boolean; motion: MotionPref }

const PREFS_KEY = 'room0_prefs';
const DEFAULT_PREFS: Prefs = { sound: true, ambient: false, motion: 'auto' };

export function loadPrefs(): Prefs {
  try {
    const raw = JSON.parse(localStorage.getItem(PREFS_KEY) || '{}');
    return {
      sound: typeof raw.sound === 'boolean' ? raw.sound : DEFAULT_PREFS.sound,
      ambient: typeof raw.ambient === 'boolean' ? raw.ambient : DEFAULT_PREFS.ambient,
      motion: raw.motion === 'reduced' || raw.motion === 'full' ? raw.motion : 'auto',
    };
  } catch {
    return { ...DEFAULT_PREFS };
  }
}

/** Weak phones get fewer particles and no blur-heavy layers. */
export function lowPowerDevice(): boolean {
  const nav = navigator as Navigator & { deviceMemory?: number };
  return (nav.hardwareConcurrency ?? 8) <= 4 || (nav.deviceMemory ?? 8) <= 2;
}

export function prefersReducedMotion(prefs: Prefs): boolean {
  if (prefs.motion === 'reduced') return true;
  if (prefs.motion === 'full') return false;
  return window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
}

export function applyPrefs(prefs: Prefs) {
  const root = document.documentElement;
  root.classList.toggle('rm', prefersReducedMotion(prefs));
  root.classList.toggle('lowfx', prefs.motion !== 'full' && lowPowerDevice());
  sfx.setEnabled(prefs.sound);
}

export function savePrefs(prefs: Prefs) {
  localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  applyPrefs(prefs);
  window.dispatchEvent(new CustomEvent('room0:prefs', { detail: prefs }));
}

export function usePrefs(): [Prefs, (next: Prefs) => void] {
  const [prefs, setPrefs] = useState<Prefs>(loadPrefs);
  useEffect(() => {
    const onChange = (e: Event) => setPrefs((e as CustomEvent<Prefs>).detail);
    window.addEventListener('room0:prefs', onChange);
    return () => window.removeEventListener('room0:prefs', onChange);
  }, []);
  return [prefs, savePrefs];
}

export const isReduced = () => document.documentElement.classList.contains('rm');
export const isLowFx = () => document.documentElement.classList.contains('lowfx');

// ------------------------------------------------------------------ sound kit
export type SfxName = 'open' | 'page' | 'stamp' | 'clue' | 'key' | 'critical' | 'alert' | 'tick';

class SoundKit {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private enabled = true;
  private ambientNodes: { stop: () => void } | null = null;
  private wantAmbient = false;

  setEnabled(on: boolean) {
    this.enabled = on;
    if (!on) this.stopAmbient();
    else if (this.wantAmbient) this.startAmbient();
  }

  /** Call from a user gesture. Safe to call repeatedly. */
  unlock() {
    if (!this.enabled) return;
    try {
      if (!this.ctx) {
        const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!Ctor) return;
        this.ctx = new Ctor();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.55;
        this.master.connect(this.ctx.destination);
        const len = this.ctx.sampleRate;
        this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const data = this.noise.getChannelData(0);
        for (let i = 0; i < len; i += 1) data[i] = Math.random() * 2 - 1;
      }
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      if (this.wantAmbient && !this.ambientNodes) this.startAmbient();
    } catch {
      this.ctx = null; // audio unavailable: silent game
    }
  }

  private ready(): AudioContext | null {
    if (!this.enabled || !this.ctx || !this.master || this.ctx.state !== 'running') return null;
    return this.ctx;
  }

  private tone(freq: number, start: number, dur: number, type: OscillatorType, peak: number, glideTo?: number) {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, start);
    if (glideTo) osc.frequency.exponentialRampToValueAtTime(glideTo, start + dur);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(peak, start + Math.min(0.03, dur / 4));
    gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    osc.connect(gain).connect(this.master!);
    osc.start(start);
    osc.stop(start + dur + 0.05);
  }

  private hiss(start: number, dur: number, freq: number, q: number, peak: number) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(freq, start);
    filter.Q.value = q;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(peak, start + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    src.connect(filter).connect(gain).connect(this.master!);
    src.start(start, Math.random() * 0.5);
    src.stop(start + dur + 0.05);
  }

  play(name: SfxName) {
    const ctx = this.ready();
    if (!ctx) return;
    const t = ctx.currentTime + 0.01;
    switch (name) {
      case 'page': this.hiss(t, 0.22, 2600, 0.8, 0.22); this.hiss(t + 0.05, 0.16, 5200, 1.2, 0.08); break;
      case 'stamp': this.tone(90, t, 0.25, 'sine', 0.5, 45); this.hiss(t, 0.08, 900, 0.6, 0.35); break;
      case 'open':
        this.tone(70, t, 0.6, 'sine', 0.45, 38);
        this.hiss(t + 0.08, 0.5, 1800, 0.6, 0.18);
        this.hiss(t + 0.3, 0.3, 3200, 1, 0.1);
        break;
      case 'clue': this.tone(659, t, 0.5, 'triangle', 0.16); this.tone(988, t + 0.12, 0.7, 'triangle', 0.12); break;
      case 'key':
        [523, 784, 1047].forEach((f, i) => this.tone(f, t + i * 0.11, 0.7, 'triangle', 0.14));
        break;
      case 'critical':
        this.tone(55, t, 1.3, 'sawtooth', 0.12, 41);
        this.tone(110, t, 1.1, 'sine', 0.22, 82);
        [880, 1319, 1760].forEach((f, i) => this.tone(f, t + 0.25 + i * 0.09, 0.9, 'sine', 0.06));
        break;
      case 'alert':
        [0, 0.22].forEach((d) => { this.tone(440, t + d, 0.12, 'square', 0.06); this.tone(330, t + d + 0.11, 0.12, 'square', 0.06); });
        break;
      case 'tick': this.tone(1800, t, 0.04, 'square', 0.03); break;
    }
  }

  ambient(on: boolean) {
    this.wantAmbient = on;
    if (on) this.startAmbient();
    else this.stopAmbient();
  }

  private startAmbient() {
    const ctx = this.ready();
    if (!ctx || this.ambientNodes) return;
    const out = ctx.createGain();
    out.gain.setValueAtTime(0.0001, ctx.currentTime);
    out.gain.exponentialRampToValueAtTime(0.05, ctx.currentTime + 3);
    out.connect(this.master!);
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 420;
    filter.connect(out);
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    lfo.frequency.value = 0.07;
    lfoGain.gain.value = 180;
    lfo.connect(lfoGain).connect(filter.frequency);
    const oscs = [55, 82.41, 110.6].map((f, i) => {
      const o = ctx.createOscillator();
      o.type = i === 2 ? 'triangle' : 'sine';
      o.frequency.value = f;
      o.detune.value = i * 7;
      o.connect(filter);
      o.start();
      return o;
    });
    const wind = ctx.createBufferSource();
    wind.buffer = this.noise;
    wind.loop = true;
    const windGain = ctx.createGain();
    windGain.gain.value = 0.25;
    wind.connect(windGain).connect(filter);
    wind.start();
    lfo.start();
    this.ambientNodes = {
      stop: () => {
        const now = ctx.currentTime;
        out.gain.cancelScheduledValues(now);
        out.gain.setValueAtTime(out.gain.value, now);
        out.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);
        window.setTimeout(() => { [...oscs, lfo, wind].forEach((n) => { try { n.stop(); } catch { /* stopped */ } }); out.disconnect(); }, 1400);
      },
    };
  }

  private stopAmbient() {
    this.ambientNodes?.stop();
    this.ambientNodes = null;
  }
}

export const sfx = new SoundKit();

/** Unlock audio on the first touch/click anywhere (browser autoplay rules). */
export function installAudioUnlock() {
  const unlock = () => sfx.unlock();
  window.addEventListener('pointerdown', unlock, { passive: true });
  window.addEventListener('keydown', unlock);
}

/** Per-game "already seen" memory so cinematics and discovery reveals survive refresh without replaying. */
export function seenStore(gameId: number, kind: string) {
  const key = `room0_${kind}_${gameId}`;
  return {
    has: () => localStorage.getItem(key) === '1',
    mark: () => localStorage.setItem(key, '1'),
  };
}

export function seenClues(gameId: number) {
  const key = `room0_clues_${gameId}`;
  const read = (): Set<number> => {
    try { return new Set((JSON.parse(localStorage.getItem(key) || '[]') as number[]).filter(Number.isInteger)); } catch { return new Set(); }
  };
  return {
    read,
    add: (ids: number[]) => {
      const all = read();
      ids.forEach((i) => all.add(i));
      localStorage.setItem(key, JSON.stringify([...all]));
    },
    initialized: () => localStorage.getItem(key) !== null,
  };
}
