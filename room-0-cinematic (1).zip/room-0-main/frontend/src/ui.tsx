import React, { useEffect, useState } from 'react';
import { parseUtc } from './api';

export function Card({ title, actions, children, className = '', kicker }: {
  title?: React.ReactNode; actions?: React.ReactNode; children: React.ReactNode; className?: string; kicker?: string;
}) {
  return (
    <section className={`dossier animate-rise ${className}`}>
      {title || actions ? (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          {title ? (
            <div>
              {kicker ? <div className="font-type text-[11px] uppercase tracking-[0.3em] text-amber-200/60">{kicker}</div> : null}
              <h2 className="title-display text-xl text-slate-50 sm:text-2xl">{title}</h2>
            </div>
          ) : <span />}
          {actions}
        </div>
      ) : null}
      {children}
    </section>
  );
}

type Variant = 'primary' | 'secondary' | 'danger' | 'success';
// literal class names so Tailwind keeps the component classes in the build
const VARIANT_CLASS: Record<Variant, string> = {
  primary: 'btn-primary', secondary: 'btn-secondary', danger: 'btn-danger', success: 'btn-success',
};

export function Button({ variant = 'primary', busy, className = '', children, ...props }:
  React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; busy?: boolean }) {
  return (
    <button {...props} disabled={props.disabled || busy} className={`btn ${VARIANT_CLASS[variant]} ${className}`}>
      {busy ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" aria-label="در حال انجام" /> : children}
    </button>
  );
}

export function Alert({ kind = 'info', children, onClose }: {
  kind?: 'info' | 'error' | 'success' | 'warn'; children: React.ReactNode; onClose?: () => void;
}) {
  const cls = {
    info: 'border-teal-400/40 bg-teal-400/10 text-teal-100',
    error: 'border-rose-500/50 bg-rose-600/15 text-rose-100 animate-shake',
    success: 'border-emerald-400/40 bg-emerald-500/10 text-emerald-100',
    warn: 'border-amber-400/50 bg-amber-400/10 text-amber-100',
  }[kind];
  const icon = { info: 'ℹ', error: '⚠', success: '✓', warn: '!' }[kind];
  return (
    <div role={kind === 'error' ? 'alert' : 'status'} className={`mb-4 flex items-start justify-between gap-3 rounded-xl border px-4 py-3 text-sm backdrop-blur animate-rise ${cls}`}>
      <div className="flex gap-2"><span className="font-bold">{icon}</span><div>{children}</div></div>
      {onClose ? <button aria-label="بستن" onClick={onClose} className="text-lg leading-none opacity-60 hover:opacity-100">×</button> : null}
    </div>
  );
}

export function Spinner({ label = 'در حال بارگذاری...' }: { label?: string }) {
  return (
    <div className="flex items-center gap-3 text-slate-400">
      <span className="relative flex h-5 w-5">
        <span className="absolute inset-0 animate-ping rounded-full bg-amber-300/30" />
        <span className="relative h-5 w-5 animate-spin rounded-full border-2 border-white/10 border-t-amber-300" />
      </span>
      <span className="font-type tracking-wide">{label}</span>
    </div>
  );
}

/** Circular timer driven by the server deadline (clock offset applied). */
export function Countdown({ deadline, offset, total = 60 }: { deadline: string | null; offset: number; total?: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(t);
  }, []);
  if (!deadline) return null;
  const leftMs = Math.max(0, parseUtc(deadline) - (now + offset));
  const left = Math.ceil(leftMs / 1000);
  const frac = Math.min(1, leftMs / (total * 1000));
  const urgent = left <= 10;
  const r = 26, c = 2 * Math.PI * r;
  return (
    <div className={`relative h-16 w-16 shrink-0 rounded-full ${urgent ? 'animate-pulseRing' : ''}`} aria-label={`${left} ثانیه باقی‌مانده`} role="timer">
      <svg viewBox="0 0 64 64" className="h-16 w-16 -rotate-90">
        <circle cx="32" cy="32" r={r} fill="rgba(0,0,0,.45)" stroke="rgba(255,255,255,.08)" strokeWidth="5" />
        <circle cx="32" cy="32" r={r} fill="none" stroke={urgent ? '#e11d48' : '#e8c26a'} strokeWidth="5" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - frac)} style={{ transition: 'stroke-dashoffset .25s linear, stroke .3s' }} />
      </svg>
      <span className={`absolute inset-0 flex items-center justify-center font-type text-lg tabular-nums ${urgent ? 'text-rose-300' : 'text-amber-100'}`}>{left}</span>
    </div>
  );
}

export function useAsyncAction() {
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<{ kind: 'error' | 'success'; text: string } | null>(null);
  const run = async (key: string, fn: () => Promise<unknown>, success?: string) => {
    setBusy(key);
    setMessage(null);
    try {
      await fn();
      haptic('success');
      if (success) setMessage({ kind: 'success', text: success });
      return true;
    } catch (e) {
      haptic('error');
      setMessage({ kind: 'error', text: e instanceof Error ? e.message : 'خطای ناشناخته' });
      return false;
    } finally {
      setBusy(null);
    }
  };
  return { busy, message, setMessage, run };
}

/** Telegram haptics when available; silently ignored in a normal browser. */
export function haptic(kind: 'success' | 'error' | 'warning' | 'light') {
  const h = (window as any).Telegram?.WebApp?.HapticFeedback;
  try {
    if (!h) return;
    if (kind === 'light') h.impactOccurred('light');
    else h.notificationOccurred(kind);
  } catch { /* unsupported client */ }
}

export function Avatar({ name, dim = false, size = 'h-9 w-9' }: { name: string; dim?: boolean; size?: string }) {
  let hash = 0;
  for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  const hue = hash % 360;
  return (
    <span className={`${size} inline-flex shrink-0 items-center justify-center rounded-full font-display text-base ${dim ? 'grayscale opacity-50' : ''}`}
      style={{ background: `radial-gradient(circle at 30% 30%, hsl(${hue} 70% 55%), hsl(${(hue + 40) % 360} 60% 22%))`, boxShadow: `0 0 0 2px rgba(0,0,0,.6), 0 0 14px hsl(${hue} 80% 50% / .35)` }}>
      {name.trim().charAt(0) || '؟'}
    </span>
  );
}
