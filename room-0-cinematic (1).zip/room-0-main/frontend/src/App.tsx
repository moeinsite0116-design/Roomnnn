import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api, displayName, getToken, Me, setToken, setUnauthorizedHandler, STAFF_ROLE_FA } from './api';
import { Alert, Avatar, Button, Card, Spinner } from './ui';
import Admin from './views/Admin';
import { SoundButton } from './views/FxSettings';
import { History, Profile } from './views/Profile';
import Room from './views/Room';
import Tables from './views/Tables';

declare global {
  interface Window {
    Telegram?: { WebApp?: { initData?: string; ready?: () => void; expand?: () => void; BackButton?: { show: () => void; hide: () => void; onClick: (fn: () => void) => void; offClick: (fn: () => void) => void } } };
  }
}

type View = 'tables' | 'profile' | 'history' | 'admin';
const ROOM_KEY = 'room0_room';

function App() {
  const [me, setMe] = useState<Me | null>(null);
  const [authState, setAuthState] = useState<'loading' | 'ok' | 'error'>('loading');
  const [authError, setAuthError] = useState('');
  const [view, setView] = useState<View>('tables');
  const [roomId, setRoomId] = useState<number | null>(() => Number(sessionStorage.getItem(ROOM_KEY)) || null);
  const [voice, setVoice] = useState<{ enabled: boolean; status: string; message: string } | null>(null);
  const initStarted = useRef(false);
  const botUsername = import.meta.env.VITE_TELEGRAM_BOT_USERNAME?.trim();

  const login = useCallback(async () => {
    setAuthState('loading');
    const initData = window.Telegram?.WebApp?.initData;
    if (!initData) {
      setAuthError('این برنامه را از داخل تلگرام (Mini App ربات ROOM 0) باز کنید.');
      setAuthState('error');
      return;
    }
    try {
      const data = await api<{ access_token: string; user: Me }>('/api/v1/auth/telegram', { method: 'POST', json: { init_data: initData } });
      setToken(data.access_token);
      setMe(data.user);
      setAuthError('');
      setAuthState('ok');
    } catch (e) {
      setAuthError(`ورود با تلگرام ناموفق بود: ${(e as Error).message} برنامه را از تلگرام دوباره باز کنید.`);
      setAuthState('error');
    }
  }, []);

  const authLost = useCallback(() => {
    setToken(null);
    setMe(null);
    login();
  }, [login]);

  const openRoom = (id: number | null) => {
    setRoomId(id);
    if (id) sessionStorage.setItem(ROOM_KEY, String(id));
    else sessionStorage.removeItem(ROOM_KEY);
  };

  useEffect(() => {
    // StrictMode runs effects twice in dev; two logins with the same initData would race.
    if (initStarted.current) return;
    initStarted.current = true;
    window.Telegram?.WebApp?.ready?.();
    window.Telegram?.WebApp?.expand?.();
    try {
      (window.Telegram?.WebApp as any)?.setHeaderColor?.('#05060a');
      (window.Telegram?.WebApp as any)?.setBackgroundColor?.('#05060a');
    } catch { /* older Telegram clients */ }
    setUnauthorizedHandler(authLost);
    fetch('/api/v1/livekit/status').then((r) => r.json()).then(setVoice).catch(() => setVoice(null));
    (async () => {
      if (getToken()) {
        try {
          setMe(await api<Me>('/api/v1/auth/me'));
          setAuthState('ok');
          return;
        } catch {
          setToken(null);
        }
      }
      await login();
    })();
  }, [login, authLost]);

  useEffect(() => {
    const back = window.Telegram?.WebApp?.BackButton;
    if (!back) return;
    const handleBack = () => openRoom(null);
    if (!roomId) { back.hide(); return; }
    back.show();
    back.onClick(handleBack);
    return () => back.offClick(handleBack);
  }, [roomId]);

  const logout = async () => {
    await api('/api/v1/auth/logout', { method: 'POST' }).catch(() => undefined);
    setToken(null);
    setMe(null);
    openRoom(null);
    setAuthState('error');
    setAuthError('از حساب خارج شدید. برای ورود دوباره، برنامه را از تلگرام باز کنید.');
  };

  const isStaff = me && me.role !== 'player';
  const nav: [View, string][] = [['tables', 'میزها'], ['profile', 'پروفایل'], ['history', 'تاریخچه'], ...(isStaff ? [['admin', 'مدیریت'] as [View, string]] : [])];

  return (
    <div className="relative min-h-[100dvh] text-slate-100" dir="rtl" style={{ paddingTop: 'calc(max(env(safe-area-inset-top), var(--tg-safe-area-inset-top, 0px)) + var(--tg-content-safe-area-inset-top, 0px))', paddingBottom: 'max(env(safe-area-inset-bottom), var(--tg-safe-area-inset-bottom, 0px))', paddingLeft: 'env(safe-area-inset-left)', paddingRight: 'env(safe-area-inset-right)' }}>
      <div className="scene" aria-hidden />
      <div className="scanlines" aria-hidden />
      <div className="relative z-10 mx-auto max-w-6xl px-3 pb-10 pt-4 sm:px-4 sm:pt-6">
        <header className="dossier mb-5 overflow-hidden">
          <div className="pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full bg-amber-300/10 blur-3xl" />
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Logo />
              <div>
                <p className="font-type text-[11px] uppercase tracking-[0.4em] text-teal-200/80 animate-flicker" dir="ltr">ROOM 0</p>
                <h1 className="title-display gold-text text-3xl leading-tight sm:text-4xl">اتاق صفر</h1>
                <p className="font-type text-[11px] text-slate-400">هیچ‌کس آن‌طور که به نظر می‌رسد نیست...</p>
              </div>
            </div>
            {me ? (
              <div className="flex items-center gap-2">
              <SoundButton />
              <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm">
                <Avatar name={displayName(me)} />
                <div>
                  <div className="font-semibold">{displayName(me)}</div>
                  <div className="text-xs text-slate-400">{STAFF_ROLE_FA[me.role] ?? me.role} • <button onClick={logout} className="text-rose-300 hover:underline">خروج</button></div>
                </div>
              </div>
              </div>
            ) : null}
          </div>
          {me ? (
            <nav className="mt-4 flex gap-1 overflow-x-auto rounded-xl border border-white/10 bg-black/30 p-1" aria-label="بخش‌ها">
              {nav.map(([k, label]) => {
                const active = view === k && !roomId;
                return (
                  <button key={k} onClick={() => { setView(k); openRoom(null); }}
                    className={`relative flex-1 whitespace-nowrap rounded-lg px-3 py-2 text-sm font-semibold transition ${active ? 'bg-gradient-to-b from-amber-300 to-amber-600 text-black shadow-gold' : 'text-slate-300 hover:bg-white/5'}`}>
                    {label}
                  </button>
                );
              })}
            </nav>
          ) : null}
        </header>

        {authState === 'loading' ? <Card><Spinner label="در حال ورود با تلگرام..." /></Card> : null}
        {authState === 'error' ? (
          <div className="space-y-3">
            <Alert kind="error">{authError} {window.Telegram?.WebApp?.initData ? <button className="underline" onClick={login}>تلاش دوباره</button> : null}</Alert>
            {!window.Telegram?.WebApp?.initData && botUsername ? (
              <a className="inline-flex min-h-11 items-center rounded-xl border border-amber-300/40 bg-amber-300/10 px-4 text-sm text-amber-100 hover:bg-amber-300/20" href={`https://t.me/${encodeURIComponent(botUsername)}?startapp`} target="_blank" rel="noreferrer">
                بازگشت به ربات ROOM 0 در تلگرام
              </a>
            ) : null}
          </div>
        ) : null}

        {me && authState === 'ok' ? (
          roomId ? <Room tableId={roomId} me={me} onBack={() => openRoom(null)} onAuthLost={authLost} /> :
          view === 'tables' ? (
            <div className="space-y-6">
              <Tables onOpen={openRoom} />
              {voice ? (
                <Card title="صدای زنده" kicker="VOICE CHANNEL">
                  <div className={`rounded-xl border px-4 py-3 text-sm ${voice.enabled ? 'border-teal-400/40 bg-teal-400/10 text-teal-100' : 'border-amber-400/40 bg-amber-400/10 text-amber-100'}`}>
                    {voice.enabled ? 'زیرساخت LiveKit تنظیم شده، اما اتصال صوتی هنوز از رابط بازی قابل استفاده نیست.' : 'گفت‌وگوی صوتی روی این سرور فعال نشده است.'}
                  </div>
                </Card>
              ) : null}
            </div>
          ) :
          view === 'profile' ? <Profile me={me} onUpdated={setMe} /> :
          view === 'history' ? <History /> :
          isStaff ? <Admin me={me} /> : null
        ) : null}
      </div>
    </div>
  );
}

function Logo() {
  return (
    <svg viewBox="0 0 64 64" className="h-14 w-14 drop-shadow-[0_0_14px_rgba(232,194,106,.45)]" aria-hidden>
      <defs>
        <linearGradient id="lg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#fff3c9" /><stop offset="1" stopColor="#9c7424" /></linearGradient>
      </defs>
      <rect x="3" y="3" width="58" height="58" rx="14" fill="#0b0d14" stroke="rgba(232,194,106,.35)" />
      <circle cx="30" cy="30" r="14" fill="none" stroke="url(#lg)" strokeWidth="5" />
      <path d="M40 40 52 52" stroke="url(#lg)" strokeWidth="6" strokeLinecap="round" />
      <path d="M22 38 38 22" stroke="#e11d48" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  );
}

export default App;
