export const TOKEN_KEY = 'room0_token';

export interface Me {
  id: number;
  telegram_id: number;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  display_name: string | null;
  role: string;
  games_played: number;
  games_won: number;
  created_at: string | null;
}

export interface TableItem {
  id: number;
  name: string;
  status: string;
  max_players: number;
  spectator_capacity: number;
  host_user_id: number | null;
  start_time: string | null;
  available_seats: number;
  spectators: number;
  game_id: number | null;
  my_reservation?: { seat_index: number; status: string } | null;
  is_spectating?: boolean;
  settings?: { interrogation_questions: number; interrogation_seconds: number; answer_seconds: number; vote_seconds: number };
}

export interface GamePlayer {
  user_id: number;
  name: string;
  is_alive: boolean;
  role: string | null;
  connected?: boolean;
}

export interface GameState {
  id: number;
  table_id: number;
  status: 'started' | 'finished' | 'aborted';
  phase: string;
  round_no: number;
  total_rounds: number;
  phase_deadline: string | null;
  server_time: string;
  winner: string | null;
  question: { id: number; prompt: string } | null;
  players: GamePlayer[];
  me: { is_player: boolean; role?: string; team?: string; is_alive?: boolean; teammates?: number[] };
  progress: { answered: number; voted: number; alive: number };
  my_answer: string | null;
  my_vote: number | null;
  answers: { user_id: number; text: string }[];
  last_event_id?: number;
  stage?: 'interrogation' | 'briefing' | 'investigation' | 'finished';
  case?: CaseFile | null;
  settings?: GameSettings;
  clues?: ClueBrief[];
  interrogation?: InterrogationBlock | null;
  dossier?: DossierSuspect[];
  briefing?: { ready: number; alive: number; me_ready: boolean } | null;
}

export interface GameSettings {
  interrogation_seconds: number; answer_seconds: number; vote_seconds: number; briefing_seconds: number; interrogation_total: number;
}

export interface CaseFile {
  code: string | null; title: string; summary?: string | null; objective?: string | null; briefing?: { label: string; value: string }[];
}

export type ClueKind = 'document' | 'photo' | 'note' | 'report' | 'testimony' | 'record' | string;
export type Importance = 'normal' | 'key' | 'critical' | string;

export interface ClueBrief {
  id: number; title: string; text: string; kind: ClueKind; importance: Importance; round: number;
  discovered_at: string | null; team_only: boolean;
}

export interface InterrogationQuestion {
  id: number; prompt: string; kind: 'text' | 'choice' | 'evidence'; follow_up: boolean;
  options: { key: string; label: string }[]; evidence: { id: number; title: string; kind: ClueKind }[];
}

export interface InterrogationBlock {
  step: number; total: number; answered: number; alive: number; question: InterrogationQuestion | null;
  my_answer: { display: string | null; skipped: boolean } | null;
  history: { step: number; prompt: string; answer: string | null; skipped: boolean }[];
}

export interface DossierSuspect {
  user_id: number; name: string;
  entries: { step: number; prompt: string; answer: string | null; skipped: boolean; response_ms: number | null; follow_up: boolean;
    contradiction: { clue_id: number; title: string } | null }[];
}

export interface BoardClue extends ClueBrief {
  entities: { type: string; label: string }[]; media_url: string | null;
  note?: { flagged: boolean; status: 'new' | 'reviewing' | 'checked'; text: string; updated_at: string | null };
}

export interface BoardLink { id: number; from: number; to: number; label: string | null; contradiction: boolean }
export interface Hypothesis {
  id: number; text: string; clue_ids: number[]; suspect_user_id: number | null; created_at: string | null;
  check: { cited: number; contradictions: number[][]; verdict: 'consistent' | 'conflict' | 'unsupported' };
}
export interface Board {
  game_id: number; readonly: boolean; clues: BoardClue[]; relations: { from: number; to: number; type: string; label: string }[];
  links: BoardLink[]; hypotheses: Hypothesis[]; progress: number;
  summary: { discovered: number; checked: number; flagged: number; links: number; contradictions: number; hypotheses: number } | null;
}

export interface Seat {
  seat_index: number;
  user_id: number;
  status: string;
  connected: boolean;
  name: string;
}

export interface Snapshot {
  table: TableItem;
  seats: Seat[];
  online: number[];
  game: GameState | null;
}

export interface GameEvent {
  id: number;
  type: string;
  payload: Record<string, unknown>;
  at: string;
}

const MESSAGES: Record<string, string> = {
  'A game is already running at this table': 'یک بازی روی این میز در جریان است.',
  'Account is banned': 'حساب شما مسدود شده است.',
  'Answers are not being accepted now': 'الان زمان ثبت پاسخ نیست.',
  'Cannot leave a table while a game is running': 'در حین بازی نمی‌توانید میز را ترک کنید.',
  'Concurrent login, retry': 'ورود هم‌زمان؛ دوباره تلاش کنید.',
  'Eliminated players cannot act': 'بازیکن حذف‌شده نمی‌تواند اقدام کند.',
  'Game not found': 'بازی پیدا نشد.',
  'Insufficient permissions': 'مجوز کافی ندارید.',
  'Leave spectating before taking a seat': 'ابتدا از حالت تماشا خارج شوید.',
  'No published case with questions is available': 'هیچ پرونده‌ی منتشرشده‌ای با سؤال وجود ندارد.',
  'Not authenticated': 'نشست شما معتبر نیست؛ دوباره وارد شوید.',
  'Only the table host can start the game': 'فقط میزبان می‌تواند بازی را شروع کند.',
  'Reservation expired': 'مهلت رزرو تمام شد؛ دوباره رزرو کنید.',
  'Reservation not found': 'رزروی برای شما پیدا نشد.',
  'Seat is not available': 'این صندلی آزاد نیست.',
  'Seat taken or you already hold a reservation': 'صندلی گرفته شده یا شما رزرو فعال دیگری دارید.',
  'Seated players cannot spectate their own table': 'بازیکن نشسته نمی‌تواند تماشاچی همان میز باشد.',
  'Spectator capacity reached': 'ظرفیت تماشاچی پر است.',
  'Table is closed': 'این میز بسته شده است.',
  'Table is full': 'میز پر است.',
  'Table is not open for reservations': 'میز برای رزرو باز نیست.',
  'Table is not waiting for a game': 'میز آماده‌ی شروع نیست.',
  'Table not found': 'میز پیدا نشد.',
  'Target is not an alive player': 'این بازیکن زنده نیست.',
  'Too many open tables': 'تعداد میزهای باز شما به سقف رسیده است.',
  'Voting is not open now': 'الان زمان رأی‌گیری نیست.',
  'You already answered this round': 'در این دور قبلاً پاسخ داده‌اید.',
  'You already hold a seat at this table': 'شما روی این میز صندلی دارید.',
  'You already voted this round': 'در این دور قبلاً رأی داده‌اید.',
  'You are already on the waitlist': 'شما در صف انتظار هستید.',
  'You are not a player in this game': 'شما بازیکن این بازی نیستید.',
  'You cannot vote for yourself': 'نمی‌توانید به خودتان رأی دهید.',
  'You cannot ban yourself': 'نمی‌توانید خودتان را مسدود کنید.',
  'Rate limit exceeded': 'درخواست‌ها زیاد است؛ کمی صبر کنید.',
  'Invalid request': 'ورودی نامعتبر است.',
  'Internal server error': 'خطای داخلی سرور؛ دوباره تلاش کنید.',
  'The interrogation stage is over': 'مرحلهٔ بازجویی تمام شده است.',
  'This question is no longer active': 'این سؤال دیگر فعال نیست؛ صفحه به‌روز شد.',
  'You already answered this step': 'به این سؤال قبلاً پاسخ داده‌اید.',
  'Choose one of the listed answers': 'یکی از گزینه‌ها را انتخاب کنید.',
  'Choose a discovered public clue': 'یک مدرک کشف‌شده را انتخاب کنید.',
  'Answer text is required': 'متن پاسخ را بنویسید.',
  'The case is closed': 'این پرونده بسته شده است.',
  'Clue not found': 'این سرنخ برای شما در دسترس نیست.',
  'Invalid review status': 'وضعیت بررسی نامعتبر است.',
  'A clue cannot be linked to itself': 'یک سرنخ را نمی‌توان به خودش وصل کرد.',
  'Too many links on your board': 'تخته‌ی شما پر از اتصال است.',
  'Link not found': 'این اتصال پیدا نشد.',
  'Too many hypotheses': 'تعداد فرضیه‌ها به سقف رسیده است.',
  'Suspect is not a player in this game': 'مظنون انتخاب‌شده بازیکن این بازی نیست.',
  'Concurrent update, retry': 'هم‌زمان تغییر کرد؛ دوباره تلاش کنید.',
};

export function translate(detail: string): string {
  if (MESSAGES[detail]) return MESSAGES[detail];
  const m = detail.match(/^Exactly (\d+) confirmed players are required \(have (\d+)\)$/);
  if (m) return `برای شروع دقیقاً ${m[1]} بازیکن تأییدشده لازم است (اکنون ${m[2]}).`;
  return detail;
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

let token: string | null = sessionStorage.getItem(TOKEN_KEY);
let onUnauthorized: (() => void) | null = null;

export const getToken = () => token;
export function setToken(value: string | null) {
  token = value;
  if (value) sessionStorage.setItem(TOKEN_KEY, value);
  else sessionStorage.removeItem(TOKEN_KEY);
}
export function setUnauthorizedHandler(fn: (() => void) | null) {
  onUnauthorized = fn;
}

export async function api<T = unknown>(path: string, init: RequestInit & { json?: unknown } = {}): Promise<T> {
  const { json, ...rest } = init;
  let res: Response;
  try {
    res = await fetch(path, {
      ...rest,
      body: json !== undefined ? JSON.stringify(json) : rest.body,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(rest.headers ?? {}),
      },
    });
  } catch {
    throw new ApiError(0, 'اتصال به سرور برقرار نشد؛ اینترنت را بررسی کنید.');
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && token && onUnauthorized) onUnauthorized();
    const detail = typeof body?.detail === 'string' ? body.detail : 'Internal server error';
    throw new ApiError(res.status, translate(detail));
  }
  return body as T;
}

export const ROLE_FA: Record<string, string> = {
  detective: 'کارآگاه',
  spy: 'جاسوس',
  independent: 'مستقل',
};

export const WINNER_FA: Record<string, string> = {
  detectives: 'کارآگاه‌ها',
  spies: 'جاسوس‌ها',
  independent: 'مستقل',
  draw: 'مساوی',
};

export const CLUE_KIND_FA: Record<string, string> = {
  document: 'سند', photo: 'عکس', note: 'یادداشت', report: 'گزارش', testimony: 'شهادت', record: 'سابقه',
};

export const ENTITY_FA: Record<string, string> = { person: 'شخص', place: 'مکان', time: 'زمان', object: 'شیء' };

export const STATUS_FA: Record<string, string> = {
  waiting: 'در انتظار بازیکن',
  playing: 'در حال بازی',
  closed: 'بسته',
  pending: 'در انتظار تأیید',
  confirmed: 'آماده',
  started: 'در جریان',
  finished: 'پایان‌یافته',
  aborted: 'لغوشده',
};

export const STAFF_ROLE_FA: Record<string, string> = {
  player: 'بازیکن',
  analyst: 'تحلیلگر (فقط خواندن)',
  support: 'پشتیبان',
  moderator: 'ناظر',
  game_admin: 'مدیر بازی',
  super_admin: 'مدیر کل',
};

export const displayName = (u: Pick<Me, 'display_name' | 'first_name' | 'username' | 'id'>) =>
  u.display_name || u.first_name || u.username || `بازیکن ${u.id}`;

/** Backend timestamps are naive UTC ISO strings. */
export const parseUtc = (s: string) => Date.parse(/[zZ]|[+-]\d\d:\d\d$/.test(s) ? s : s + 'Z');
