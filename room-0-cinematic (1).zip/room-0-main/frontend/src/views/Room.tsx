import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { api, ClueBrief, GameEvent, GameState, Me, ROLE_FA, Snapshot, STATUS_FA, WINNER_FA } from '../api';
import { seenClues, seenStore, sfx, usePrefs } from '../fx';
import { Alert, Avatar, Button, Card, Countdown, haptic, Spinner, useAsyncAction } from '../ui';
import { ConnState, useTableSocket } from '../useTableSocket';
import Board from './game/Board';
import CaseOpening from './game/CaseOpening';
import Discovery from './game/Discovery';
import Dossier from './game/Dossier';
import Interrogation from './game/Interrogation';

const CONN_FA: Record<ConnState, [string, string]> = {
  connecting: ['در حال اتصال...', 'bg-amber-300 animate-pulse'],
  open: ['خط امن برقرار است', 'bg-teal-300 shadow-glow'],
  reconnecting: ['قطع شد؛ اتصال مجدد...', 'bg-orange-400 animate-pulse'],
  closed: ['قطع', 'bg-rose-500'],
};

const ROLE_STYLE: Record<string, { color: string; glow: string; motto: string; icon: React.ReactNode }> = {
  detective: {
    color: 'text-teal-200', glow: 'shadow-glow border-teal-300/50', motto: 'جاسوس‌ها را پیدا و با رأی بیرون کنید.',
    icon: <path d="M26 26m-12 0a12 12 0 1 0 24 0a12 12 0 1 0-24 0M35 35l11 11" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />,
  },
  spy: {
    color: 'text-rose-200', glow: 'shadow-blood border-rose-400/60', motto: 'پنهان بمانید تا تعدادتان با بقیه برابر شود.',
    icon: <><path d="M8 28c6-10 30-10 36 0" fill="none" stroke="currentColor" strokeWidth="4" /><circle cx="18" cy="34" r="6" fill="currentColor" /><circle cx="34" cy="34" r="6" fill="currentColor" /><path d="M24 34h4" stroke="currentColor" strokeWidth="3" /></>,
  },
  independent: {
    color: 'text-amber-100', glow: 'shadow-gold border-amber-300/60', motto: 'به هیچ‌کس تعلق ندارید؛ زنده بمانید.',
    icon: <><circle cx="26" cy="26" r="16" fill="none" stroke="currentColor" strokeWidth="4" /><path d="M26 14v24M14 26h24" stroke="currentColor" strokeWidth="3" /></>,
  },
};

export default function Room({ tableId, me, onBack, onAuthLost }: {
  tableId: number; me: Me; onBack: () => void; onAuthLost: () => void;
}) {
  const { state, snapshot, events, error, clockOffset } = useTableSocket(tableId, onAuthLost);
  const { busy, message, setMessage, run } = useAsyncAction();
  const [showResult, setShowResult] = useState(true);

  const [label, dot] = CONN_FA[state];
  const post = (key: string, path: string, json?: unknown, success?: string) =>
    run(key, () => api(path, { method: 'POST', json }), success);
  const [prefs] = usePrefs();
  const running = snapshot?.game?.status === 'started';
  useEffect(() => {
    sfx.ambient(prefs.ambient && running);
    return () => sfx.ambient(false);
  }, [prefs.ambient, running]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Button variant="secondary" onClick={onBack}>→ بازگشت به میزها</Button>
        <span className="chip py-1" aria-live="polite">
          <span className={`h-2 w-2 rounded-full ${dot}`} /> {label}
        </span>
      </div>
      {error ? <Alert kind="error">{error}</Alert> : null}
      {message ? <Alert kind={message.kind} onClose={() => setMessage(null)}>{message.text}</Alert> : null}
      {!snapshot ? <Card><Spinner label="در حال دریافت پرونده‌ی میز..." /></Card> : (
        <>
          {snapshot.game && snapshot.game.status === 'started' ? (
            <GameView game={snapshot.game} me={me} offset={clockOffset} busy={busy} post={post} events={events} />
          ) : (
            <>
              {snapshot.game && showResult ? <ResultView game={snapshot.game} me={me} events={events} onClose={() => setShowResult(false)} /> : null}
              {snapshot.game && snapshot.game.status !== 'started' ? <FinalReview game={snapshot.game} me={me} /> : null}
              <WaitingView snapshot={snapshot} me={me} busy={busy} post={post} onLeft={onBack} />
            </>
          )}
        </>
      )}
    </div>
  );
}

function WaitingView({ snapshot, me, busy, post, onLeft }: {
  snapshot: Snapshot; me: Me; busy: string | null; onLeft: () => void;
  post: (k: string, p: string, j?: unknown, s?: string) => Promise<boolean>;
}) {
  const { table, seats } = snapshot;
  const mySeat = seats.find((s) => s.user_id === me.id);
  const isHost = table.host_user_id === me.id || me.role === 'game_admin' || me.role === 'super_admin';
  const confirmed = seats.filter((s) => s.status === 'confirmed').length;
  const base = `/api/v1/tables/${table.id}`;
  const slots = Array.from({ length: table.max_players }, (_, i) => seats.find((s) => s.seat_index === i + 1) ?? null);
  const ready = confirmed === table.max_players;

  return (
    <Card kicker={`TABLE #${String(table.id).padStart(3, '0')} — ${STATUS_FA[table.status] ?? table.status}`} title={table.name}>
      <div className="relative mx-auto mb-5 grid max-w-xl grid-cols-3 gap-3">
        {slots.map((s, i) => (
          <div key={i} style={{ animationDelay: `${i * 70}ms` }}
            className={`relative flex animate-rise flex-col items-center gap-1 rounded-2xl border p-3 text-center text-sm transition ${s ? (s.status === 'confirmed' ? 'border-teal-300/50 bg-teal-400/10 shadow-glow' : 'border-amber-300/40 bg-amber-300/5') : 'border-dashed border-white/15 bg-black/20'}`}>
            <span className="font-type text-[10px] tracking-widest text-slate-500" dir="ltr">SEAT {i + 1}</span>
            {s ? (
              <>
                <span className="relative">
                  <Avatar name={s.name} size="h-11 w-11" />
                  <span className={`absolute -bottom-0.5 -left-0.5 h-3 w-3 rounded-full border-2 border-black ${s.connected ? 'bg-teal-300' : 'bg-slate-600'}`} title={s.connected ? 'آنلاین' : 'آفلاین'} />
                </span>
                <span className="max-w-full truncate font-semibold">{s.name}{s.user_id === me.id ? ' (شما)' : ''}</span>
                <span className={`text-[11px] ${s.status === 'confirmed' ? 'text-teal-200' : 'text-amber-200'}`}>{s.status === 'confirmed' ? '✓ آماده' : 'منتظر تأیید'}</span>
              </>
            ) : table.status === 'waiting' && !mySeat ? (
              <button className="mt-1 flex h-[4.5rem] flex-col items-center justify-center gap-1 text-amber-200 transition hover:text-amber-100" disabled={busy !== null}
                onClick={() => post(`seat${i}`, `${base}/reserve`, { seat_index: i + 1 }, `صندلی ${i + 1} رزرو شد.`)}>
                <span className="flex h-10 w-10 items-center justify-center rounded-full border border-amber-300/40 text-xl">+</span>
                <span className="text-xs">نشستن</span>
              </button>
            ) : <div className="flex h-[4.5rem] items-center text-slate-600">خالی</div>}
          </div>
        ))}
      </div>

      <div className="mb-4">
        <div className="mb-1 flex justify-between text-xs text-slate-400"><span>بازیکنان آماده</span><span className="font-type">{confirmed}/{table.max_players}</span></div>
        <div className="h-2 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full bg-gradient-to-l from-teal-300 to-amber-400 transition-all duration-700" style={{ width: `${(confirmed / table.max_players) * 100}%` }} />
        </div>
        <p className="mt-2 text-xs text-slate-500">تماشاچی‌ها: {table.spectators}</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {mySeat && mySeat.status === 'pending' ? (
          <Button variant="success" busy={busy === 'confirm'} onClick={() => post('confirm', `${base}/confirm`, undefined, 'حضور شما تأیید شد.')}>تأیید حضور (آماده‌ام)</Button>
        ) : null}
        {mySeat && table.status === 'waiting' ? (
          <Button variant="danger" busy={busy === 'cancel'} onClick={() => post('cancel', `${base}/cancel`).then((ok) => ok && onLeft())}>ترک میز</Button>
        ) : null}
        {!mySeat ? (
          <Button variant="secondary" busy={busy === 'unspec'} onClick={() => api(`${base}/spectate`, { method: 'DELETE' }).then(onLeft)}>{table.status === 'waiting' && snapshot.seats.length === 0 && !snapshot.game ? 'خروج از تماشا' : 'خروج'}</Button>
        ) : null}
        {isHost && table.status === 'waiting' ? (
          <Button busy={busy === 'start'} disabled={!ready} className={ready ? 'animate-pulse' : ''} onClick={() => post('start', `${base}/start`, {})}>
            شروع بازجویی
          </Button>
        ) : null}
      </div>
      {isHost && !ready ? <p className="mt-2 text-xs text-slate-500">شروع بازی وقتی فعال می‌شود که هر {table.max_players} بازیکن حضورشان را تأیید کنند.</p> : null}
    </Card>
  );
}

function RoleCard({ role, teammates }: { role: string; teammates: string[] }) {
  const [open, setOpen] = useState(false);
  const style = ROLE_STYLE[role] ?? ROLE_STYLE.independent;
  return (
    <div className={`flip h-56 cursor-pointer select-none ${open ? 'open' : ''}`} onClick={() => { setOpen(!open); haptic('light'); }}
      role="button" aria-pressed={open} aria-label={open ? 'پنهان کردن نقش' : 'نمایش نقش مخفی'}>
      <div className="flip-inner h-full">
        <div className="flip-face flex flex-col items-center justify-center gap-3 rounded-2xl border border-amber-300/30 bg-[repeating-linear-gradient(45deg,rgba(232,194,106,.06)_0_10px,transparent_10px_20px)] bg-black/50">
          <span className="stamp animate-stamp border-rose-500 text-rose-500">محرمانه</span>
          <span className="font-type text-xs tracking-widest text-slate-400">برای دیدن نقش ضربه بزنید</span>
        </div>
        <div className={`flip-face flip-back flex flex-col items-center justify-center gap-2 rounded-2xl border bg-black/60 p-4 text-center ${style.glow}`}>
          <svg viewBox="0 0 52 52" className={`h-14 w-14 ${style.color}`} aria-hidden>{style.icon}</svg>
          <div className={`title-display text-4xl ${style.color}`}>{ROLE_FA[role] ?? role}</div>
          <p className="text-xs text-slate-300">{style.motto}</p>
          {teammates.length ? <p className="text-xs text-rose-200">هم‌تیمی: {teammates.join('، ')}</p> : null}
          <p className="text-[10px] text-slate-500">فقط شما این را می‌بینید • ضربه برای پنهان کردن</p>
        </div>
      </div>
    </div>
  );
}

const STAGES: [string, string][] = [['interrogation', 'شناسایی نفوذی‌ها'], ['briefing', 'باز شدن پرونده'], ['investigation', 'تحقیق و رأی'], ['finished', 'حکم']];

function StageTrack({ game }: { game: GameState }) {
  const stage = game.stage ?? 'investigation';
  const order = STAGES.map(([k]) => k);
  const now = order.indexOf(stage);
  const steps = (game.settings?.interrogation_total ?? 0) > 0 ? STAGES : STAGES.filter(([k]) => k !== 'interrogation');
  return (
    <ol className="stage-track" aria-label="مراحل پرونده">
      {steps.map(([k, label]) => {
        const i = order.indexOf(k);
        return (
          <li key={k} className={i < now ? 'done' : i === now ? 'now' : ''} aria-current={i === now ? 'step' : undefined}>
            <span className="dot" />{label}{k === 'investigation' && stage === 'investigation' ? ` · دور ${game.round_no}/${game.total_rounds}` : ''}
          </li>
        );
      })}
    </ol>
  );
}

function SidePanel({ game, me }: { game: GameState; me: Me }) {
  const nameOf = useMemo(() => Object.fromEntries(game.players.map((p) => [p.user_id, p.name])), [game.players]);
  return (
    <div className="space-y-4">
      {game.me.is_player && game.me.role ? (
        <Card kicker="TOP SECRET" title="نقش مخفی شما">
          <RoleCard role={game.me.role} teammates={(game.me.teammates ?? []).map((id) => nameOf[id])} />
        </Card>
      ) : null}
      <Card kicker="SUSPECTS" title="مظنونین">
        <ul className="space-y-2">
          {game.players.map((p) => (
            <li key={p.user_id} className={`relative flex items-center justify-between overflow-hidden rounded-xl border px-3 py-2 text-sm transition ${p.is_alive ? 'border-white/10 bg-black/30' : 'border-rose-500/20 bg-rose-950/20'}`}>
              <span className={`flex items-center gap-2 ${p.is_alive ? '' : 'text-slate-500'}`}>
                <span className="relative">
                  <Avatar name={p.name} dim={!p.is_alive} size="h-8 w-8" />
                  <span className={`absolute -bottom-0.5 -left-0.5 h-2.5 w-2.5 rounded-full border-2 border-black ${p.connected ? 'bg-teal-300' : 'bg-slate-600'}`} title={p.connected ? 'آنلاین' : 'آفلاین'} />
                </span>
                {p.name}{p.user_id === me.id ? ' (شما)' : ''}
              </span>
              {p.role ? <span className={`text-xs ${ROLE_STYLE[p.role]?.color ?? ''}`}>{ROLE_FA[p.role] ?? p.role}</span> : null}
              {!p.is_alive ? <span className="stamp absolute left-1/3 top-1 animate-stamp border-rose-600 text-sm text-rose-600">حذف</span> : null}
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

type Tab = 'session' | 'board' | 'dossier';

function GameView({ game, me, offset, busy, post, events }: {
  game: GameState; me: Me; offset: number; busy: string | null; events: GameEvent[];
  post: (k: string, p: string, j?: unknown, s?: string) => Promise<boolean>;
}) {
  const stage = game.stage ?? 'investigation';
  const opening = useMemo(() => seenStore(game.id, 'opening'), [game.id]);
  const seen = useMemo(() => seenClues(game.id), [game.id]);
  const [showOpening, setShowOpening] = useState(() => !opening.has());
  const [queue, setQueue] = useState<ClueBrief[]>([]);
  const [fresh, setFresh] = useState<number[]>([]);
  const [tab, setTab] = useState<Tab>('session');
  const [focusClue, setFocusClue] = useState<number | null>(null);
  const isPlayer = game.me.is_player && !!game.me.is_alive;
  const openingVisible = showOpening && (stage === 'briefing' || stage === 'investigation') && !!game.case;

  useEffect(() => {
    const clues = game.clues ?? [];
    if (!seen.initialized()) { seen.add(clues.map((c) => c.id)); return; } // never replay past discoveries
    const known = seen.read();
    const unseen = clues.filter((c) => !known.has(c.id));
    if (!unseen.length || stage !== 'investigation' || openingVisible) return;
    seen.add(unseen.map((c) => c.id));
    setQueue((q) => [...q, ...unseen.filter((u) => !q.some((x) => x.id === u.id))]);
    setFresh((f) => [...f, ...unseen.map((c) => c.id)]);
  }, [game.clues, stage, openingVisible, seen]);
  useEffect(() => {
    if (!fresh.length) return;
    const t = window.setTimeout(() => setFresh([]), 30000);
    return () => window.clearTimeout(t);
  }, [fresh]);

  const enterInvestigation = () => {
    opening.mark();
    seen.add((game.clues ?? []).map((c) => c.id));
    setShowOpening(false);
    if (stage === 'briefing' && isPlayer && !game.briefing?.me_ready) post('ready', `/api/v1/games/${game.id}/briefing/ready`);
  };
  const dequeue = useCallback(() => setQueue((q) => q.slice(1)), []);
  const side = <SidePanel game={game} me={me} />;
  const refreshKey = `${game.phase}-${game.round_no}-${(game.clues ?? []).map((c) => c.id).join('.')}`;

  if (stage === 'interrogation') {
    return <><StageTrack game={game} /><Interrogation game={game} offset={offset} busy={busy} post={post} side={side} /></>;
  }
  if (openingVisible) return <CaseOpening game={game} isPlayer={isPlayer} busy={busy === 'ready'} onEnter={enterInvestigation} />;

  return (
    <>
      <StageTrack game={game} />
      {queue.length ? <Discovery key={queue[0].id} clue={queue[0]} remaining={queue.length - 1} onDone={dequeue} /> : null}
      {stage === 'briefing' ? (
        <Card kicker={`CASE ${game.case?.code ?? ''}`} title="پرونده باز شد"
          actions={<Countdown deadline={game.phase_deadline} offset={offset} total={game.settings?.briefing_seconds ?? 40} />}>
          <p className="text-slate-300">{game.case?.objective}</p>
          <p className="mt-3 text-sm text-slate-400">آماده برای ورود به صحنه: <b className="font-type text-sky-200">{game.briefing?.ready ?? 0}/{game.briefing?.alive ?? 0}</b> — دور اول وقتی همه آماده شوند یا زمان تمام شود شروع می‌شود.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            {isPlayer && !game.briefing?.me_ready ? <Button busy={busy === 'ready'} onClick={() => post('ready', `/api/v1/games/${game.id}/briefing/ready`)}>آماده‌ام</Button> : null}
            <Button variant="secondary" onClick={() => setShowOpening(true)}>بازپخش پرونده</Button>
          </div>
        </Card>
      ) : null}
      <div className="tabs mt-4" role="tablist" aria-label="بخش‌های تحقیق">
        {([['session', 'جلسهٔ بازجویی'], ['board', 'تخته تحقیق'], ['dossier', 'پروندهٔ بازجویی']] as [Tab, string][])
          .filter(([k]) => k !== 'dossier' || (game.dossier?.length ?? 0) > 0)
          .map(([k, label]) => (
            <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => { setTab(k); sfx.play('page'); }}>
              {label}{k === 'board' && fresh.length ? <span className="tab-dot" aria-label="مدرک جدید" /> : null}
            </button>
          ))}
      </div>
      <div className="mt-4">
        {tab === 'session' ? (stage === 'briefing' ? <div className="grid gap-4 lg:grid-cols-3"><div className="lg:col-span-2"><CaseSummary game={game} onReplay={() => setShowOpening(true)} /></div>{side}</div>
          : <RoundSession game={game} me={me} offset={offset} busy={busy} post={post} events={events} side={side} />) : null}
        {tab === 'board' ? <Board gameId={game.id} players={game.players} refreshKey={refreshKey} fresh={fresh}
          focusClueId={focusClue} onFocusHandled={() => setFocusClue(null)} /> : null}
        {tab === 'dossier' ? <Dossier dossier={game.dossier ?? []} meId={me.id} onClue={(id) => { setFocusClue(id); setTab('board'); }} /> : null}
      </div>
    </>
  );
}

function CaseSummary({ game, onReplay }: { game: GameState; onReplay: () => void }) {
  const file = game.case;
  if (!file) return null;
  return (
    <Card kicker={`CASE ${file.code ?? ''}`} title={file.title} actions={<Button variant="secondary" onClick={onReplay}>بازپخش پرونده</Button>}>
      {file.summary ? <p className="leading-8 text-slate-300">{file.summary}</p> : null}
      {file.objective ? <p className="mt-3 rounded-xl border border-rose-400/30 bg-rose-500/10 p-3 text-rose-100"><b>مأموریت: </b>{file.objective}</p> : null}
      {file.briefing?.length ? (
        <dl className="mt-3 grid gap-2 sm:grid-cols-2">
          {file.briefing.map((r) => <div key={r.label} className="rounded-xl border border-white/10 bg-black/30 p-3"><dt className="text-xs text-slate-500">{r.label}</dt><dd>{r.value}</dd></div>)}
        </dl>
      ) : null}
    </Card>
  );
}

function FinalReview({ game, me }: { game: GameState; me: Me }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <Button variant="secondary" onClick={() => setOpen(!open)}>{open ? 'بستن جمع‌بندی تحقیق' : 'جمع‌بندی تحقیق و تخته شما'}</Button>
      </div>
      {open ? (
        <>
          {game.case ? <CaseSummary game={game} onReplay={() => undefined} /> : null}
          <Board gameId={game.id} players={game.players} refreshKey={`final-${game.id}`} />
          {game.dossier?.length ? <Dossier dossier={game.dossier} meId={me.id} /> : null}
        </>
      ) : null}
    </div>
  );
}

function RoundSession({ game, me, offset, busy, post, events, side }: {
  game: GameState; me: Me; offset: number; busy: string | null; events: GameEvent[]; side: React.ReactNode;
  post: (k: string, p: string, j?: unknown, s?: string) => Promise<boolean>;
}) {
  const [answer, setAnswer] = useState('');
  useEffect(() => setAnswer(''), [game.round_no]);
  useEffect(() => haptic('warning'), [game.phase, game.round_no]);
  const amAlivePlayer = game.me.is_player && game.me.is_alive;
  const nameOf = useMemo(() => Object.fromEntries(game.players.map((p) => [p.user_id, p.name])), [game.players]);
  const lastResolved = [...events].reverse().find((e) => e.type === 'round.resolved');
  const phaseFa = game.phase === 'answer' ? 'بازجویی — فاز پاسخ' : game.phase === 'vote' ? 'رأی‌گیری' : 'در حال شمارش';
  const done = game.phase === 'answer' ? game.progress.answered : game.progress.voted;

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="space-y-4 lg:col-span-2">
        <Card kicker={`ROUND ${game.round_no} / ${game.total_rounds}`} title={phaseFa}
          actions={<Countdown key={`${game.phase}-${game.round_no}`} deadline={game.phase_deadline} offset={offset}
            total={game.phase === 'vote' ? game.settings?.vote_seconds ?? 60 : game.settings?.answer_seconds ?? 60} />}>
          {game.question ? (
            <div className="relative -rotate-[0.6deg] rounded-lg bg-paper p-5 text-stone-900 shadow-[0_12px_30px_-8px_rgba(0,0,0,.8)]">
              <span className="absolute -top-3 right-6 h-6 w-16 rotate-3 bg-amber-200/70 shadow" aria-hidden />
              <div className="font-type text-[11px] tracking-[0.3em] text-stone-500" dir="ltr">QUESTION #{game.round_no}</div>
              <p className="mt-1 text-lg font-bold leading-8">{game.question.prompt}</p>
            </div>
          ) : null}
          <div className="mt-4 flex items-center gap-2 text-xs text-slate-400">
            <span>{game.phase === 'answer' ? 'پاسخ داده‌اند' : 'رأی داده‌اند'}</span>
            <div className="flex gap-1">
              {Array.from({ length: game.progress.alive }, (_, i) => (
                <span key={i} className={`h-2 w-4 rounded-sm transition ${i < done ? 'bg-amber-300 shadow-gold' : 'bg-white/10'}`} />
              ))}
            </div>
            <span className="font-type">{done}/{game.progress.alive}</span>
          </div>

          {game.phase === 'answer' && amAlivePlayer ? (
            game.my_answer ? <div className="mt-4"><Alert kind="success">پاسخ شما ثبت شد: «{game.my_answer}». پاسخ‌ها پس از پایان این فاز نمایش داده می‌شوند.</Alert></div> : (
              <form className="mt-4 flex flex-col gap-2 sm:flex-row" onSubmit={(e) => {
                e.preventDefault();
                if (answer.trim()) post('answer', `/api/v1/games/${game.id}/answer`, { text: answer.trim() });
              }}>
                <input value={answer} onChange={(e) => setAnswer(e.target.value)} maxLength={500} placeholder="پاسخ شما..." className="field flex-1" />
                <Button type="submit" busy={busy === 'answer'} disabled={!answer.trim()}>ثبت پاسخ</Button>
              </form>
            )
          ) : null}

          {game.phase === 'vote' ? (
            <div className="mt-5 space-y-2">
              <h3 className="title-display text-lg text-amber-100">اظهارات این دور</h3>
              {game.answers.length === 0 ? <p className="text-sm text-slate-400">کسی پاسخ نداد.</p> : game.answers.map((a, i) => (
                <div key={a.user_id} style={{ animationDelay: `${i * 80}ms` }} className="flex animate-rise items-start gap-3 rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm">
                  <Avatar name={nameOf[a.user_id] ?? '?'} size="h-8 w-8" />
                  <div><div className="text-xs text-amber-200/80">{nameOf[a.user_id]}</div><div>«{a.text}»</div></div>
                </div>
              ))}
              {amAlivePlayer ? (
                <>
                  <h3 className="title-display mt-5 text-lg text-rose-200">به چه کسی مشکوکید؟</h3>
                  {game.my_vote ? <Alert kind="success">رأی شما برای «{nameOf[game.my_vote]}» ثبت شد.</Alert> : (
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                      {game.players.filter((p) => p.is_alive && p.user_id !== me.id).map((p) => (
                        <button key={p.user_id} disabled={busy !== null}
                          onClick={() => window.confirm(`رأی به «${p.name}»؟ این رأی قابل تغییر نیست.`) && post(`v${p.user_id}`, `/api/v1/games/${game.id}/vote`, { target_user_id: p.user_id })}
                          className="group flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-600/10 p-2 text-sm transition hover:-translate-y-0.5 hover:border-rose-400 hover:shadow-blood disabled:opacity-40">
                          <Avatar name={p.name} size="h-8 w-8" />
                          <span className="truncate">{busy === `v${p.user_id}` ? '...' : p.name}</span>
                          <span className="mr-auto text-rose-300 opacity-0 transition group-hover:opacity-100">◎</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              ) : null}
            </div>
          ) : null}
          {!game.me.is_player ? <p className="mt-3 text-sm text-slate-400">شما تماشاچی هستید.</p> : null}
          {game.me.is_player && !game.me.is_alive ? <p className="mt-3 text-sm text-rose-300">شما حذف شده‌اید و فقط تماشا می‌کنید.</p> : null}
        </Card>
        {lastResolved ? <RoundResult key={lastResolved.id} ev={lastResolved} nameOf={nameOf} /> : null}
      </div>

      {side}
    </div>
  );
}

function RoundResult({ ev, nameOf }: { ev: GameEvent; nameOf: Record<number, string> }) {
  const p = ev.payload as { round: number; eliminated_user_id: number | null; eliminated_role: string | null; tally: Record<string, number>; abstained: number };
  const max = Math.max(1, ...Object.values(p.tally));
  return (
    <Card kicker={`VERDICT — ROUND ${p.round}`} title={`حکم دور ${p.round}`} className={p.eliminated_user_id ? 'animate-shake' : ''}>
      {p.eliminated_user_id ? (
        <div className="flex items-center gap-3">
          <Avatar name={nameOf[p.eliminated_user_id] ?? '?'} dim />
          <p className="text-base">«{nameOf[p.eliminated_user_id]}» از اتاق بیرون رفت{p.eliminated_role ? <> — نقش: <b className={ROLE_STYLE[p.eliminated_role]?.color}>{ROLE_FA[p.eliminated_role] ?? p.eliminated_role}</b></> : ''}.</p>
          <span className="stamp mr-auto animate-stamp border-rose-600 text-rose-600">اخراج</span>
        </div>
      ) : <p>رأی‌ها مساوی شد یا رأیی ثبت نشد؛ کسی حذف نشد.</p>}
      <ul className="mt-4 space-y-1.5 text-sm">
        {Object.entries(p.tally).sort((a, b) => b[1] - a[1]).map(([uid, n]) => (
          <li key={uid} className="flex items-center gap-2">
            <span className="w-24 truncate text-slate-300">{nameOf[Number(uid)]}</span>
            <span className="h-2 flex-1 overflow-hidden rounded-full bg-white/10"><span className="block h-full rounded-full bg-gradient-to-l from-rose-400 to-rose-700" style={{ width: `${(n / max) * 100}%` }} /></span>
            <span className="w-10 text-left font-type text-xs text-slate-400">{n}</span>
          </li>
        ))}
        <li className="text-xs text-slate-500">ممتنع: {p.abstained}</li>
      </ul>
    </Card>
  );
}

function ResultView({ game, me, events, onClose }: { game: GameState; me: Me; events: GameEvent[]; onClose: () => void }) {
  const myRole = game.players.find((p) => p.user_id === me.id)?.role;
  const winRole = { detectives: 'detective', spies: 'spy', independent: 'independent' }[game.winner ?? ''];
  const iWon = game.status === 'finished' && myRole && myRole === winRole;
  void events;
  useEffect(() => { if (myRole) haptic(iWon ? 'success' : 'warning'); }, [iWon, myRole]);
  return (
    <Card kicker="CASE CLOSED" title="پایان پرونده" actions={<Button variant="secondary" onClick={onClose}>بستن</Button>} className="overflow-hidden">
      <span className={`stamp absolute left-5 top-24 animate-stamp text-2xl ${game.status === 'aborted' ? 'border-slate-400 text-slate-400' : 'border-rose-600 text-rose-600'}`}>
        {game.status === 'aborted' ? 'لغو شد' : 'مختومه'}
      </span>
      {game.status === 'aborted' ? <Alert kind="warn">این بازی توسط مدیر لغو شد و در آمار ثبت نشد.</Alert> : (
        <div className="py-2 text-center">
          <div className="text-sm text-slate-400">برنده</div>
          <div className="title-display gold-text text-5xl">{WINNER_FA[game.winner ?? 'draw'] ?? game.winner}</div>
          {myRole ? <div className={`mt-2 title-display text-xl ${iWon ? 'text-teal-200' : game.winner === 'draw' ? 'text-slate-300' : 'text-rose-300'}`}>{iWon ? 'شما بردید!' : game.winner === 'draw' ? 'مساوی' : 'شما باختید'}</div> : null}
        </div>
      )}
      <ul className="mt-4 grid gap-2 sm:grid-cols-2">
        {game.players.map((p, i) => (
          <li key={p.user_id} style={{ animationDelay: `${i * 90}ms` }} className="flex animate-rise items-center gap-2 rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm">
            <Avatar name={p.name} dim={!p.is_alive} size="h-8 w-8" />
            <span>{p.name}</span>
            <b className={`mr-auto ${ROLE_STYLE[p.role ?? '']?.color ?? ''}`}>{ROLE_FA[p.role ?? ''] ?? p.role}</b>
            {!p.is_alive ? <span className="text-xs text-slate-500">(حذف)</span> : null}
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-slate-500">{game.round_no} دور در این بازی برگزار شد. برای بازی بعدی، دوباره صندلی رزرو کنید.</p>
    </Card>
  );
}
