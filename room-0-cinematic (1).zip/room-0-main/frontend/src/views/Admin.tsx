import React, { useCallback, useEffect, useState } from 'react';
import { api, displayName, Me, STAFF_ROLE_FA, STATUS_FA, WINNER_FA } from '../api';
import { Alert, Button, Card, Spinner, useAsyncAction } from '../ui';
import { Stat } from './Profile';

interface AdminUser extends Me { is_banned: boolean; ban_reason: string | null; last_seen_at: string | null }
interface Overview { users_total: number; banned_total: number; active_games: number; finished_games: number; tables_reserved: number; admins_total: number; winners: Record<string, number> }
interface AdminTable { id: number; name: string; status: string; seated: number; max_players: number; game_id: number | null; host_user_id: number | null }
interface AdminGame { id: number; table_id: number; status: string; phase: string; round_no: number; winner: string | null; started_at: string | null }
interface Action { id: number; admin_user_id: number; action: string; target_user_id: number | null; target_table_id: number | null; reason: string | null; created_at: string }
interface Status { database: boolean; redis: boolean | null; ws_connections: number; uptime_seconds: number; recent_errors: { at: string; level: string; logger: string; message: string; error: string }[] }

const MOD = ['moderator', 'game_admin', 'super_admin'];
const ACTION_FA: Record<string, string> = { 'user.ban': 'مسدودسازی', 'user.unban': 'رفع مسدودی', 'user.role': 'تغییر نقش', 'table.close': 'بستن میز', 'game.abort': 'لغو بازی' };
const fmt = (s: string | null) => (s ? new Date(s + 'Z').toLocaleString('fa-IR') : '—');

export default function Admin({ me }: { me: Me }) {
  const [tab, setTab] = useState<'overview' | 'users' | 'tables' | 'log' | 'status'>('overview');
  const tabs: [typeof tab, string][] = [['overview', 'آمار'], ['users', 'کاربران'], ['tables', 'میزها و بازی‌ها'], ['log', 'گزارش اقدامات'], ['status', 'وضعیت سرویس']];
  return (
    <div className="space-y-4">
      <nav className="flex flex-wrap gap-2">
        {tabs.map(([k, l]) => <Button key={k} variant={tab === k ? 'primary' : 'secondary'} onClick={() => setTab(k)}>{l}</Button>)}
      </nav>
      {tab === 'overview' ? <OverviewTab /> : tab === 'users' ? <UsersTab me={me} /> : tab === 'tables' ? <TablesTab me={me} /> : tab === 'log' ? <LogTab /> : <StatusTab />}
    </div>
  );
}

function useLoad<T>(path: string) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState('');
  const load = useCallback(() => api<T>(path).then((d) => { setData(d); setError(''); }).catch((e) => setError(e.message)), [path]);
  useEffect(() => { load(); }, [load]);
  return { data, error, load };
}

function OverviewTab() {
  const { data, error } = useLoad<Overview>('/api/v1/admin/overview');
  if (error) return <Alert kind="error">{error}</Alert>;
  if (!data) return <Spinner />;
  return (
    <Card title="آمار کلی">
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="کل کاربران" value={data.users_total} />
        <Stat label="کاربران مسدود" value={data.banned_total} tone="text-red-300" />
        <Stat label="بازی‌های فعال" value={data.active_games} tone="text-emerald-300" />
        <Stat label="بازی‌های تمام‌شده" value={data.finished_games} />
        <Stat label="میزهای دارای رزرو" value={data.tables_reserved} tone="text-yellow-300" />
        <Stat label="کادر مدیریت" value={data.admins_total} tone="text-violet-300" />
      </div>
      <p className="mt-4 text-sm text-slate-300">
        برنده‌ها: {Object.entries(data.winners).map(([k, v]) => `${WINNER_FA[k] ?? k}: ${v}`).join(' • ') || '—'}
      </p>
    </Card>
  );
}

function UsersTab({ me }: { me: Me }) {
  const [q, setQ] = useState('');
  const [query, setQuery] = useState('');
  const { data, error, load } = useLoad<{ total: number; items: AdminUser[] }>(`/api/v1/admin/users?q=${encodeURIComponent(query)}`);
  const { busy, message, setMessage, run } = useAsyncAction();
  const canModerate = MOD.includes(me.role);

  const ban = (u: AdminUser) => {
    const reason = window.prompt(`دلیل مسدودسازی «${displayName(u)}» (حداقل ۳ حرف):`)?.trim();
    if (!reason) return;
    run(`b${u.id}`, () => api(`/api/v1/admin/users/${u.id}/ban`, { method: 'POST', json: { reason } }), 'کاربر مسدود شد.').then(load);
  };
  const unban = (u: AdminUser) =>
    run(`u${u.id}`, () => api(`/api/v1/admin/users/${u.id}/unban`, { method: 'POST', json: {} }), 'مسدودی برداشته شد.').then(load);
  const setRole = (u: AdminUser, role: string) =>
    run(`r${u.id}`, () => api(`/api/v1/admin/users/${u.id}/role`, { method: 'POST', json: { role } }), 'نقش تغییر کرد.').then(load);

  return (
    <Card title="کاربران">
      <form className="mb-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); setQuery(q.trim()); }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} maxLength={64} placeholder="جست‌وجو: نام، @username یا شناسه تلگرام"
          className="field flex-1" />
        <Button type="submit">جست‌وجو</Button>
      </form>
      {message ? <Alert kind={message.kind} onClose={() => setMessage(null)}>{message.text}</Alert> : null}
      {error ? <Alert kind="error">{error}</Alert> : !data ? <Spinner /> : (
        <>
          <p className="mb-2 text-xs text-slate-400">{data.total} کاربر</p>
          <ul className="space-y-2">
            {data.items.map((u) => (
              <li key={u.id} className="flex flex-col gap-2 rounded-xl border border-white/10 bg-black/30 p-3 text-sm md:flex-row md:items-center md:justify-between">
                <div>
                  <b>{displayName(u)}</b> {u.username ? <span className="text-slate-400">@{u.username}</span> : null}
                  <div className="text-xs text-slate-400">شناسه {u.id} • تلگرام {u.telegram_id} • {STAFF_ROLE_FA[u.role] ?? u.role} • بازی {u.games_played} / برد {u.games_won} • آخرین حضور {fmt(u.last_seen_at)}</div>
                  {u.is_banned ? <div className="text-xs text-red-300">مسدود — دلیل: {u.ban_reason}</div> : null}
                </div>
                <div className="flex flex-wrap gap-2">
                  {me.role === 'super_admin' && u.role !== 'super_admin' && u.id !== me.id ? (
                    <select value={u.role} disabled={busy !== null} onChange={(e) => setRole(u, e.target.value)}
                      className="field w-auto py-1 text-xs">
                      {Object.keys(STAFF_ROLE_FA).filter((r) => r !== 'super_admin').map((r) => <option key={r} value={r}>{STAFF_ROLE_FA[r]}</option>)}
                    </select>
                  ) : null}
                  {canModerate && u.id !== me.id && u.role !== 'super_admin' ? (
                    u.is_banned
                      ? <Button variant="success" busy={busy === `u${u.id}`} onClick={() => unban(u)}>رفع مسدودی</Button>
                      : <Button variant="danger" busy={busy === `b${u.id}`} onClick={() => ban(u)}>مسدودسازی</Button>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </Card>
  );
}

function TablesTab({ me }: { me: Me }) {
  const tables = useLoad<{ items: AdminTable[] }>('/api/v1/admin/tables');
  const games = useLoad<{ items: AdminGame[] }>('/api/v1/admin/games');
  const { busy, message, setMessage, run } = useAsyncAction();
  const canModerate = MOD.includes(me.role);
  const canAbort = ['game_admin', 'super_admin'].includes(me.role);
  const reload = () => { tables.load(); games.load(); };

  return (
    <div className="space-y-4">
      {message ? <Alert kind={message.kind} onClose={() => setMessage(null)}>{message.text}</Alert> : null}
      <Card title="میزها" actions={<Button variant="secondary" onClick={reload}>به‌روزرسانی</Button>}>
        {tables.error ? <Alert kind="error">{tables.error}</Alert> : !tables.data ? <Spinner /> : (
          <ul className="space-y-2">
            {tables.data.items.map((t) => (
              <li key={t.id} className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm">
                <span>#{t.id} {t.name} — {STATUS_FA[t.status] ?? t.status} — {t.seated}/{t.max_players} نفر</span>
                {canModerate && t.status === 'waiting' ? (
                  <Button variant="danger" busy={busy === `c${t.id}`} onClick={() => {
                    const reason = window.prompt('دلیل بستن میز:') ?? '';
                    if (window.confirm(`میز «${t.name}» بسته شود؟ رزروها لغو می‌شوند.`))
                      run(`c${t.id}`, () => api(`/api/v1/admin/tables/${t.id}/close`, { method: 'POST', json: { reason } }), 'میز بسته شد.').then(reload);
                  }}>بستن میز</Button>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Card title="بازی‌ها">
        {games.error ? <Alert kind="error">{games.error}</Alert> : !games.data ? <Spinner /> : (
          <ul className="space-y-2">
            {games.data.items.map((g) => (
              <li key={g.id} className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm">
                <span>بازی #{g.id} (میز {g.table_id}) — {STATUS_FA[g.status] ?? g.status}{g.status === 'started' ? ` — دور ${g.round_no}، ${g.phase}` : ''}{g.winner ? ` — برنده: ${WINNER_FA[g.winner] ?? g.winner}` : ''} — {fmt(g.started_at)}</span>
                {canAbort && g.status === 'started' ? (
                  <Button variant="danger" busy={busy === `g${g.id}`} onClick={() => window.confirm('بازی لغو شود؟ آمار ثبت نمی‌شود.') &&
                    run(`g${g.id}`, () => api(`/api/v1/games/${g.id}/finish`, { method: 'POST' }), 'بازی لغو شد.').then(reload)}>لغو بازی</Button>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function LogTab() {
  const { data, error } = useLoad<{ items: Action[] }>('/api/v1/admin/actions');
  if (error) return <Alert kind="error">{error}</Alert>;
  if (!data) return <Spinner />;
  return (
    <Card title="گزارش اقدامات مدیریتی">
      {data.items.length === 0 ? <p className="text-slate-400">اقدامی ثبت نشده است.</p> : (
        <ul className="space-y-2 text-sm">
          {data.items.map((a) => (
            <li key={a.id} className="rounded-lg border border-white/10 bg-black/30 px-3 py-2">
              {fmt(a.created_at)} — مدیر #{a.admin_user_id}: {ACTION_FA[a.action] ?? a.action}
              {a.target_user_id ? ` کاربر #${a.target_user_id}` : ''}{a.target_table_id ? ` میز #${a.target_table_id}` : ''}
              {a.reason ? <span className="text-slate-400"> — {a.reason}</span> : null}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function StatusTab() {
  const { data, error, load } = useLoad<Status>('/api/v1/admin/status');
  if (error) return <Alert kind="error">{error}</Alert>;
  if (!data) return <Spinner />;
  const badge = (v: boolean | null) => v === null ? <span className="text-slate-400">استفاده نمی‌شود</span> : v ? <span className="text-emerald-300">سالم</span> : <span className="text-red-300">خطا</span>;
  return (
    <Card title="وضعیت سرویس‌ها" actions={<Button variant="secondary" onClick={load}>به‌روزرسانی</Button>}>
      <div className="grid gap-2 text-sm sm:grid-cols-2">
        <div>دیتابیس: {badge(data.database)}</div>
        <div>Redis: {badge(data.redis)}</div>
        <div>اتصال‌های زنده (این worker): {data.ws_connections}</div>
        <div>مدت فعالیت: {Math.round(data.uptime_seconds / 60)} دقیقه</div>
      </div>
      <h3 className="mt-4 font-semibold">خطاها و هشدارهای اخیر</h3>
      {data.recent_errors.length === 0 ? <p className="text-sm text-slate-400">خطایی ثبت نشده است.</p> : (
        <ul className="mt-2 space-y-1 text-xs">
          {data.recent_errors.map((e, i) => (
            <li key={i} dir="ltr" className="rounded bg-slate-800 px-2 py-1 text-left font-mono">{e.at} {e.level} {e.logger}: {e.message} {e.error}</li>
          ))}
        </ul>
      )}
    </Card>
  );
}
