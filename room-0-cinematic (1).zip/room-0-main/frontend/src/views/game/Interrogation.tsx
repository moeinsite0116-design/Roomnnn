import React, { useEffect, useState } from 'react';
import { CLUE_KIND_FA, GameState } from '../../api';
import { seenStore, sfx } from '../../fx';
import { Alert, Button, Card, Countdown, haptic } from '../../ui';

type Post = (k: string, p: string, j?: unknown, s?: string) => Promise<boolean>;

/** «مرحله شناسایی نفوذی‌ها»: the server picks each player's question; this view only collects intent. */
export default function Interrogation({ game, offset, busy, post, side }: {
  game: GameState; offset: number; busy: string | null; post: Post; side: React.ReactNode;
}) {
  const block = game.interrogation;
  const intro = seenStore(game.id, 'intro');
  const [showIntro, setShowIntro] = useState(() => !intro.has());
  const [choice, setChoice] = useState<string | null>(null);
  const [clueId, setClueId] = useState<number | null>(null);
  const [text, setText] = useState('');
  const q = block?.question ?? null;
  useEffect(() => { setChoice(null); setClueId(null); setText(''); }, [q?.id]);
  useEffect(() => { if (block?.step) haptic('light'); }, [block?.step]);

  const preliminary = (game.clues ?? []).filter((c) => c.round === 0);
  const isPlayer = game.me.is_player && game.me.is_alive;
  const canSend = q && (q.kind === 'choice' ? !!choice : q.kind === 'evidence' ? clueId !== null : text.trim().length > 0);

  const submit = () => {
    if (!q || !canSend) return;
    sfx.play('page');
    const body = q.kind === 'choice' ? { question_id: q.id, option_key: choice }
      : q.kind === 'evidence' ? { question_id: q.id, clue_id: clueId } : { question_id: q.id, text: text.trim() };
    post('iq', `/api/v1/games/${game.id}/interrogation/answer`, body);
  };

  if (!block) return null;
  return (
    <>
      {showIntro ? (
        <div className="iq-intro" role="dialog" aria-modal="true" aria-label="مرحله شناسایی نفوذی‌ها">
          <div className="iq-intro-scan" aria-hidden />
          <div className="iq-intro-body">
            <span className="iq-intro-kicker" dir="ltr">PHASE 01 · INFILTRATOR SCREENING</span>
            <h2 className="iq-intro-title">مرحله شناسایی نفوذی‌ها</h2>
            <p className="iq-intro-lead">{game.case?.title ? `پرونده‌ی «${game.case.title}» هنوز بسته است.` : 'پرونده هنوز بسته است.'} قبل از باز شدنش، همه بازجویی می‌شوند.</p>
            <ul className="iq-intro-rules">
              <li>{block.total} سؤال؛ هر سؤال {game.settings?.interrogation_seconds ?? 45} ثانیه.</li>
              <li>سؤال بعدی هر نفر از روی پاسخ قبلی خودش انتخاب می‌شود.</li>
              <li>پاسخ‌ها و زمان پاسخ‌گویی ثبت می‌شوند و بعد از این مرحله برای همه باز می‌شوند.</li>
            </ul>
            <Button onClick={() => { intro.mark(); setShowIntro(false); sfx.unlock(); sfx.play('stamp'); }}>شروع بازجویی</Button>
          </div>
        </div>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <Card kicker={`INTERROGATION · ${block.step}/${block.total}`} title="مرحله شناسایی نفوذی‌ها"
            actions={<Countdown key={`iq-${block.step}`} deadline={game.phase_deadline} offset={offset} total={game.settings?.interrogation_seconds ?? 45} />}>
            <ol className="iq-steps" aria-label="پیشرفت بازجویی">
              {Array.from({ length: block.total }, (_, i) => (
                <li key={i} className={i + 1 < block.step ? 'done' : i + 1 === block.step ? 'now' : ''}><span>{i + 1}</span></li>
              ))}
            </ol>

            {q ? (
              <div className="iq-paper" key={q.id}>
                <span className="iq-tape" aria-hidden />
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-type text-[12px] tracking-[0.25em] text-stone-500" dir="ltr">Q-{String(block.step).padStart(2, '0')}</span>
                  {q.follow_up ? <span className="iq-followup">سؤال تکمیلی، بر اساس پاسخ قبلی شما</span> : null}
                </div>
                <p className="mt-1 text-lg font-bold leading-8">{q.prompt}</p>
              </div>
            ) : isPlayer ? <p className="text-slate-400">سؤالی برای شما باقی نمانده است.</p> : null}

            {isPlayer && q && !block.my_answer ? (
              <div className="mt-4 space-y-3">
                {q.kind === 'choice' ? (
                  <div className="grid gap-2" role="radiogroup" aria-label="گزینه‌ها">
                    {q.options.map((o) => (
                      <button key={o.key} role="radio" aria-checked={choice === o.key} onClick={() => { setChoice(o.key); sfx.play('tick'); }}
                        className={`iq-option ${choice === o.key ? 'on' : ''}`}>
                        <span className="iq-radio" aria-hidden />{o.label}
                      </button>
                    ))}
                  </div>
                ) : null}
                {q.kind === 'evidence' ? (
                  <div className="grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="مدارک">
                    {q.evidence.map((c) => (
                      <button key={c.id} role="radio" aria-checked={clueId === c.id} onClick={() => { setClueId(c.id); sfx.play('tick'); }}
                        className={`iq-option ${clueId === c.id ? 'on' : ''}`}>
                        <span className="iq-radio" aria-hidden />
                        <span><span className="block text-xs text-sky-300/80">{CLUE_KIND_FA[c.kind] ?? 'مدرک'}</span>{c.title}</span>
                      </button>
                    ))}
                  </div>
                ) : null}
                {q.kind === 'text' ? (
                  <textarea value={text} onChange={(e) => setText(e.target.value)} maxLength={300} rows={3}
                    className="field" placeholder="پاسخ کوتاه و دقیق..." />
                ) : null}
                <Button onClick={submit} busy={busy === 'iq'} disabled={!canSend}>ثبت پاسخ در پرونده</Button>
              </div>
            ) : null}

            {block.my_answer ? (
              <div className="mt-4">
                <Alert kind={block.my_answer.skipped ? 'warn' : 'success'}>
                  {block.my_answer.skipped ? 'وقت این سؤال تمام شد و بی‌پاسخ ثبت شد.' : <>پاسخ شما ثبت شد: «{block.my_answer.display}»</>}
                </Alert>
              </div>
            ) : null}

            <div className="mt-4 flex items-center gap-2 text-sm text-slate-400">
              <span>پاسخ داده‌اند</span>
              <div className="flex gap-1" aria-hidden>
                {Array.from({ length: block.alive }, (_, i) => <span key={i} className={`h-2 w-4 rounded-sm ${i < block.answered ? 'bg-sky-300 shadow-signal' : 'bg-white/10'}`} />)}
              </div>
              <span className="font-type">{block.answered}/{block.alive}</span>
            </div>
            {!game.me.is_player ? <p className="mt-3 text-sm text-slate-400">شما تماشاچی هستید؛ پاسخ‌ها پس از پایان این مرحله منتشر می‌شوند.</p> : null}

            {block.history.length ? (
              <ul className="mt-5 space-y-2 border-t border-white/10 pt-4 text-sm">
                {block.history.map((h) => (
                  <li key={h.step} className="flex gap-3 text-slate-300">
                    <span className="font-type text-xs text-slate-500" dir="ltr">Q-{String(h.step).padStart(2, '0')}</span>
                    <span className="flex-1">{h.prompt}<span className="block text-sky-200">{h.skipped ? 'بی‌پاسخ' : `«${h.answer}»`}</span></span>
                  </li>
                ))}
              </ul>
            ) : null}
          </Card>
        </div>

        <div className="space-y-4">
          {side}
          {preliminary.length ? (
            <Card kicker="PRE-FILE" title="پیش‌پرونده">
              <ul className="space-y-2">
                {preliminary.map((c) => (
                  <li key={c.id} className={`ev-mini imp-${c.importance} ${c.team_only ? 'team' : ''}`}>
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="text-sky-300/80">{CLUE_KIND_FA[c.kind] ?? 'مدرک'}</span>
                      {c.team_only ? <span className="text-rose-300">محرمانهٔ تیم شما</span> : null}
                    </div>
                    <div className="font-semibold">{c.title}</div>
                    <p className="text-sm leading-7 text-slate-300">{c.text}</p>
                  </li>
                ))}
              </ul>
            </Card>
          ) : null}
        </div>
      </div>
    </>
  );
}
