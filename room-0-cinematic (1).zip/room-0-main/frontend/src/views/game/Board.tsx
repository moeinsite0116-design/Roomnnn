import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { api, Board as BoardData, BoardClue, BoardLink, CLUE_KIND_FA, ENTITY_FA, GamePlayer, parseUtc } from '../../api';
import { sfx } from '../../fx';
import { Alert, Button, Card, Spinner, haptic } from '../../ui';

type Filter = 'all' | 'flagged' | 'new' | 'team';
const FILTERS: [Filter, string][] = [['all', 'همه'], ['new', 'بررسی‌نشده'], ['flagged', 'علامت‌دار'], ['team', 'محرمانهٔ تیم']];
const STATUS_FA: Record<string, string> = { new: 'جدید', reviewing: 'در حال بررسی', checked: 'بررسی‌شده' };
const IMPORTANCE_FA: Record<string, string> = { normal: 'معمولی', key: 'کلیدی', critical: 'تعیین‌کننده' };

const KIND_ICON: Record<string, string> = {
  document: 'M7 3h7l5 5v13H7z M14 3v5h5', photo: 'M4 7h4l2-2h4l2 2h4v12H4z M12 16a3 3 0 1 0 0-6 3 3 0 0 0 0 6',
  note: 'M5 4h14v12l-4 4H5z M15 20v-4h4', report: 'M6 3h12v18H6z M9 8h6 M9 12h6 M9 16h4',
  testimony: 'M4 5h16v10H9l-5 4z', record: 'M5 4h14v16H5z M8 8h8 M8 12h8 M8 16h5',
};

function KindIcon({ kind, className = 'h-5 w-5' }: { kind: string; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" aria-hidden>
      <path d={KIND_ICON[kind] ?? KIND_ICON.document} />
    </svg>
  );
}

const newRequestId = () => (crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40);

interface Line { key: string; d: string; kind: 'link' | 'bad' | 'rel'; fresh: boolean; x1: number; y1: number; x2: number; y2: number; label?: string }

export default function Board({ gameId, players, refreshKey, focusClueId, onFocusHandled, fresh }: {
  gameId: number; players: GamePlayer[]; refreshKey: string; focusClueId?: number | null; onFocusHandled?: () => void;
  fresh?: number[];
}) {
  const [data, setData] = useState<BoardData | null>(null);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [connect, setConnect] = useState(false);
  const [pick, setPick] = useState<number | null>(null);
  const [showRelations, setShowRelations] = useState(true);
  const [openId, setOpenId] = useState<number | null>(null);
  const [newLink, setNewLink] = useState<number | null>(null);
  const [notice, setNotice] = useState<{ kind: 'warn' | 'error' | 'success'; text: string } | null>(null);
  const [lines, setLines] = useState<Line[]>([]);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const cardRefs = useRef(new Map<number, HTMLElement>());

  const load = useCallback(async () => {
    try {
      setData(await api<BoardData>(`/api/v1/games/${gameId}/board`));
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, [gameId]);
  useEffect(() => { load(); }, [load, refreshKey]);
  useEffect(() => {
    if (focusClueId && data?.clues.some((c) => c.id === focusClueId)) { setOpenId(focusClueId); onFocusHandled?.(); }
  }, [focusClueId, data, onFocusHandled]);

  const clues = data?.clues ?? [];
  const byId = useMemo(() => new Map(clues.map((c) => [c.id, c])), [clues]);
  const visible = clues.filter((c) => filter === 'all' || (filter === 'flagged' && c.note?.flagged)
    || (filter === 'new' && (c.note?.status ?? 'new') !== 'checked') || (filter === 'team' && c.team_only));

  const measure = useCallback(() => {
    const wrap = wrapRef.current;
    if (!wrap || !data) return;
    const box = wrap.getBoundingClientRect();
    const center = (id: number) => {
      const el = cardRefs.current.get(id);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return { x: r.left - box.left + r.width / 2, y: r.top - box.top + 22 };
    };
    const out: Line[] = [];
    const add = (from: number, to: number, kind: Line['kind'], key: string, fresh: boolean, label?: string) => {
      const a = center(from), b = center(to);
      if (!a || !b) return;
      const dist = Math.hypot(b.x - a.x, b.y - a.y);
      const sag = Math.min(70, dist * 0.18);
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2 + sag;
      out.push({ key, d: `M${a.x},${a.y} Q${mx},${my} ${b.x},${b.y}`, kind, fresh, x1: a.x, y1: a.y, x2: b.x, y2: b.y, label });
    };
    if (showRelations) data.relations.forEach((r, i) => add(r.from, r.to, 'rel', `r${i}`, false, r.label));
    data.links.forEach((l) => add(l.from, l.to, l.contradiction ? 'bad' : 'link', `l${l.id}`, l.id === newLink, l.label ?? undefined));
    setLines(out);
  }, [data, showRelations, newLink]);

  useLayoutEffect(() => { measure(); }, [measure, filter]);
  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(() => measure());
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [measure]);

  const link = async (a: number, b: number) => {
    try {
      const res = await api<BoardLink & { created: boolean }>(`/api/v1/games/${gameId}/links`, { method: 'POST', json: { from_clue_id: a, to_clue_id: b } });
      setNewLink(res.id);
      if (res.contradiction) {
        sfx.play('alert'); haptic('warning');
        setNotice({ kind: 'warn', text: `این دو مدرک با هم نمی‌خوانند: «${byId.get(a)?.title}» و «${byId.get(b)?.title}».` });
      } else {
        sfx.play('tick'); haptic('light');
        setNotice(res.created ? { kind: 'success', text: 'اتصال روی تخته ثبت شد.' } : null);
      }
      await load();
    } catch (e) {
      setNotice({ kind: 'error', text: (e as Error).message });
    }
  };

  const onCard = (id: number) => {
    if (!connect || data?.readonly) { setOpenId(id); sfx.play('page'); return; }
    if (pick === null) { setPick(id); sfx.play('tick'); return; }
    if (pick === id) { setPick(null); return; }
    const a = pick;
    setPick(null);
    link(a, id);
  };

  if (error && !data) return <Card><Alert kind="error">{error} <button className="underline" onClick={load}>تلاش دوباره</button></Alert></Card>;
  if (!data) return <Card><Spinner label="در حال چیدن مدارک روی تخته..." /></Card>;

  const open = openId != null ? byId.get(openId) ?? null : null;
  const s = data.summary;

  return (
    <div className="space-y-4">
      <Card kicker="INVESTIGATION BOARD" title="صحنه تحقیق"
        actions={!data.readonly ? (
          <div className="flex flex-wrap gap-2">
            <Button variant={connect ? 'danger' : 'secondary'} onClick={() => { setConnect(!connect); setPick(null); }}>
              {connect ? 'پایان اتصال' : 'اتصال سرنخ‌ها'}
            </Button>
          </div>
        ) : <span className="chip py-1">فقط خواندنی</span>}>
        {s ? (
          <div className="mb-4">
            <div className="mb-1 flex justify-between text-sm text-slate-400"><span>پیشرفت تحقیق</span><span className="font-type">{data.progress}٪</span></div>
            <div className="bd-progress"><span style={{ width: `${data.progress}%` }} /></div>
            <div className="mt-2 flex flex-wrap gap-2 text-sm">
              <span className="chip">مدرک {s.discovered}</span><span className="chip">بررسی‌شده {s.checked}</span>
              <span className="chip">علامت {s.flagged}</span><span className="chip">اتصال {s.links}</span>
              {s.contradictions ? <span className="chip border-rose-400/60 text-rose-200">تناقض {s.contradictions}</span> : null}
              <span className="chip">فرضیه {s.hypotheses}</span>
            </div>
          </div>
        ) : null}
        <div className="mb-3 flex flex-wrap items-center gap-2">
          {FILTERS.map(([k, label]) => (
            <button key={k} onClick={() => setFilter(k)} className={`bd-filter ${filter === k ? 'on' : ''}`}>{label}</button>
          ))}
          <label className="mr-auto flex items-center gap-2 text-sm text-slate-400">
            <input type="checkbox" checked={showRelations} onChange={(e) => setShowRelations(e.target.checked)} className="accent-sky-400" />
            ارتباطات احتمالی
          </label>
        </div>
        {connect ? <p className="mb-3 text-sm text-sky-200">{pick === null ? 'مدرک اول را لمس کنید.' : `«${byId.get(pick)?.title}» انتخاب شد؛ حالا مدرک دوم را لمس کنید.`}</p> : null}
        {notice ? <Alert kind={notice.kind} onClose={() => setNotice(null)}>{notice.text}</Alert> : null}

        {visible.length === 0 ? (
          <div className="bd-empty">
            <KindIcon kind="document" className="h-8 w-8" />
            <p>{clues.length ? 'هیچ مدرکی با این فیلتر نیست.' : 'هنوز مدرکی کشف نشده؛ با پیشرفت پرونده، مدارک این‌جا ظاهر می‌شوند.'}</p>
          </div>
        ) : (
          <div ref={wrapRef} className="bd-wall">
            <svg className="bd-strings" aria-hidden>
              {lines.map((l) => (
                <g key={l.key} className={`bd-line ${l.kind} ${l.fresh ? 'fresh' : ''}`}>
                  <path d={l.d} pathLength={1} />
                  {l.kind !== 'rel' ? <><circle cx={l.x1} cy={l.y1} r="4" /><circle cx={l.x2} cy={l.y2} r="4" /></> : null}
                </g>
              ))}
            </svg>
            <div className="bd-grid">
              {visible.map((c, i) => (
                <ClueCard key={c.id} clue={c} index={i} picked={pick === c.id} connect={connect} fresh={fresh?.includes(c.id) ?? false}
                  refEl={(el) => { if (el) cardRefs.current.set(c.id, el); else cardRefs.current.delete(c.id); }}
                  onClick={() => onCard(c.id)} />
              ))}
            </div>
          </div>
        )}
      </Card>

      {!data.readonly ? <Hypotheses gameId={gameId} data={data} players={players} onSaved={load} /> : (
        data.hypotheses.length ? <Hypotheses gameId={gameId} data={data} players={players} onSaved={load} /> : null
      )}

      {open ? (
        <EvidenceViewer clue={open} data={data} gameId={gameId} onClose={() => setOpenId(null)} onChanged={load}
          onLink={(other) => link(open.id, other)} onOpen={(id) => setOpenId(id)} />
      ) : null}
    </div>
  );
}

function ClueCard({ clue, index, picked, connect, fresh, refEl, onClick }: {
  clue: BoardClue; index: number; picked: boolean; connect: boolean; fresh: boolean;
  refEl: (el: HTMLElement | null) => void; onClick: () => void;
}) {
  const status = clue.note?.status ?? 'new';
  const tilt = ((clue.id * 37) % 5) - 2;
  return (
    <button ref={refEl} onClick={onClick} style={{ animationDelay: `${Math.min(index, 10) * 55}ms`, ['--tilt' as string]: `${tilt * 0.5}deg` } as React.CSSProperties}
      className={`ev-card imp-${clue.importance} ${clue.team_only ? 'team' : ''} ${picked ? 'picked' : ''} ${connect ? 'connecting' : ''} ${fresh ? 'fresh' : ''}`}
      aria-label={`${clue.title}، ${CLUE_KIND_FA[clue.kind] ?? 'مدرک'}، ${STATUS_FA[status]}`}>
      <span className="ev-pin" aria-hidden />
      <span className="flex items-center justify-between gap-2 text-xs">
        <span className="flex items-center gap-1.5 text-sky-200/90"><KindIcon kind={clue.kind} className="h-4 w-4" />{CLUE_KIND_FA[clue.kind] ?? 'مدرک'}</span>
        <span className="text-slate-500">{clue.round ? `دور ${clue.round}` : 'پیش‌پرونده'}</span>
      </span>
      <span className="ev-title">{clue.title}</span>
      <span className="ev-text">{clue.text}</span>
      <span className="mt-auto flex flex-wrap items-center gap-1.5 pt-2 text-xs">
        <span className={`ev-status ${status}`}>{STATUS_FA[status]}</span>
        {clue.importance !== 'normal' ? <span className={`ev-imp ${clue.importance}`}>{IMPORTANCE_FA[clue.importance]}</span> : null}
        {clue.team_only ? <span className="ev-imp critical">تیمی</span> : null}
        {clue.note?.flagged ? <span className="text-rose-300" title="علامت‌دار">⚑</span> : null}
        {clue.note?.text ? <span className="text-slate-400" title="یادداشت دارد">✎</span> : null}
      </span>
    </button>
  );
}

function highlight(text: string, labels: string[]) {
  const usable = labels.filter((l) => l && text.includes(l)).sort((a, b) => b.length - a.length);
  if (!usable.length) return text;
  const parts: React.ReactNode[] = [];
  let rest = text;
  let key = 0;
  while (rest) {
    let best = -1, label = '';
    for (const l of usable) { const at = rest.indexOf(l); if (at !== -1 && (best === -1 || at < best)) { best = at; label = l; } }
    if (best === -1) { parts.push(rest); break; }
    if (best) parts.push(rest.slice(0, best));
    parts.push(<mark key={key++} className="ev-mark">{label}</mark>);
    rest = rest.slice(best + label.length);
  }
  return parts;
}

function EvidenceViewer({ clue, data, gameId, onClose, onChanged, onLink, onOpen }: {
  clue: BoardClue; data: BoardData; gameId: number; onClose: () => void; onChanged: () => void;
  onLink: (otherId: number) => void; onOpen: (id: number) => void;
}) {
  const [zoom, setZoom] = useState(1);
  const [scan, setScan] = useState<'idle' | 'running' | 'done'>('idle');
  const [note, setNote] = useState(clue.note?.text ?? '');
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [imgLoaded, setImgLoaded] = useState(false);
  useEffect(() => { setNote(clue.note?.text ?? ''); setScan('idle'); setZoom(1); setMsg(''); }, [clue.id]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const save = async (patch: { flagged?: boolean; status?: string; note?: string }) => {
    if (data.readonly) return;
    setSaving(true);
    try {
      await api(`/api/v1/games/${gameId}/clues/${clue.id}/note`, { method: 'PUT', json: patch });
      setMsg('ذخیره شد');
      onChanged();
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setSaving(false);
    }
  };
  const runScan = () => {
    setScan('running'); sfx.play('tick');
    window.setTimeout(() => { setScan('done'); sfx.play('clue'); if ((clue.note?.status ?? 'new') === 'new') save({ status: 'reviewing' }); }, 1500);
  };

  const status = clue.note?.status ?? 'new';
  const labels = clue.entities.map((e) => e.label);
  const related = data.relations.filter((r) => r.from === clue.id || r.to === clue.id);
  const linked = data.links.filter((l) => l.from === clue.id || l.to === clue.id);
  const linkedIds = new Set(linked.map((l) => (l.from === clue.id ? l.to : l.from)));
  const titleOf = (id: number) => data.clues.find((c) => c.id === id)?.title ?? 'مدرک';
  const when = clue.discovered_at ? new Date(parseUtc(clue.discovered_at)).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : '';

  return (
    <div className="ev-modal" role="dialog" aria-modal="true" aria-label={clue.title} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`ev-sheet imp-${clue.importance}`}>
        <header className="flex items-start justify-between gap-3">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-sm text-sky-200/90">
              <KindIcon kind={clue.kind} />{CLUE_KIND_FA[clue.kind] ?? 'مدرک'}
              <span className={`ev-imp ${clue.importance}`}>{IMPORTANCE_FA[clue.importance] ?? clue.importance}</span>
              {clue.team_only ? <span className="ev-imp critical">محرمانهٔ تیم شما</span> : null}
            </div>
            <h3 className="title-display mt-1 text-2xl text-slate-50">{clue.title}</h3>
            <p className="text-sm text-slate-500">{clue.round ? `کشف در دور ${clue.round}` : 'پیش‌پرونده'}{when ? ` · ساعت ${when}` : ''}</p>
          </div>
          <button onClick={onClose} className="ev-close" aria-label="بستن">×</button>
        </header>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button className="bd-filter" onClick={() => setZoom((z) => Math.max(1, +(z - 0.25).toFixed(2)))} aria-label="کوچک‌نمایی">−</button>
          <span className="font-type text-sm text-slate-400">{Math.round(zoom * 100)}٪</span>
          <button className="bd-filter" onClick={() => setZoom((z) => Math.min(2.5, +(z + 0.25).toFixed(2)))} aria-label="بزرگ‌نمایی">+</button>
          <button className="bd-filter mr-auto" onClick={runScan} disabled={scan === 'running'}>{scan === 'running' ? 'در حال اسکن...' : scan === 'done' ? 'اسکن دوباره' : 'اسکن مدرک'}</button>
        </div>

        <div className="ev-viewport">
          <div className={`ev-doc kind-${clue.kind} ${scan}`} style={{ transform: `scale(${zoom})` }}>
            {scan === 'running' ? <span className="ev-scanline" aria-hidden /> : null}
            {clue.kind === 'photo' ? (
              <div className="ev-photo">
                {clue.media_url ? (
                  <>
                    {!imgLoaded ? <span className="ev-photo-ph" aria-hidden /> : null}
                    <img src={clue.media_url} alt={clue.title} loading="lazy" decoding="async" onLoad={() => setImgLoaded(true)} className={imgLoaded ? 'on' : ''} />
                  </>
                ) : <span className="ev-photo-gen" aria-hidden><i /><i /><i /></span>}
                <span className="ev-photo-cap">{clue.title}</span>
              </div>
            ) : <div className="ev-doc-head"><span>{CLUE_KIND_FA[clue.kind] ?? 'سند'}</span><span dir="ltr">ROOM 0 / EV-{String(clue.id).padStart(3, '0')}</span></div>}
            <p className="ev-doc-text">{scan === 'done' ? highlight(clue.text, labels) : clue.text}</p>
          </div>
        </div>

        {scan === 'done' && clue.entities.length ? (
          <div className="mt-3 flex flex-wrap gap-2">
            {clue.entities.map((e, i) => <span key={i} className="chip"><b className="text-sky-300">{ENTITY_FA[e.type] ?? e.type}</b> {e.label}</span>)}
          </div>
        ) : null}

        {!data.readonly ? (
          <section className="mt-4 space-y-3">
            <div className="flex flex-wrap items-center gap-2" role="group" aria-label="وضعیت بررسی">
              {(['new', 'reviewing', 'checked'] as const).map((st) => (
                <button key={st} className={`bd-filter ${status === st ? 'on' : ''}`} disabled={saving} onClick={() => save({ status: st })}>{STATUS_FA[st]}</button>
              ))}
              <button className={`bd-filter ${clue.note?.flagged ? 'on bad' : ''}`} disabled={saving} onClick={() => save({ flagged: !clue.note?.flagged })}>
                ⚑ {clue.note?.flagged ? 'علامت‌دار' : 'علامت بزن'}
              </button>
            </div>
            <textarea className="field" rows={3} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)}
              placeholder="یادداشت شخصی شما دربارهٔ این مدرک (فقط خودتان می‌بینید)" />
            <div className="flex items-center gap-3">
              <Button variant="secondary" busy={saving} disabled={note === (clue.note?.text ?? '')} onClick={() => save({ note })}>ذخیرهٔ یادداشت</Button>
              {msg ? <span className="text-sm text-slate-400" role="status">{msg}</span> : null}
            </div>
          </section>
        ) : null}

        {related.length || linked.length ? (
          <section className="mt-4 border-t border-white/10 pt-3">
            <h4 className="mb-2 text-sm font-semibold text-slate-300">ارتباط با مدارک دیگر</h4>
            <ul className="space-y-1.5 text-sm">
              {linked.map((l) => {
                const other = l.from === clue.id ? l.to : l.from;
                return (
                  <li key={`l${l.id}`} className="flex items-center gap-2">
                    <span className={l.contradiction ? 'text-rose-300' : 'text-amber-200'}>{l.contradiction ? '⚠ تناقض' : '— وصل شده'}</span>
                    <button className="underline decoration-dotted" onClick={() => onOpen(other)}>{titleOf(other)}</button>
                    {!data.readonly ? (
                      <button className="mr-auto text-slate-500 hover:text-rose-300" aria-label="حذف اتصال"
                        onClick={async () => { await api(`/api/v1/games/${gameId}/links/${l.id}`, { method: 'DELETE' }).catch(() => undefined); onChanged(); }}>×</button>
                    ) : null}
                  </li>
                );
              })}
              {related.filter((r) => !linkedIds.has(r.from === clue.id ? r.to : r.from)).map((r, i) => {
                const other = r.from === clue.id ? r.to : r.from;
                return (
                  <li key={`r${i}`} className="flex items-center gap-2">
                    <span className="text-sky-300">◦ {ENTITY_FA[r.type] ?? r.type} مشترک: {r.label}</span>
                    <button className="underline decoration-dotted" onClick={() => onOpen(other)}>{titleOf(other)}</button>
                    {!data.readonly ? <button className="bd-filter mr-auto" onClick={() => onLink(other)}>وصل کن</button> : null}
                  </li>
                );
              })}
            </ul>
          </section>
        ) : null}
      </div>
    </div>
  );
}

function Hypotheses({ gameId, data, players, onSaved }: { gameId: number; data: BoardData; players: GamePlayer[]; onSaved: () => void }) {
  const [text, setText] = useState('');
  const [cited, setCited] = useState<number[]>([]);
  const [suspect, setSuspect] = useState<number | ''>('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const requestId = useRef(newRequestId());
  const titleOf = (id: number) => data.clues.find((c) => c.id === id)?.title ?? 'مدرک';
  const nameOf = (id: number | null) => players.find((p) => p.user_id === id)?.name;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy || text.trim().length < 3) return;
    setBusy(true);
    setError('');
    try {
      const res = await api<{ check: { verdict: string } }>(`/api/v1/games/${gameId}/hypotheses`, {
        method: 'POST', json: { request_id: requestId.current, text: text.trim(), clue_ids: cited, suspect_user_id: suspect === '' ? null : suspect },
      });
      requestId.current = newRequestId();
      setText(''); setCited([]); setSuspect('');
      sfx.play(res.check.verdict === 'conflict' ? 'alert' : 'clue');
      onSaved();
    } catch (err) {
      setError((err as Error).message); // same request id is reused on retry, so a resend never duplicates
    } finally {
      setBusy(false);
    }
  };

  const VERDICT: Record<string, [string, string]> = {
    consistent: ['شواهد ارجاعی با هم سازگارند', 'text-sky-200 border-sky-400/40'],
    conflict: ['در شواهد ارجاعی تناقض هست', 'text-rose-200 border-rose-400/50'],
    unsupported: ['بدون مدرک', 'text-slate-400 border-white/15'],
  };

  return (
    <Card kicker="THEORY" title="فرضیه‌ها">
      {!data.readonly ? (
        <form onSubmit={submit} className="space-y-3">
          <textarea className="field" rows={2} maxLength={600} value={text} onChange={(e) => setText(e.target.value)}
            placeholder="فرضیهٔ شما: چه کسی، چطور و با کدام مدرک؟" />
          <div>
            <div className="mb-1 text-sm text-slate-400">مدارک پشتیبان (حداکثر ۸)</div>
            <div className="flex flex-wrap gap-1.5">
              {data.clues.map((c) => {
                const on = cited.includes(c.id);
                return (
                  <button type="button" key={c.id} className={`bd-filter ${on ? 'on' : ''}`} aria-pressed={on}
                    onClick={() => setCited(on ? cited.filter((i) => i !== c.id) : cited.length < 8 ? [...cited, c.id] : cited)}>{c.title}</button>
                );
              })}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select className="field w-auto" value={suspect} onChange={(e) => setSuspect(e.target.value ? Number(e.target.value) : '')} aria-label="مظنون اصلی">
              <option value="">بدون مظنون مشخص</option>
              {players.map((p) => <option key={p.user_id} value={p.user_id}>{p.name}</option>)}
            </select>
            <Button type="submit" busy={busy} disabled={text.trim().length < 3}>ثبت فرضیه</Button>
          </div>
          {error ? <Alert kind="error">{error}</Alert> : null}
        </form>
      ) : null}
      {data.hypotheses.length ? (
        <ul className="mt-4 space-y-2">
          {data.hypotheses.map((h) => {
            const [label, cls] = VERDICT[h.check.verdict] ?? VERDICT.unsupported;
            return (
              <li key={h.id} className="rounded-xl border border-white/10 bg-black/30 p-3 text-sm">
                <p className="leading-7">{h.text}</p>
                <div className="mt-2 flex flex-wrap items-center gap-1.5 text-xs">
                  <span className={`rounded-full border px-2 py-0.5 ${cls}`}>{label}</span>
                  {h.suspect_user_id ? <span className="chip">مظنون: {nameOf(h.suspect_user_id)}</span> : null}
                  {h.clue_ids.map((id) => <span key={id} className="chip">{titleOf(id)}</span>)}
                </div>
              </li>
            );
          })}
        </ul>
      ) : data.readonly ? null : <p className="mt-3 text-sm text-slate-500">هنوز فرضیه‌ای ثبت نکرده‌اید.</p>}
    </Card>
  );
}
