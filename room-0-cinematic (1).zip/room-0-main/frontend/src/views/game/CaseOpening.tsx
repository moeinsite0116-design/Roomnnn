import React, { useEffect, useMemo, useRef, useState } from 'react';
import { CLUE_KIND_FA, GameState } from '../../api';
import { isLowFx, isReduced, sfx } from '../../fx';
import { haptic } from '../../ui';

/**
 * «پرونده جدید فعال شد» — the case file opening. Runs on real DOM layers (CSS 3D transforms,
 * transitions, light sweeps, fog and particles); every step is skippable and reduced-motion aware.
 */
const TIMELINE = [550, 1350, 2350, 3250, 3950, 4650, 6100, 6900]; // ms at which steps 1..8 begin
const LAST_STEP = TIMELINE.length;

export default function CaseOpening({ game, isPlayer, busy, onEnter }: {
  game: GameState; isPlayer: boolean; busy: boolean; onEnter: () => void;
}) {
  const reduced = useRef(isReduced()).current;
  const [step, setStep] = useState(reduced ? LAST_STEP : 0);
  const file = game.case;
  const rows = file?.briefing ?? [];
  const firstClue = useMemo(() => {
    const rank = { critical: 2, key: 1, normal: 0 } as Record<string, number>;
    const pub = (game.clues ?? []).filter((c) => !c.team_only);
    const round1 = pub.filter((c) => c.round >= 1);
    return [...(round1.length ? round1 : pub)].sort((a, b) => (rank[b.importance] ?? 0) - (rank[a.importance] ?? 0) || a.id - b.id)[0];
  }, [game.clues]);

  useEffect(() => {
    if (reduced) return;
    const timers = TIMELINE.map((at, i) => window.setTimeout(() => setStep(i + 1), at));
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [reduced]);

  useEffect(() => {
    if (reduced) return;
    // 1 lights · 2 folder + seal slam · 3 seal cracks · 4 cover opens, papers slide out
    // 5 title · 6 case rows · 7 first clue · 8 enter button
    if (step === 2) { sfx.play('stamp'); haptic('light'); }
    if (step === 3) { sfx.play('stamp'); haptic('warning'); }
    if (step === 4) { sfx.play('open'); window.setTimeout(() => sfx.play('page'), 260); }
    if (step === 6) rows.forEach((_, i) => window.setTimeout(() => sfx.play('page'), i * 220));
    if (step === 7) sfx.play('key');
  }, [step, reduced, rows]);

  const particles = useMemo(() => {
    const count = reduced ? 0 : isLowFx() ? 6 : 18;
    return Array.from({ length: count }, (_, i) => ({
      left: `${(i * 37 + 11) % 100}%`, size: 1 + ((i * 7) % 3), delay: `${(i * 0.73) % 6}s`, dur: `${9 + ((i * 5) % 7)}s`,
    }));
  }, [reduced]);

  const cls = Array.from({ length: step }, (_, i) => `s${i + 1}`).join(' ');
  const skip = () => setStep(LAST_STEP);

  return (
    <div className={`co ${cls}`} role="dialog" aria-modal="true" aria-label="باز شدن پرونده جدید">
      <div className="co-scene" aria-hidden>
        <div className="co-light co-light-blue" />
        <div className="co-light co-light-red" />
        <div className="co-fog" />
        <div className="co-fog co-fog-2" />
        <div className="co-desk" />
        {particles.map((p, i) => (
          <span key={i} className="co-dust" style={{ left: p.left, width: p.size, height: p.size, animationDelay: p.delay, animationDuration: p.dur }} />
        ))}
      </div>
      <div className="co-black" aria-hidden />

      <div className="co-body">
        <div className="co-stage" aria-hidden>
          <div className="co-folder">
            <div className="co-folder-back">
              <div className="co-tab">{file?.code ?? 'ROOM 0'}</div>
            </div>
            <div className="co-paper co-paper-1"><span className="co-paper-head">گزارش</span><i /><i /><i /><i /><i /></div>
            <div className="co-paper co-paper-2"><span className="co-photo" /><span className="co-photo-cap">ضمیمهٔ تصویری</span></div>
            <div className="co-paper co-paper-3"><span className="co-paper-head">یادداشت</span><i /><i /><i /></div>
            <div className="co-folder-cover">
              <div className="co-cover-face">
                <span className="co-cover-code" dir="ltr">CASE {file?.code ?? '—'}</span>
                <span className="co-cover-title">{file?.title}</span>
                <span className="co-cover-org" dir="ltr">ROOM 0 · CLASSIFIED ARCHIVE</span>
              </div>
              <div className="co-cover-inner" />
            </div>
            <div className="co-stamp">
              <span className="co-stamp-half co-stamp-a"><b>محرمانه</b><small dir="ltr">TOP SECRET</small></span>
              <span className="co-stamp-half co-stamp-b"><b>محرمانه</b><small dir="ltr">TOP SECRET</small></span>
              <span className="co-crack" />
            </div>
          </div>
        </div>

        <div className="co-info">
          <h2 className="co-title">پرونده جدید فعال شد</h2>
          <div className="co-meta">
            <span dir="ltr" className="co-code">{file?.code ?? ''}</span>
            <span className="co-name">{file?.title}</span>
          </div>
          {file?.objective ? (
            <p className="co-row co-objective" style={{ transitionDelay: '0ms' }}><b>مأموریت</b>{file.objective}</p>
          ) : null}
          <dl className="co-rows">
            {rows.map((r, i) => (
              <div key={r.label} className="co-row" style={{ transitionDelay: `${(i + 1) * 220}ms` }}>
                <dt>{r.label}</dt><dd>{r.value}</dd>
              </div>
            ))}
          </dl>
          {firstClue ? (
            <div className={`co-clue imp-${firstClue.importance}`}>
              <div className="co-clue-tag">اولین سرنخ · {CLUE_KIND_FA[firstClue.kind] ?? 'مدرک'}</div>
              <div className="co-clue-title">{firstClue.title}</div>
              <p>{firstClue.text}</p>
            </div>
          ) : null}
          <div className="co-actions">
            <button className="co-enter" onClick={() => { sfx.unlock(); sfx.play('page'); onEnter(); }} disabled={busy}>
              {busy ? '...' : 'ورود به صحنه تحقیق'}
            </button>
            {!isPlayer ? <span className="text-sm text-slate-400">شما تماشاچی هستید.</span> : null}
          </div>
        </div>
      </div>

      {step < LAST_STEP ? (
        <button className="co-skip" onClick={skip}>رد کردن انیمیشن ⟵</button>
      ) : null}
    </div>
  );
}
