import React, { useEffect, useState } from 'react';
import { ClueBrief, CLUE_KIND_FA } from '../../api';
import { isReduced, sfx } from '../../fx';
import { haptic } from '../../ui';

/** «سرنخ جدید کشف شد»: intensity scales with the clue's importance (normal < key < critical). */
export default function Discovery({ clue, remaining, onDone }: { clue: ClueBrief; remaining: number; onDone: () => void }) {
  const [phase, setPhase] = useState(isReduced() ? 3 : 0);
  useEffect(() => {
    const sound = clue.importance === 'critical' ? 'critical' : clue.importance === 'key' ? 'key' : 'clue';
    sfx.play(sound);
    haptic(clue.importance === 'critical' ? 'warning' : 'success');
    if (isReduced()) return;
    const t = [window.setTimeout(() => setPhase(1), 260), window.setTimeout(() => setPhase(2), 900), window.setTimeout(() => setPhase(3), 1500)];
    return () => t.forEach((x) => window.clearTimeout(x));
  }, [clue.id, clue.importance]);
  useEffect(() => {
    const t = window.setTimeout(onDone, clue.importance === 'critical' ? 9000 : 6500);
    return () => window.clearTimeout(t);
  }, [clue.id, clue.importance, onDone]);

  const label = clue.importance === 'critical' ? 'مدرک تعیین‌کننده کشف شد' : clue.importance === 'key' ? 'سرنخ کلیدی کشف شد' : 'سرنخ جدید کشف شد';
  return (
    <div className={`dc dc-${clue.importance} p${phase}`} role="alertdialog" aria-modal="true" aria-label={label}>
      <div className="dc-flash" aria-hidden />
      <div className="dc-card">
        <div className="dc-label">{label}</div>
        <div className="dc-kind">{CLUE_KIND_FA[clue.kind] ?? 'مدرک'}{clue.round ? ` · دور ${clue.round}` : ''}</div>
        <div className="dc-title">{clue.title}</div>
        <p className="dc-text">{clue.text}</p>
        <button className="dc-btn" onClick={onDone}>افزودن به تخته تحقیق{remaining ? ` (${remaining} مدرک دیگر)` : ''}</button>
      </div>
    </div>
  );
}
