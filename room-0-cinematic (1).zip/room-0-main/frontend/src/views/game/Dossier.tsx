import React, { useState } from 'react';
import { DossierSuspect } from '../../api';
import { Avatar, Card } from '../../ui';

/** Public interrogation record: answers, response times and contradictions with public evidence. */
export default function Dossier({ dossier, meId, onClue }: {
  dossier: DossierSuspect[]; meId: number; onClue?: (clueId: number) => void;
}) {
  const [onlyFlags, setOnlyFlags] = useState(false);
  const flagged = dossier.reduce((n, d) => n + d.entries.filter((e) => e.contradiction).length, 0);
  if (!dossier.length) return null;
  return (
    <Card kicker="INTERROGATION RECORD" title="پروندهٔ بازجویی"
      actions={flagged ? (
        <button onClick={() => setOnlyFlags(!onlyFlags)} className={`chip py-1 ${onlyFlags ? 'border-rose-400/60 text-rose-200' : ''}`}>
          ⚠ {flagged} تناقض {onlyFlags ? '· همه' : ''}
        </button>
      ) : <span className="text-sm text-slate-500">هنوز تناقضی آشکار نشده</span>}>
      <div className="grid gap-3 md:grid-cols-2">
        {dossier.map((d) => {
          const entries = d.entries.filter((e) => !onlyFlags || e.contradiction);
          if (onlyFlags && !entries.length) return null;
          return (
            <section key={d.user_id} className="dos-card">
              <header className="mb-2 flex items-center gap-2">
                <Avatar name={d.name} size="h-8 w-8" />
                <b>{d.name}{d.user_id === meId ? ' (شما)' : ''}</b>
              </header>
              <ol className="space-y-2">
                {entries.map((e) => (
                  <li key={e.step} className={`dos-entry ${e.contradiction ? 'bad' : ''}`}>
                    <div className="text-xs text-slate-400">{e.prompt}{e.follow_up ? ' · تکمیلی' : ''}</div>
                    <div className="mt-0.5">{e.skipped ? <span className="text-slate-500">بی‌پاسخ</span> : `«${e.answer}»`}</div>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                      {e.response_ms != null ? <span className="font-type text-slate-500">{(e.response_ms / 1000).toFixed(1)} ثانیه</span> : null}
                      {e.contradiction ? (
                        <button className="dos-flag" onClick={() => onClue?.(e.contradiction!.clue_id)}>
                          ⚠ در تناقض با «{e.contradiction.title}»
                        </button>
                      ) : null}
                    </div>
                  </li>
                ))}
              </ol>
            </section>
          );
        })}
      </div>
    </Card>
  );
}
