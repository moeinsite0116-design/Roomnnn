import React, { useCallback, useEffect, useState } from 'react';
import { api, STATUS_FA, TableItem } from '../api';
import { Alert, Button, Card, Spinner, useAsyncAction } from '../ui';

export default function Tables({ onOpen }: { onOpen: (tableId: number) => void }) {
  const [tables, setTables] = useState<TableItem[] | null>(null);
  const [loadError, setLoadError] = useState('');
  const [name, setName] = useState('');
  const [showSetup, setShowSetup] = useState(false);
  const [setup, setSetup] = useState({ interrogation_questions: 3, interrogation_seconds: 45, answer_seconds: 60, vote_seconds: 60 });
  const { busy, message, setMessage, run } = useAsyncAction();

  const load = useCallback(async () => {
    try {
      const data = await api<{ items: TableItem[] }>('/api/v1/tables');
      setTables(data.items);
      setLoadError('');
    } catch (e) {
      setLoadError((e as Error).message);
    }
  }, []);

  useEffect(() => {
    load();
    const t = window.setInterval(load, 15000);
    return () => window.clearInterval(t);
  }, [load]);

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) return setMessage({ kind: 'error', text: 'نام میز را وارد کنید.' });
    let createdId = 0;
    const ok = await run('create', async () => {
      createdId = (await api<TableItem>('/api/v1/tables', { method: 'POST', json: showSetup ? { name: trimmed, ...setup } : { name: trimmed } })).id;
    });
    if (ok) {
      setName('');
      onOpen(createdId);
    }
  };

  const act = (key: string, path: string, success: string, method = 'POST', json: unknown = undefined) =>
    run(key, () => api(path, { method, json }), success).then((ok) => { if (ok) load(); });

  const myTable = tables?.find((t) => t.my_reservation);

  return (
    <div className="space-y-6">
      <Card title="باز کردن پرونده‌ی جدید" kicker="NEW CASE FILE">
        <form onSubmit={create} className="flex flex-col gap-3 sm:flex-row">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={64}
            placeholder="نام میز (مثلاً: میز دوستان)"
            className="field flex-1"
          />
          <Button type="submit" busy={busy === 'create'}>ساخت و ورود</Button>
        </form>
        <button type="button" className="mt-3 text-sm text-sky-300 underline decoration-dotted" aria-expanded={showSetup} onClick={() => setShowSetup(!showSetup)}>
          {showSetup ? 'تنظیمات پیش‌فرض سرور' : 'تنظیم بازجویی و زمان‌ها'}
        </button>
        {showSetup ? (
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Range label="تعداد سؤال‌های مرحله شناسایی نفوذی‌ها" hint="۰ یعنی بدون این مرحله" min={0} max={6} value={setup.interrogation_questions}
              onChange={(v) => setSetup({ ...setup, interrogation_questions: v })} unit="سؤال" />
            <Range label="زمان هر سؤال بازجویی" min={20} max={180} step={5} value={setup.interrogation_seconds}
              onChange={(v) => setSetup({ ...setup, interrogation_seconds: v })} unit="ثانیه" />
            <Range label="زمان پاسخ هر دور" min={20} max={300} step={10} value={setup.answer_seconds}
              onChange={(v) => setSetup({ ...setup, answer_seconds: v })} unit="ثانیه" />
            <Range label="زمان رأی‌گیری" min={20} max={300} step={10} value={setup.vote_seconds}
              onChange={(v) => setSetup({ ...setup, vote_seconds: v })} unit="ثانیه" />
          </div>
        ) : null}
        <p className="mt-2 text-xs text-slate-400">هر میز ۶ بازیکن و حداکثر ۴ تماشاچی دارد. سازنده‌ی میز، میزبان است و بازی را شروع می‌کند.</p>
      </Card>

      {message ? <Alert kind={message.kind} onClose={() => setMessage(null)}>{message.text}</Alert> : null}
      {loadError ? <Alert kind="error">{loadError} <button className="underline" onClick={load}>تلاش دوباره</button></Alert> : null}

      <Card title="میزهای بازجویی" kicker="ACTIVE TABLES" actions={<Button variant="secondary" onClick={load}>به‌روزرسانی</Button>}>
        {tables === null ? <Spinner /> : tables.length === 0 ? (
          <div className="rounded-xl border border-dashed border-white/15 p-8 text-center text-slate-400"><div className="title-display text-2xl text-slate-300">پرونده‌ای باز نیست</div><p className="mt-1 text-sm">اولین میز را بسازید و بازپرس باشید.</p></div>
        ) : (
          <ul className="space-y-3">
            {tables.map((t, i) => {
              const mine = t.my_reservation;
              const canReserve = t.status === 'waiting' && !mine && !myTable && t.available_seats > 0 && !t.is_spectating;
              return (
                <li key={t.id} style={{ animationDelay: `${Math.min(i, 8) * 60}ms` }} className={`group relative flex animate-rise flex-col gap-3 overflow-hidden rounded-xl border bg-black/35 p-4 transition hover:-translate-y-0.5 md:flex-row md:items-center md:justify-between ${mine ? 'border-amber-300/50 shadow-gold' : 'border-white/10 hover:border-amber-300/30'}`}>
                  <span className="pointer-events-none absolute inset-y-0 right-0 w-1 bg-gradient-to-b from-amber-300 via-rose-500 to-transparent opacity-70" />
                  <div>
                    <div className="flex items-center gap-2 text-lg font-semibold"><span className="font-type text-xs text-slate-500" dir="ltr">#{String(t.id).padStart(3, '0')}</span>
                      {t.name}
                      <span className={`chip ${t.status === 'waiting' ? 'text-teal-200' : 'text-rose-200'}`}><span className={`h-1.5 w-1.5 rounded-full ${t.status === 'waiting' ? 'bg-teal-300' : 'animate-pulse bg-rose-400'}`} />
                        {STATUS_FA[t.status] ?? t.status}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center gap-1" aria-label={`صندلی خالی: ${t.available_seats} از ${t.max_players}`}>
                      {Array.from({ length: t.max_players }, (_, k) => (
                        <span key={k} className={`h-2.5 w-6 rounded-sm ${k < t.max_players - t.available_seats ? 'bg-gradient-to-l from-amber-300 to-amber-600 shadow-gold' : 'bg-white/10'}`} />
                      ))}
                      <span className="mr-2 text-xs text-slate-400">{t.max_players - t.available_seats}/{t.max_players} • تماشاچی {t.spectators}/{t.spectator_capacity}</span>
                    </div>
                    {mine ? (
                      <div className="mt-2 text-sm text-amber-200">
                        صندلی شما: {mine.seat_index} — {mine.status === 'confirmed' ? 'حضور تأیید شده' : 'منتظر تأیید حضور'}
                      </div>
                    ) : null}
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {canReserve ? (
                      <Button busy={busy === `r${t.id}`} onClick={() => act(`r${t.id}`, `/api/v1/tables/${t.id}/reserve`, `صندلی روی «${t.name}» رزرو شد؛ حضورتان را تأیید کنید.`, 'POST', {})}>رزرو صندلی</Button>
                    ) : null}
                    {t.status === 'waiting' && !mine && t.available_seats === 0 ? (
                      <Button variant="secondary" busy={busy === `w${t.id}`} onClick={() => act(`w${t.id}`, `/api/v1/tables/${t.id}/waitlist`, 'به صف انتظار اضافه شدید.')}>صف انتظار</Button>
                    ) : null}
                    {!mine && !t.is_spectating && t.spectators < t.spectator_capacity ? (
                      <Button variant="secondary" busy={busy === `s${t.id}`} onClick={() => run(`s${t.id}`, () => api(`/api/v1/tables/${t.id}/spectate`, { method: 'POST' })).then((ok) => ok && onOpen(t.id))}>تماشا</Button>
                    ) : null}
                    {mine || t.is_spectating ? <Button variant="success" onClick={() => onOpen(t.id)}>ورود به اتاق</Button> : null}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Range({ label, hint, min, max, step = 1, value, unit, onChange }: {
  label: string; hint?: string; min: number; max: number; step?: number; value: number; unit: string; onChange: (v: number) => void;
}) {
  return (
    <label className="block rounded-xl border border-white/10 bg-black/30 p-3 text-sm">
      <span className="flex justify-between gap-2"><span>{label}</span><b className="font-type text-sky-200">{value} {unit}</b></span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="mt-2 w-full accent-sky-400" />
      {hint ? <span className="text-xs text-slate-500">{hint}</span> : null}
    </label>
  );
}
