import React from 'react';
import { MotionPref, sfx, usePrefs } from '../fx';
import { Card } from '../ui';

/** Sound, ambient and motion preferences. Stored on this device only; the game works fully with everything off. */
export default function FxSettings() {
  const [prefs, save] = usePrefs();
  const MOTION: [MotionPref, string][] = [['auto', 'خودکار (طبق تنظیم گوشی)'], ['reduced', 'کاهش انیمیشن‌ها'], ['full', 'کامل']];
  return (
    <Card kicker="EFFECTS" title="صدا و جلوه‌ها">
      <div className="space-y-2">
        <Toggle label="افکت‌های صوتی (پوشه، ورق، کشف، هشدار)" on={prefs.sound}
          onChange={(v) => { save({ ...prefs, sound: v }); if (v) { sfx.unlock(); sfx.play('clue'); } }} />
        <Toggle label="صدای محیطی کم‌حجم هنگام بازی" on={prefs.ambient} disabled={!prefs.sound}
          onChange={(v) => { save({ ...prefs, ambient: v }); sfx.unlock(); }} />
        <div className="fx-toggle flex-col items-stretch">
          <span>حرکت و انیمیشن</span>
          <div className="mt-2 flex flex-wrap gap-2" role="radiogroup" aria-label="حرکت و انیمیشن">
            {MOTION.map(([k, label]) => (
              <button key={k} role="radio" aria-checked={prefs.motion === k} className={`bd-filter ${prefs.motion === k ? 'on' : ''}`}
                onClick={() => save({ ...prefs, motion: k })}>{label}</button>
            ))}
          </div>
        </div>
        <p className="text-sm text-slate-500">صداها با Web Audio ساخته می‌شوند و فقط بعد از اولین لمس شما پخش می‌شوند. «کامل» حالت کم‌مصرف خودکار را هم خاموش می‌کند.</p>
      </div>
    </Card>
  );
}

function Toggle({ label, on, disabled, onChange }: { label: string; on: boolean; disabled?: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className={`fx-toggle ${disabled ? 'opacity-50' : ''}`}>
      <span>{label}</span>
      <button type="button" role="switch" aria-checked={on} aria-label={label} className="fx-switch" disabled={disabled} onClick={() => onChange(!on)} />
    </label>
  );
}

/** Compact mute button for the header. */
export function SoundButton() {
  const [prefs, save] = usePrefs();
  return (
    <button type="button" onClick={() => { save({ ...prefs, sound: !prefs.sound }); if (!prefs.sound) { sfx.unlock(); sfx.play('tick'); } }}
      className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-black/30 text-slate-200 hover:border-sky-400/50"
      aria-label={prefs.sound ? 'خاموش کردن صدا' : 'روشن کردن صدا'} aria-pressed={prefs.sound} title={prefs.sound ? 'صدا روشن' : 'صدا خاموش'}>
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <path d="M4 9h4l5-4v14l-5-4H4z" />
        {prefs.sound ? <path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11" /> : <path d="M17 9l5 6M22 9l-5 6" />}
      </svg>
    </button>
  );
}
