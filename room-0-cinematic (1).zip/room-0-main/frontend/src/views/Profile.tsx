import React, { useEffect, useState } from 'react';
import { api, displayName, Me, ROLE_FA, STAFF_ROLE_FA, STATUS_FA, WINNER_FA } from '../api';
import { Alert, Button, Card, Spinner, useAsyncAction } from '../ui';
import FxSettings from './FxSettings';

interface HistoryItem { game_id: number; status: string; winner: string | null; role: string; won: boolean; finished_at: string | null }

export function Profile({ me, onUpdated }: { me: Me; onUpdated: (m: Me) => void }) {
  const [name, setName] = useState(me.display_name ?? '');
  const { busy, message, setMessage, run } = useAsyncAction();
  const rate = me.games_played ? Math.round((me.games_won / me.games_played) * 100) : 0;
  return (
    <div className="space-y-4">
    <Card title="پروفایل">
      {message ? <Alert kind={message.kind} onClose={() => setMessage(null)}>{message.text}</Alert> : null}
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="بازی‌ها" value={me.games_played} />
        <Stat label="بردها" value={me.games_won} />
        <Stat label="درصد برد" value={`${rate}٪`} />
      </div>
      <dl className="mt-4 grid gap-2 text-sm text-slate-300 sm:grid-cols-2">
        <div>نام: <b>{displayName(me)}</b></div>
        <div>نام کاربری تلگرام: {me.username ? `@${me.username}` : '—'}</div>
        <div>سطح دسترسی: {STAFF_ROLE_FA[me.role] ?? me.role}</div>
        <div>عضویت از: {me.created_at ? new Date(me.created_at + 'Z').toLocaleDateString('fa-IR') : '—'}</div>
      </dl>
      <form className="mt-4 flex flex-col gap-2 sm:flex-row" onSubmit={(e) => {
        e.preventDefault();
        run('save', async () => onUpdated(await api<Me>('/api/v1/users/me', { method: 'PATCH', json: { display_name: name.trim() } })), 'نام نمایشی ذخیره شد.');
      }}>
        <input value={name} onChange={(e) => setName(e.target.value)} maxLength={32} placeholder="نام نمایشی در بازی"
          className="field flex-1" />
        <Button type="submit" busy={busy === 'save'} disabled={!name.trim()}>ذخیره</Button>
      </form>
    </Card>
    <FxSettings />
    </div>
  );
}

export function History() {
  const [items, setItems] = useState<HistoryItem[] | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    api<{ items: HistoryItem[] }>('/api/v1/users/me/games').then((d) => setItems(d.items)).catch((e) => setError(e.message));
  }, []);
  return (
    <Card title="تاریخچه‌ی بازی‌ها">
      {error ? <Alert kind="error">{error}</Alert> : items === null ? <Spinner /> : items.length === 0 ? (
        <p className="text-slate-400">هنوز بازی تمام‌شده‌ای ندارید.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="text-slate-400"><tr><th className="p-2">بازی</th><th className="p-2">نقش شما</th><th className="p-2">برنده</th><th className="p-2">نتیجه</th><th className="p-2">تاریخ</th></tr></thead>
            <tbody>
              {items.map((g) => (
                <tr key={g.game_id} className="border-t border-slate-800">
                  <td className="p-2">#{g.game_id}</td>
                  <td className="p-2">{ROLE_FA[g.role] ?? g.role}</td>
                  <td className="p-2">{g.status === 'aborted' ? STATUS_FA.aborted : WINNER_FA[g.winner ?? 'draw']}</td>
                  <td className={`p-2 ${g.won ? 'text-emerald-300' : 'text-slate-300'}`}>{g.status === 'aborted' ? '—' : g.won ? 'برد' : g.winner === 'draw' ? 'مساوی' : 'باخت'}</td>
                  <td className="p-2">{g.finished_at ? new Date(g.finished_at + 'Z').toLocaleString('fa-IR') : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

export function Stat({ label, value, tone = 'text-amber-200' }: { label: string; value: React.ReactNode; tone?: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-black/30 p-4">
      <div className="text-sm text-slate-400">{label}</div>
      <div className={`mt-2 title-display text-3xl ${tone}`}>{value}</div>
    </div>
  );
}
