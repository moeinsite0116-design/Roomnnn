import React from 'react';
import ReactDOM from 'react-dom/client';
import '@fontsource-variable/vazirmatn';
import '@fontsource/lalezar/arabic-400.css';
import '@fontsource/lalezar/latin-400.css';
import '@fontsource/special-elite/latin-400.css';
import App from './App';
import { applyPrefs, installAudioUnlock, loadPrefs } from './fx';
import './index.css';

applyPrefs(loadPrefs());
installAudioUnlock();
window.matchMedia?.('(prefers-reduced-motion: reduce)').addEventListener?.('change', () => applyPrefs(loadPrefs()));

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
