from __future__ import annotations

from typing import Annotated, Literal
from urllib.parse import urlsplit

from pydantic import AliasChoices, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore', populate_by_name=True)

    app_name: str = 'ROOM 0'
    environment: Literal['development', 'staging', 'production'] = 'development'
    debug: bool = False
    backend_host: str = '0.0.0.0'
    backend_port: int = 8000
    jwt_secret_key: str = 'change-me'
    telegram_bot_token: str = Field(default='', validation_alias=AliasChoices('BOT_TOKEN', 'TELEGRAM_BOT_TOKEN'))
    telegram_bot_username: str = Field(default='', validation_alias=AliasChoices('BOT_USERNAME', 'TELEGRAM_BOT_USERNAME'))
    telegram_webhook_path: str = '/telegram/webhook'
    telegram_app_url: str = ''
    bot_api_secret: str = ''
    telegram_allowed_origins: Annotated[list[str], NoDecode] = Field(default_factory=lambda: ['https://example.com'])
    database_url: str = 'postgresql+psycopg://postgres:postgres@localhost:5432/room0'
    redis_url: str = 'redis://localhost:6379/0'
    livekit_url: str = 'wss://livekit.example.com'
    livekit_api_key: str = 'devkey'
    livekit_api_secret: str = 'devsecret'
    cors_origins: Annotated[list[str], NoDecode] = Field(default_factory=lambda: ['http://localhost:5173'])
    admin_email: str = 'admin@example.com'
    admin_username: str = 'room0admin'
    enable_livekit: bool = False
    enable_demo_mode: bool = False
    enable_rewards: bool = False
    timezone: str = 'Asia/Tehran'
    app_version: str = '0.1.0'
    security_headers_enabled: bool = True
    rate_limit_per_minute: int = 60
    login_rate_limit_per_minute: int = 10
    sensitive_rate_limit_per_minute: int = 90
    log_level: str = 'INFO'
    init_data_max_age_seconds: int = 3600
    access_token_expire_minutes: int = 720
    backup_dir: str = './backups'
    init_data_max_uses: int = 5
    min_players: int = 6
    answer_phase_seconds: int = 60
    vote_phase_seconds: int = 60
    reservation_ttl_minutes: int = 10
    interrogation_questions_default: int = 3   # steps per player in «مرحله شناسایی نفوذی‌ها»; 0 disables it
    interrogation_seconds: int = 45
    briefing_seconds: int = 40               # case-file opening; ends early when every player is ready
    max_open_tables_per_user: int = 3
    enable_game_ticker: bool = True
    ws_idle_timeout_seconds: int = 70
    ws_max_message_bytes: int = 2048
    ws_rate_limit_messages: int = 20       # per 10 seconds per connection
    ws_auth_timeout_seconds: int = 10
    realtime_use_redis: bool = False       # fan-out across several workers via Redis pub/sub
    super_admin_telegram_ids: Annotated[list[int], NoDecode] = Field(
        default_factory=list, validation_alias=AliasChoices('ADMIN_IDS', 'SUPER_ADMIN_TELEGRAM_IDS'))

    @field_validator('cors_origins', 'telegram_allowed_origins', 'super_admin_telegram_ids', mode='before')
    @classmethod
    def _split_csv(cls, value):
        # .env uses comma-separated values (see .env.example); JSON lists also work.
        if isinstance(value, str):
            value = value.strip()
            if value.startswith('['):
                import json

                return json.loads(value)
            return [item.strip() for item in value.split(',') if item.strip()]
        return value

    @field_validator('min_players')
    @classmethod
    def _fixed_game_size(cls, value: int) -> int:
        # Current role distribution and seat schema are explicitly designed for six players.
        if value != 6:
            raise ValueError('MIN_PLAYERS must be 6 until variable-size game rules are implemented')
        return value

    @model_validator(mode='after')
    def _forbid_default_secrets_in_production(self) -> 'Settings':
        if self.environment == 'production':
            weak = {
                'jwt_secret_key': {'change-me', 'replace-with-strong-secret', ''},
                'telegram_bot_token': {'replace-me', 'replace-with-bot-token', ''},
            }
            for field, bad in weak.items():
                value = getattr(self, field)
                if value in bad or (field == 'jwt_secret_key' and len(value) < 32):
                    raise ValueError(f'{field} must be set to a strong real value in production')
            if self.debug:
                raise ValueError('DEBUG must be false in production')
            if self.enable_demo_mode:
                raise ValueError('ENABLE_DEMO_MODE must be false in production')
            app_url = urlsplit(self.telegram_app_url)
            if app_url.scheme != 'https' or not app_url.netloc or app_url.username or app_url.password:
                raise ValueError('TELEGRAM_APP_URL must be a valid HTTPS URL in production')
            app_origin = f'{app_url.scheme}://{app_url.netloc}'
            if app_origin not in self.cors_origins or app_origin not in self.telegram_allowed_origins:
                raise ValueError('TELEGRAM_APP_URL origin must be listed in CORS_ORIGINS and TELEGRAM_ALLOWED_ORIGINS')
            if not self.telegram_bot_username.strip('@'):
                raise ValueError('BOT_USERNAME must be configured in production')
            if not self.bot_api_secret or len(self.bot_api_secret) < 32:
                raise ValueError('BOT_API_SECRET must be at least 32 characters in production')
            for origin in [*self.cors_origins, *self.telegram_allowed_origins]:
                parsed = urlsplit(origin)
                if parsed.scheme not in {'https', 'http'} or not parsed.netloc or parsed.path not in {'', '/'} or '*' in origin:
                    raise ValueError('Origins must be explicit scheme + host values; wildcards are forbidden in production')
        return self


settings = Settings()
