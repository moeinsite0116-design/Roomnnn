from __future__ import annotations

import hashlib
import hmac
import json
from datetime import datetime, timezone
from datetime import timedelta
from typing import Any

import jwt
from urllib.parse import parse_qsl

from app.core.config import settings


def validate_telegram_init_data(init_data: str, bot_token: str) -> dict[str, Any]:
    """Validate Telegram Mini App initData according to Telegram rules."""
    if not init_data or not bot_token:
        raise ValueError('Telegram initData or bot token is missing')

    pairs = parse_qsl(init_data, keep_blank_values=True, strict_parsing=True)
    keys = [key for key, _ in pairs]
    if len(keys) != len(set(keys)):
        raise ValueError('duplicate initData fields')
    fields: dict[str, str] = dict(pairs)

    if 'hash' not in fields or len(fields['hash']) != 64:
        raise ValueError('hash is missing or malformed in initData')
    if any(c not in '0123456789abcdefABCDEF' for c in fields['hash']):
        raise ValueError('hash is malformed in initData')

    provided_hash = fields.pop('hash')
    data_check_string = '\n'.join(f'{k}={fields[k]}' for k in sorted(fields.keys()))
    # Telegram spec: secret = HMAC_SHA256(key="WebAppData", msg=bot_token)
    secret_key = hmac.new(b'WebAppData', bot_token.encode('utf-8'), hashlib.sha256).digest()
    calc_hash = hmac.new(secret_key, data_check_string.encode('utf-8'), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(calc_hash, provided_hash):
        raise ValueError('invalid initData signature')

    auth_date = fields.get('auth_date')
    if auth_date is None:
        raise ValueError('auth_date is missing')
    try:
        ts = int(auth_date)
    except ValueError as exc:
        raise ValueError('auth_date is not valid') from exc
    now = datetime.now(timezone.utc).timestamp()
    if ts > now + 30:
        raise ValueError('auth_date is in the future')
    if now - ts > settings.init_data_max_age_seconds:
        raise ValueError('initData has expired')

    parsed: dict[str, Any] = {}
    for key, value in fields.items():
        try:
            parsed[key] = json.loads(value)
        except json.JSONDecodeError:
            parsed[key] = value

    return parsed


JWT_ALGORITHM = 'HS256'


def create_access_token(user_id: int, jti: str, expires_delta: timedelta | None = None) -> tuple[str, datetime]:
    """Return (token, expires_at as naive UTC)."""
    delta = expires_delta or timedelta(minutes=settings.access_token_expire_minutes)
    expires_at = datetime.now(timezone.utc) + delta
    payload = {'sub': str(user_id), 'jti': jti, 'exp': expires_at, 'iat': datetime.now(timezone.utc)}
    token = jwt.encode(payload, settings.jwt_secret_key, algorithm=JWT_ALGORITHM)
    return token, expires_at.replace(tzinfo=None)


def decode_access_token(token: str) -> dict[str, Any]:
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key,
            algorithms=[JWT_ALGORITHM],
            options={'require': ['exp', 'sub', 'jti']},
        )
    except jwt.PyJWTError as exc:
        raise ValueError('invalid token') from exc
    return payload
