from __future__ import annotations

PLAYER = 'player'
ANALYST = 'analyst'          # Read-only Analyst
SUPPORT = 'support'
MODERATOR = 'moderator'
GAME_ADMIN = 'game_admin'
SUPER_ADMIN = 'super_admin'

ALL_ROLES = (PLAYER, ANALYST, SUPPORT, MODERATOR, GAME_ADMIN, SUPER_ADMIN)
STAFF_ROLES = (ANALYST, SUPPORT, MODERATOR, GAME_ADMIN, SUPER_ADMIN)


def is_staff(role: str) -> bool:
    return role in STAFF_ROLES
