from __future__ import annotations

import logging
import re
from collections import deque
from datetime import datetime, timezone

from app.core.config import settings

# Never let tokens / initData / hashes reach the logs.
_SECRET_PATTERNS = [
    (re.compile(r'(\d{6,}:[A-Za-z0-9_-]{30,})'), '[REDACTED_BOT_TOKEN]'),
    (re.compile(r'(?i)(hash=)[0-9a-f]{32,}'), r'\1[REDACTED]'),
    (re.compile(r'(?i)(x-telegram-init-data["\':= ]+)[^\s"\']+'), r'\1[REDACTED]'),
    (re.compile(r'(?i)(bearer\s+)[A-Za-z0-9._-]+'), r'\1[REDACTED]'),
    (re.compile(r'(?i)(init_data["\':= ]+)[^\s"\']+'), r'\1[REDACTED]'),
]

# Last important log records (already redacted), shown to staff in the admin panel.
recent_errors: deque[dict[str, str]] = deque(maxlen=200)


def redact(message: str) -> str:
    for pattern, repl in _SECRET_PATTERNS:
        message = pattern.sub(repl, message)
    return message


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg, record.args = redact(record.getMessage()), ()
        return True


class RecentErrorsHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        recent_errors.append({
            'at': datetime.now(timezone.utc).replace(tzinfo=None).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': redact(record.getMessage())[:500],
            'error': record.exc_info[0].__name__ if record.exc_info and record.exc_info[0] else '',
        })


def setup_logging() -> None:
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    )
    root = logging.getLogger()
    for handler in root.handlers:
        handler.addFilter(RedactingFilter())
    if not any(isinstance(h, RecentErrorsHandler) for h in root.handlers):
        errors = RecentErrorsHandler(level=logging.WARNING)
        root.addHandler(errors)
