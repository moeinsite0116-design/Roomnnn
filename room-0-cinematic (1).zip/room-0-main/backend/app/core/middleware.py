from __future__ import annotations

from collections import defaultdict, deque
from time import monotonic

from fastapi import Request
from fastapi.responses import JSONResponse

from app.core.config import settings

api_rate_limit: dict[tuple[str, str], deque[float]] = defaultdict(deque)


def reset_rate_limit() -> None:  # tests
    api_rate_limit.clear()


async def security_headers_middleware(request: Request, call_next):
    if settings.security_headers_enabled:
        response = await call_next(request)
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
        response.headers['Cache-Control'] = 'no-store'
        return response
    return await call_next(request)


async def rate_limit_middleware(request: Request, call_next):
    if request.url.path.startswith('/api/'):
        client_key = request.client.host if request.client else 'unknown'
        path = request.url.path
        if path == '/api/v1/auth/telegram':
            bucket, limit = 'login', settings.login_rate_limit_per_minute
        elif request.method in {'POST', 'PUT', 'PATCH', 'DELETE'} and path.startswith(
            ('/api/v1/tables', '/api/v1/games', '/api/v1/admin', '/api/v1/bot')
        ):
            bucket, limit = 'sensitive-write', settings.sensitive_rate_limit_per_minute
        else:
            bucket, limit = 'api', settings.rate_limit_per_minute
        key = (client_key, bucket)
        now = monotonic()
        window = api_rate_limit[key]
        while window and now - window[0] > 60:
            window.popleft()
        if len(api_rate_limit) > 10_000:  # drop idle clients so the dict cannot grow without bound
            for old_key in [k for k, w in api_rate_limit.items() if not w or now - w[-1] > 60]:
                api_rate_limit.pop(old_key, None)
            window = api_rate_limit[key]
        if len(window) >= limit:
            return JSONResponse(status_code=429, content={'detail': 'Rate limit exceeded'})
        window.append(now)
    return await call_next(request)
