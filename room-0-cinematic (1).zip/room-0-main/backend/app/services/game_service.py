"""ROOM 0 game engine. All rules run on the server; the client only sends intents.

Rules are documented in docs/game_rules.md (extracted from the original source + explicit contract
for what the source left undefined). Every state transition is a compare-and-set UPDATE, so
concurrent / repeated requests can never apply a transition twice.
"""
from __future__ import annotations

import json
import random
import secrets
from collections import Counter
from datetime import datetime, timedelta
from typing import Any

from fastapi import HTTPException
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import roles as app_roles
from app.core.config import settings
from app.services.realtime import schedule_notify
from app.db.models import (
    CaseModel,
    Clue,
    Game,
    GameAnswer,
    GameClue,
    GameEvent,
    GamePlayer,
    GameVote,
    InterrogationAnswer,
    Question,
    Reservation,
    TableModel,
    User,
)
from app.services.investigation_rules import (
    QuestionView,
    clue_visible_to,
    detect_contradiction,
    interrogation_total,
    parse_json_list,
    public_options,
    select_interrogation_question,
)

# ---------------------------------------------------------------- rules / constants
ROLE_SET: tuple[str, ...] = ('detective', 'detective', 'detective', 'spy', 'spy', 'independent')
TEAM_OF = {'detective': 'detectives', 'spy': 'infiltrators', 'independent': 'alliance'}
WINNING_ROLE = {'detectives': 'detective', 'spies': 'spy', 'independent': 'independent'}
INFILTRATORS_KNOW_EACH_OTHER = True
REVEAL_ROLE_ON_ELIMINATION = True


def utcnow() -> datetime:
    return datetime.utcnow()


# ---------------------------------------------------------------- pure rules (unit-testable)
def assign_roles(user_ids: list[int], rng: random.Random | None = None) -> dict[int, str]:
    """Secure random role assignment; the role set is fixed by the 6-player rules."""
    if len(user_ids) != len(ROLE_SET):
        raise ValueError(f'exactly {len(ROLE_SET)} players required')
    roles = list(ROLE_SET)
    (rng or random.SystemRandom()).shuffle(roles)
    return dict(zip(user_ids, roles))


def tally_votes(votes: dict[int, int]) -> int | None:
    """Plurality. A tie for first place (or no votes) eliminates nobody."""
    if not votes:
        return None
    counts = Counter(votes.values()).most_common()
    if len(counts) > 1 and counts[0][1] == counts[1][1]:
        return None
    return counts[0][0]


def determine_game_winner(players: list[dict[str, Any]]) -> str | None:
    """Returns 'detectives' | 'spies' | 'independent' | 'draw' | None (game continues)."""
    alive = [p for p in players if p.get('is_alive', True)]
    if not alive:
        return 'draw'
    spies = sum(1 for p in alive if p.get('role_name') == 'spy')
    if spies == 0:
        if any(p.get('role_name') == 'detective' for p in alive):
            return 'detectives'
        return 'independent'
    if spies >= len(alive) - spies:
        return 'spies'
    return None


# ---------------------------------------------------------------- helpers
async def _fresh_game(db: AsyncSession, game_id: int) -> Game | None:
    result = await db.execute(select(Game).where(Game.id == game_id).execution_options(populate_existing=True))
    return result.scalar_one_or_none()


async def _players(db: AsyncSession, game_id: int) -> list[GamePlayer]:
    result = await db.execute(
        select(GamePlayer)
        .where(GamePlayer.game_id == game_id, GamePlayer.is_spectator.is_(False))
        .order_by(GamePlayer.id)
        .execution_options(populate_existing=True)
    )
    return list(result.scalars().all())


async def _questions(db: AsyncSession, case_id: int | None) -> list[Question]:
    """Round (discussion + vote) questions. Interrogation questions are a separate pool."""
    if case_id is None:
        return []
    result = await db.execute(
        select(Question).where(Question.case_id == case_id, Question.stage != 'interrogation')
        .order_by(Question.order_index, Question.id)
    )
    return list(result.scalars().all())


async def _interrogation_pool(db: AsyncSession, case_id: int | None) -> list[Question]:
    if case_id is None:
        return []
    result = await db.execute(
        select(Question).where(Question.case_id == case_id, Question.stage == 'interrogation')
        .order_by(Question.order_index, Question.id)
    )
    return list(result.scalars().all())


def _qview(q: Question) -> QuestionView:
    return QuestionView(id=q.id, order_index=q.order_index, kind=q.kind or 'text', requires_clue_id=q.requires_clue_id,
                        follow_up_of_id=q.follow_up_of_id, follow_up_option=q.follow_up_option)


# ---------------------------------------------------------------- per-game settings
SETTING_BOUNDS = {
    'interrogation_questions': (0, 6),
    'interrogation_seconds': (20, 180),
    'answer_seconds': (20, 300),
    'vote_seconds': (20, 300),
}


def default_table_settings() -> dict[str, int]:
    return {
        'interrogation_questions': settings.interrogation_questions_default,
        'interrogation_seconds': settings.interrogation_seconds,
        'answer_seconds': settings.answer_phase_seconds,
        'vote_seconds': settings.vote_phase_seconds,
    }


def table_settings(table: TableModel) -> dict[str, int]:
    cfg = default_table_settings()
    try:
        stored = json.loads(table.settings_json) if table.settings_json else {}
    except ValueError:
        stored = {}
    for key, (low, high) in SETTING_BOUNDS.items():
        value = stored.get(key) if isinstance(stored, dict) else None
        if isinstance(value, int) and not isinstance(value, bool):
            cfg[key] = max(low, min(high, value))
    return cfg


def game_settings(game: Game) -> dict[str, int]:
    cfg = default_table_settings()
    cfg.update({'briefing_seconds': settings.briefing_seconds, 'interrogation_total': 0})
    try:
        stored = json.loads(game.settings_json) if game.settings_json else {}
    except ValueError:
        stored = {}
    if isinstance(stored, dict):
        cfg.update({k: v for k, v in stored.items() if isinstance(v, int) and not isinstance(v, bool)})
    return cfg


# ---------------------------------------------------------------- clue discovery
async def _discover_clues(db: AsyncSession, game: Game, round_no: int, now: datetime) -> list[int]:
    """Record every clue unlocked up to `round_no` (idempotent; called from CAS-winning transitions)."""
    if game.case_id is None:
        return []
    clues = (await db.execute(
        select(Clue).where(Clue.case_id == game.case_id, func.coalesce(Clue.unlock_round, 0) <= round_no)
        .order_by(Clue.order_index, Clue.id)
    )).scalars().all()
    known = set((await db.execute(select(GameClue.clue_id).where(GameClue.game_id == game.id))).scalars().all())
    new_public: list[int] = []
    for clue in clues:
        if clue.id in known:
            continue
        db.add(GameClue(game_id=game.id, clue_id=clue.id, round_no=round_no, discovered_at=now))
        if clue.visibility == 'public':
            new_public.append(clue.id)
    if new_public:  # events are public: team-only clues are never named here
        _event(db, game.id, 'clue.discovered', {'round': round_no, 'clue_ids': new_public})
    return new_public


async def _visible_clues(db: AsyncSession, game: Game, team: str | None) -> list[tuple[Clue, GameClue]]:
    rows = (await db.execute(
        select(Clue, GameClue).join(GameClue, GameClue.clue_id == Clue.id)
        .where(GameClue.game_id == game.id).order_by(GameClue.discovered_at, Clue.order_index, Clue.id)
    )).all()
    over = game.status != 'started'
    return [(c, g) for c, g in rows if clue_visible_to(c.visibility or 'public', team, game_over=over)]


async def _public_clue_ids(db: AsyncSession, game: Game) -> set[int]:
    return {c.id for c, _ in await _visible_clues(db, game, None) if (c.visibility or 'public') == 'public'}


def _event(db: AsyncSession, game_id: int, type_: str, payload: dict[str, Any]) -> None:
    db.add(GameEvent(game_id=game_id, type=type_, payload=json.dumps(payload, ensure_ascii=False)))


def _name(user: User) -> str:
    return user.display_name or user.first_name or user.username or f'player-{user.id}'


# ---------------------------------------------------------------- demo content
async def seed_demo_case(db: AsyncSession) -> CaseModel:
    """Development only (ENABLE_DEMO_MODE): installs the bundled curated case once (idempotent by slug)."""
    from app.services.case_loader import load_case_file

    return await load_case_file(db, published=True)


async def _pick_case(db: AsyncSession, case_id: int | None) -> CaseModel:
    query = select(CaseModel).where(CaseModel.is_published.is_(True), CaseModel.is_deleted.is_(False))
    if case_id is not None:
        query = query.where(CaseModel.id == case_id)
    cases = list((await db.execute(query)).scalars().all())
    usable = []
    for case in cases:
        if await _questions(db, case.id):
            usable.append(case)
    if usable:
        return secrets.choice(usable)
    if case_id is None and settings.enable_demo_mode:
        return await seed_demo_case(db)
    raise HTTPException(status_code=409, detail='No published case with questions is available')


# ---------------------------------------------------------------- lifecycle
async def start_game(db: AsyncSession, table_id: int, user: User, case_id: int | None = None) -> Game:
    table = (await db.execute(
        select(TableModel).where(TableModel.id == table_id).with_for_update()
    )).scalar_one_or_none()
    if table is None:
        raise HTTPException(status_code=404, detail='Table not found')
    privileged = user.role in (app_roles.GAME_ADMIN, app_roles.SUPER_ADMIN)
    if table.host_user_id != user.id and not privileged:
        raise HTTPException(status_code=403, detail='Only the table host can start the game')

    reservations = list(
        (
            await db.execute(
                select(Reservation).where(Reservation.table_id == table_id, Reservation.status == 'confirmed')
                .order_by(Reservation.seat_index)
            )
        ).scalars().all()
    )
    if len(reservations) != settings.min_players:
        raise HTTPException(
            status_code=409,
            detail=f'Exactly {settings.min_players} confirmed players are required (have {len(reservations)})',
        )

    case = await _pick_case(db, case_id)

    claimed = await db.execute(
        update(TableModel).where(TableModel.id == table_id, TableModel.status == 'waiting').values(status='playing')
    )
    if claimed.rowcount != 1:
        raise HTTPException(status_code=409, detail='Table is not waiting for a game')

    now = utcnow()
    cfg = table_settings(table)
    pool = [_qview(q) for q in await _interrogation_pool(db, case.id)]
    cfg['interrogation_total'] = interrogation_total(pool, cfg['interrogation_questions'])
    cfg['briefing_seconds'] = settings.briefing_seconds
    if cfg['interrogation_total'] > 0:
        phase, round_no, deadline, index = 'interrogation', 0, now + timedelta(seconds=cfg['interrogation_seconds']), 1
    elif cfg['briefing_seconds'] > 0:
        phase, round_no, deadline, index = 'briefing', 0, now + timedelta(seconds=cfg['briefing_seconds']), 0
    else:  # legacy flow: straight into round 1
        phase, round_no, deadline, index = 'answer', 1, now + timedelta(seconds=cfg['answer_seconds']), 0
    game = Game(
        table_id=table_id, case_id=case.id, status='started', phase=phase, round_no=round_no,
        phase_deadline=deadline, started_at=now, phase_started_at=now, interrogation_index=index,
        settings_json=json.dumps(cfg),
    )
    db.add(game)
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail='A game is already running at this table')

    assigned = assign_roles([r.user_id for r in reservations])
    for reservation in reservations:
        role = assigned[reservation.user_id]
        db.add(GamePlayer(game_id=game.id, user_id=reservation.user_id, role_name=role,
                          team=TEAM_OF[role], is_alive=True, is_spectator=False))
    _event(db, game.id, 'game.started', {'case_id': case.id, 'players': [r.user_id for r in reservations]})
    if phase == 'interrogation':
        await _discover_clues(db, game, 0, now)
        _event(db, game.id, 'phase.interrogation', {'step': 1, 'total': cfg['interrogation_total']})
    elif phase == 'briefing':
        await _discover_clues(db, game, 1, now)
        _event(db, game.id, 'phase.briefing', {})
    else:
        await _discover_clues(db, game, 1, now)
        _event(db, game.id, 'phase.answer', {'round': 1})
    await db.commit()
    schedule_notify(table_id)
    return await _fresh_game(db, game.id)  # type: ignore[return-value]


async def _finish(db: AsyncSession, game_id: int, winner: str | None, now: datetime, aborted: bool = False) -> bool:
    claimed = await db.execute(
        update(Game).where(Game.id == game_id, Game.status == 'started').values(
            status='aborted' if aborted else 'finished', phase='finished',
            winner=None if aborted else winner, finished_at=now, phase_deadline=None,
        )
    )
    if claimed.rowcount != 1:  # someone else already finished it -> do nothing (no double stats)
        return False
    game = await _fresh_game(db, game_id)
    players = await _players(db, game_id)
    if not aborted:
        winning_role = WINNING_ROLE.get(winner or '')
        for player in players:
            values: dict[str, Any] = {'games_played': User.games_played + 1}
            if winning_role and player.role_name == winning_role:
                values['games_won'] = User.games_won + 1
            await db.execute(update(User).where(User.id == player.user_id).values(**values))
    await db.execute(update(TableModel).where(TableModel.id == game.table_id).values(status='waiting'))
    await db.execute(
        update(Reservation).where(Reservation.table_id == game.table_id, Reservation.status == 'confirmed')
        .values(status='completed')
    )
    _event(db, game_id, 'game.aborted' if aborted else 'game.finished',
           {'winner': None if aborted else winner, 'roles': {str(p.user_id): p.role_name for p in players}})
    return True


async def _to_vote(db: AsyncSession, game_id: int, round_no: int, now: datetime) -> bool:
    game = await _fresh_game(db, game_id)
    seconds = game_settings(game)['vote_seconds'] if game else settings.vote_phase_seconds
    claimed = await db.execute(
        update(Game).where(
            Game.id == game_id, Game.status == 'started', Game.phase == 'answer', Game.round_no == round_no
        ).values(phase='vote', phase_deadline=now + timedelta(seconds=seconds), phase_started_at=now)
    )
    if claimed.rowcount != 1:
        return False
    _event(db, game_id, 'phase.vote', {'round': round_no})
    return True


async def _resolve_round(db: AsyncSession, game_id: int, round_no: int, now: datetime) -> bool:
    claimed = await db.execute(
        update(Game).where(
            Game.id == game_id, Game.status == 'started', Game.phase == 'vote', Game.round_no == round_no
        ).values(phase='resolving')
    )
    if claimed.rowcount != 1:
        return False
    game = await _fresh_game(db, game_id)
    players = await _players(db, game_id)
    alive_ids = {p.user_id for p in players if p.is_alive}
    votes = (
        await db.execute(select(GameVote).where(GameVote.game_id == game_id, GameVote.round_no == round_no))
    ).scalars().all()
    vote_map = {v.voter_id: v.target_id for v in votes if v.voter_id in alive_ids and v.target_id in alive_ids}
    eliminated = tally_votes(vote_map)
    answers = (
        await db.execute(select(GameAnswer).where(GameAnswer.game_id == game_id, GameAnswer.round_no == round_no))
    ).scalars().all()

    role_of = {p.user_id: p.role_name for p in players}
    if eliminated is not None:
        await db.execute(
            update(GamePlayer).where(
                GamePlayer.game_id == game_id, GamePlayer.user_id == eliminated, GamePlayer.is_alive.is_(True)
            ).values(is_alive=False, eliminated_round=round_no)
        )
    _event(db, game_id, 'round.resolved', {
        'round': round_no,
        'eliminated_user_id': eliminated,
        'eliminated_role': role_of.get(eliminated) if (eliminated and REVEAL_ROLE_ON_ELIMINATION) else None,
        'tally': {str(k): v for k, v in Counter(vote_map.values()).items()},
        'abstained': len(alive_ids) - len(vote_map),
        'answers': {str(a.user_id): a.text for a in answers},
    })

    outcome = determine_game_winner([
        {'role_name': p.role_name, 'is_alive': p.is_alive and p.user_id != eliminated} for p in players
    ])
    total_rounds = len(await _questions(db, game.case_id))
    if outcome is None and round_no >= total_rounds:
        outcome = 'draw'
    if outcome is not None:
        await _finish(db, game_id, outcome, now)
    else:
        await db.execute(
            update(Game).where(Game.id == game_id, Game.phase == 'resolving').values(
                phase='answer', round_no=round_no + 1,
                phase_deadline=now + timedelta(seconds=game_settings(game)['answer_seconds']), phase_started_at=now,
            )
        )
        await _discover_clues(db, game, round_no + 1, now)
        _event(db, game_id, 'phase.answer', {'round': round_no + 1})
    return True


# ---------------------------------------------------------------- interrogation stage
async def _team_of(db: AsyncSession, game_id: int, user_id: int) -> str | None:
    return await db.scalar(select(GamePlayer.team).where(GamePlayer.game_id == game_id, GamePlayer.user_id == user_id))


async def _answered_map(db: AsyncSession, game_id: int, user_id: int) -> dict[int, str | None]:
    rows = (await db.execute(select(InterrogationAnswer).where(
        InterrogationAnswer.game_id == game_id, InterrogationAnswer.user_id == user_id))).scalars().all()
    return {r.question_id: (None if r.skipped else r.option_key) for r in rows}


async def _current_question_for(db: AsyncSession, game: Game, user_id: int,
                                pool: list[Question] | None = None) -> Question | None:
    """Deterministic server-side choice of this player's question for the current step."""
    pool = pool if pool is not None else await _interrogation_pool(db, game.case_id)
    by_id = {q.id: q for q in pool}
    rows = (await db.execute(select(InterrogationAnswer).where(
        InterrogationAnswer.game_id == game.id, InterrogationAnswer.user_id == user_id,
        InterrogationAnswer.index_no == game.interrogation_index))).scalars().all()
    if rows:  # already answered/skipped this step: report that question
        return by_id.get(rows[0].question_id)
    team = await _team_of(db, game.id, user_id)
    visible = {c.id for c, _ in await _visible_clues(db, game, team)}
    chosen = select_interrogation_question([_qview(q) for q in pool], await _answered_map(db, game.id, user_id), visible)
    return by_id.get(chosen.id) if chosen else None


async def _advance_interrogation(db: AsyncSession, game_id: int, index: int, now: datetime) -> bool:
    game = await _fresh_game(db, game_id)
    if game is None:
        return False
    cfg = game_settings(game)
    last = index >= cfg['interrogation_total']
    values: dict[str, Any] = {'phase_started_at': now}
    if not last:
        values.update(interrogation_index=index + 1, phase_deadline=now + timedelta(seconds=cfg['interrogation_seconds']))
    elif cfg['briefing_seconds'] > 0:
        values.update(phase='briefing', phase_deadline=now + timedelta(seconds=cfg['briefing_seconds']))
    else:
        values.update(phase='answer', round_no=1, phase_deadline=now + timedelta(seconds=cfg['answer_seconds']))
    claimed = await db.execute(update(Game).where(
        Game.id == game_id, Game.status == 'started', Game.phase == 'interrogation', Game.interrogation_index == index,
    ).values(**values))
    if claimed.rowcount != 1:
        return False
    # Players who did not answer this step get a recorded skip so the question is never re-asked.
    pool = await _interrogation_pool(db, game.case_id)
    for player in await _players(db, game_id):
        if not player.is_alive:
            continue
        has_row = await db.scalar(select(InterrogationAnswer.id).where(
            InterrogationAnswer.game_id == game_id, InterrogationAnswer.user_id == player.user_id,
            InterrogationAnswer.index_no == index))
        if has_row:
            continue
        question = await _current_question_for(db, game, player.user_id, pool)  # game still holds `index`
        if question is not None:
            db.add(InterrogationAnswer(game_id=game_id, user_id=player.user_id, index_no=index, question_id=question.id,
                                       kind=question.kind or 'text', skipped=True, created_at=now))
    game = await _fresh_game(db, game_id)
    if not last:
        _event(db, game_id, 'phase.interrogation', {'step': index + 1, 'total': cfg['interrogation_total']})
    elif game.phase == 'briefing':
        await _discover_clues(db, game, 1, now)
        _event(db, game_id, 'phase.briefing', {})
    else:
        await _discover_clues(db, game, 1, now)
        _event(db, game_id, 'phase.answer', {'round': 1})
    return True


async def _briefing_to_rounds(db: AsyncSession, game_id: int, now: datetime) -> bool:
    game = await _fresh_game(db, game_id)
    if game is None:
        return False
    claimed = await db.execute(update(Game).where(
        Game.id == game_id, Game.status == 'started', Game.phase == 'briefing',
    ).values(phase='answer', round_no=1, phase_started_at=now,
             phase_deadline=now + timedelta(seconds=game_settings(game)['answer_seconds'])))
    if claimed.rowcount != 1:
        return False
    await _discover_clues(db, game, 1, now)
    _event(db, game_id, 'phase.answer', {'round': 1})
    return True


async def submit_interrogation_answer(db: AsyncSession, game_id: int, user: User, *, question_id: int,
                                      option_key: str | None, text: str | None, clue_id: int | None) -> dict[str, Any]:
    if await _fresh_game(db, game_id) is None:
        raise HTTPException(status_code=404, detail='Game not found')
    await advance_if_due(db, game_id)
    game = await _fresh_game(db, game_id)
    if game.status != 'started' or game.phase != 'interrogation':
        raise HTTPException(status_code=409, detail='The interrogation stage is over')
    await _require_active_player(db, game_id, user.id)
    question = await _current_question_for(db, game, user.id)
    if question is None or question.id != question_id:
        raise HTTPException(status_code=409, detail='This question is no longer active')
    kind = question.kind or 'text'
    options = parse_json_list(question.options_json)
    stored_text = stored_key = stored_clue = None
    if kind == 'choice':
        keys = {o['key'] for o in public_options('choice', options)}
        if option_key not in keys:
            raise HTTPException(status_code=422, detail='Choose one of the listed answers')
        stored_key = option_key
    elif kind == 'evidence':
        if clue_id is None or clue_id not in await _public_clue_ids(db, game):
            raise HTTPException(status_code=422, detail='Choose a discovered public clue')
        stored_clue = clue_id
    else:
        stored_text = (text or '').strip()
        if not stored_text:
            raise HTTPException(status_code=422, detail='Answer text is required')
    now = utcnow()
    response_ms = int((now - game.phase_started_at).total_seconds() * 1000) if game.phase_started_at else None
    db.add(InterrogationAnswer(
        game_id=game_id, user_id=user.id, index_no=game.interrogation_index, question_id=question.id, kind=kind,
        text=stored_text, option_key=stored_key, clue_id=stored_clue,
        response_ms=max(0, response_ms) if response_ms is not None else None,
        contradiction_clue_id=detect_contradiction(kind, options, option_key=stored_key, text=stored_text, clue_id=stored_clue),
        created_at=now,
    ))
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail='You already answered this step')
    _event(db, game_id, 'interrogation.answered', {'step': game.interrogation_index, 'user_id': user.id})
    await db.commit()

    index = game.interrogation_index
    answered = await db.scalar(select(func.count(InterrogationAnswer.id)).where(
        InterrogationAnswer.game_id == game_id, InterrogationAnswer.index_no == index))
    alive = len([p for p in await _players(db, game_id) if p.is_alive])
    if (answered or 0) >= alive and await _advance_interrogation(db, game_id, index, utcnow()):
        await db.commit()
    schedule_notify(game.table_id)
    return {'ok': True, 'step': index}


async def briefing_ready(db: AsyncSession, game_id: int, user: User) -> dict[str, Any]:
    """Player finished watching the case file. When everyone is ready, round 1 starts early."""
    if await _fresh_game(db, game_id) is None:
        raise HTTPException(status_code=404, detail='Game not found')
    await advance_if_due(db, game_id)
    game = await _fresh_game(db, game_id)
    if game.status != 'started' or game.phase != 'briefing':
        return {'ok': True, 'phase': game.phase}
    player = await _require_active_player(db, game_id, user.id)
    await db.execute(update(GamePlayer).where(GamePlayer.id == player.id, GamePlayer.ready_at.is_(None))
                     .values(ready_at=utcnow()))
    await db.commit()
    players = [p for p in await _players(db, game_id) if p.is_alive]
    if all(p.ready_at is not None for p in players) and await _briefing_to_rounds(db, game_id, utcnow()):
        await db.commit()
    schedule_notify(game.table_id)
    return {'ok': True, 'phase': (await _fresh_game(db, game_id)).phase}


async def advance_if_due(db: AsyncSession, game_id: int, now: datetime | None = None) -> bool:
    """Move the game forward if the current phase deadline has passed. Safe to call from anywhere, any number of times."""
    now = now or utcnow()
    game = await _fresh_game(db, game_id)
    if game is None or game.status != 'started' or game.phase_deadline is None or game.phase_deadline > now:
        return False
    if game.phase == 'interrogation':
        changed = await _advance_interrogation(db, game_id, game.interrogation_index, now)
    elif game.phase == 'briefing':
        changed = await _briefing_to_rounds(db, game_id, now)
    elif game.phase == 'answer':
        changed = await _to_vote(db, game_id, game.round_no, now)
    elif game.phase == 'vote':
        changed = await _resolve_round(db, game_id, game.round_no, now)
    else:
        changed = False
    if changed:
        await db.commit()
        schedule_notify(game.table_id)
    return changed  # nothing was written when False (compare-and-set matched no row)


async def abort_game(db: AsyncSession, game_id: int) -> bool:
    done = await _finish(db, game_id, None, utcnow(), aborted=True)
    if done:
        await db.commit()
        game = await _fresh_game(db, game_id)
        schedule_notify(game.table_id)
    else:
        await db.rollback()
    return done


# ---------------------------------------------------------------- player actions
async def _require_active_player(db: AsyncSession, game_id: int, user_id: int) -> GamePlayer:
    player = (
        await db.execute(
            select(GamePlayer).where(GamePlayer.game_id == game_id, GamePlayer.user_id == user_id)
            .execution_options(populate_existing=True)
        )
    ).scalar_one_or_none()
    if player is None or player.is_spectator:
        raise HTTPException(status_code=403, detail='You are not a player in this game')
    if not player.is_alive:
        raise HTTPException(status_code=403, detail='Eliminated players cannot act')
    return player


async def submit_answer(db: AsyncSession, game_id: int, user: User, text: str) -> dict[str, Any]:
    if await _fresh_game(db, game_id) is None:
        raise HTTPException(status_code=404, detail='Game not found')
    await advance_if_due(db, game_id)
    game = await _fresh_game(db, game_id)
    if game.status != 'started' or game.phase != 'answer':
        raise HTTPException(status_code=409, detail='Answers are not being accepted now')
    await _require_active_player(db, game_id, user.id)

    db.add(GameAnswer(game_id=game_id, round_no=game.round_no, user_id=user.id, text=text.strip()))
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail='You already answered this round')
    _event(db, game_id, 'answer.submitted', {'round': game.round_no, 'user_id': user.id})
    await db.commit()

    # Count only after our own commit: with concurrent submitters, whoever counts last sees every answer
    # (counting inside the transaction misses other uncommitted answers and the early switch never fires).
    answered = await db.scalar(
        select(func.count(GameAnswer.id)).where(GameAnswer.game_id == game_id, GameAnswer.round_no == game.round_no)
    )
    alive = len([p for p in await _players(db, game_id) if p.is_alive])
    if (answered or 0) >= alive:
        await _to_vote(db, game_id, game.round_no, utcnow())  # compare-and-set: only one caller wins
        await db.commit()
    schedule_notify(game.table_id)
    return {'ok': True, 'round': game.round_no}


async def submit_vote(db: AsyncSession, game_id: int, user: User, target_user_id: int) -> dict[str, Any]:
    if await _fresh_game(db, game_id) is None:
        raise HTTPException(status_code=404, detail='Game not found')
    await advance_if_due(db, game_id)
    game = await _fresh_game(db, game_id)
    if game.status != 'started' or game.phase != 'vote':
        raise HTTPException(status_code=409, detail='Voting is not open now')
    await _require_active_player(db, game_id, user.id)
    if target_user_id == user.id:
        raise HTTPException(status_code=422, detail='You cannot vote for yourself')
    players = await _players(db, game_id)
    if target_user_id not in {p.user_id for p in players if p.is_alive}:
        raise HTTPException(status_code=422, detail='Target is not an alive player')

    db.add(GameVote(game_id=game_id, round_no=game.round_no, voter_id=user.id, target_id=target_user_id))
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail='You already voted this round')
    _event(db, game_id, 'vote.submitted', {'round': game.round_no, 'user_id': user.id})
    await db.commit()

    voted = await db.scalar(  # after commit, see answer path
        select(func.count(GameVote.id)).where(GameVote.game_id == game_id, GameVote.round_no == game.round_no)
    )
    if (voted or 0) >= len([p for p in players if p.is_alive]):
        await _resolve_round(db, game_id, game.round_no, utcnow())  # compare-and-set
        await db.commit()
    schedule_notify(game.table_id)
    return {'ok': True, 'round': game.round_no}


# ---------------------------------------------------------------- views (viewer-aware, never leak secrets)
async def get_state(db: AsyncSession, game_id: int, viewer: User) -> dict[str, Any]:
    if await _fresh_game(db, game_id) is None:
        raise HTTPException(status_code=404, detail='Game not found')
    await advance_if_due(db, game_id)
    game = await _fresh_game(db, game_id)
    players = await _players(db, game_id)
    users = {
        u.id: u for u in (await db.execute(select(User).where(User.id.in_([p.user_id for p in players])))).scalars()
    }
    finished = game.status != 'started'
    me = next((p for p in players if p.user_id == viewer.id), None)

    def public_role(p: GamePlayer) -> str | None:
        if finished or (not p.is_alive and REVEAL_ROLE_ON_ELIMINATION):
            return p.role_name
        return None

    question = None
    questions = await _questions(db, game.case_id)
    if game.status == 'started' and 1 <= game.round_no <= len(questions):
        q = questions[game.round_no - 1]
        question = {'id': q.id, 'prompt': q.prompt}

    answered = voted = 0
    my_answer = my_vote = None
    round_answers: list[dict[str, Any]] = []
    if game.status == 'started':
        answers = (await db.execute(
            select(GameAnswer).where(GameAnswer.game_id == game_id, GameAnswer.round_no == game.round_no)
        )).scalars().all()
        votes = (await db.execute(
            select(GameVote).where(GameVote.game_id == game_id, GameVote.round_no == game.round_no)
        )).scalars().all()
        answered, voted = len(answers), len(votes)
        my_answer = next((a.text for a in answers if a.user_id == viewer.id), None)
        my_vote = next((v.target_id for v in votes if v.voter_id == viewer.id), None)
        if game.phase == 'vote':  # answers become public once the answer phase is over
            round_answers = [{'user_id': a.user_id, 'text': a.text} for a in answers]

    me_view: dict[str, Any] = {'is_player': me is not None}
    if me is not None:
        me_view.update({'role': me.role_name, 'team': me.team, 'is_alive': me.is_alive})
        if me.role_name == 'spy' and INFILTRATORS_KNOW_EACH_OTHER:
            me_view['teammates'] = [p.user_id for p in players if p.role_name == 'spy' and p.user_id != viewer.id]

    state = {
        'id': game.id, 'table_id': game.table_id, 'status': game.status, 'phase': game.phase,
        'round_no': game.round_no, 'total_rounds': len(questions),
        'phase_deadline': game.phase_deadline.isoformat() if game.phase_deadline else None,
        'server_time': utcnow().isoformat(),
        'winner': game.winner, 'question': question,
        'players': [
            {'user_id': p.user_id, 'name': _name(users[p.user_id]), 'is_alive': p.is_alive, 'role': public_role(p)}
            for p in players
        ],
        'me': me_view,
        'progress': {'answered': answered, 'voted': voted, 'alive': len([p for p in players if p.is_alive])},
        'my_answer': my_answer, 'my_vote': my_vote, 'answers': round_answers,
    }
    state.update(await _investigation_view(db, game, players, users, me))
    return state


STAGE_OF_PHASE = {'interrogation': 'interrogation', 'briefing': 'briefing', 'answer': 'investigation',
                  'vote': 'investigation', 'resolving': 'investigation', 'finished': 'finished'}


def _answer_display(answer: InterrogationAnswer, question: Question | None, clue_titles: dict[int, str]) -> str | None:
    if answer.skipped:
        return None
    if answer.kind == 'choice' and question is not None:
        labels = {o['key']: o['label'] for o in public_options('choice', parse_json_list(question.options_json))}
        return labels.get(answer.option_key or '', answer.option_key)
    if answer.kind == 'evidence':
        return clue_titles.get(answer.clue_id or 0, 'مدرک')
    return answer.text


def _clue_brief(clue: Clue, found: GameClue) -> dict[str, Any]:
    return {
        'id': clue.id, 'title': clue.title or 'سرنخ', 'text': clue.text, 'kind': clue.kind or 'document',
        'importance': clue.importance or 'normal', 'round': found.round_no,
        'discovered_at': found.discovered_at.isoformat() if found.discovered_at else None,
        'team_only': (clue.visibility or 'public') != 'public',
    }


async def _investigation_view(db: AsyncSession, game: Game, players: list[GamePlayer], users: dict[int, User],
                              me: GamePlayer | None) -> dict[str, Any]:
    """Viewer-specific additions: stage, case file, interrogation, dossier and discovered clues."""
    cfg = game_settings(game)
    finished = game.status != 'started'
    stage = 'finished' if finished else STAGE_OF_PHASE.get(game.phase or '', 'investigation')
    team = me.team if me is not None else None
    case = await db.get(CaseModel, game.case_id) if game.case_id else None
    visible = await _visible_clues(db, game, team)
    clue_titles = {c.id: (c.title or 'سرنخ') for c, _ in visible}
    public_ids = {c.id for c, _ in visible if (c.visibility or 'public') == 'public'}

    case_view = None
    if case is not None:
        case_view = {'code': case.code, 'title': case.title}
        if stage != 'interrogation':  # the file opens after the interrogation stage
            briefing = parse_json_list(case.briefing_json)
            case_view.update({
                'summary': case.summary, 'objective': case.objective,
                'briefing': [{'label': str(b.get('label', '')), 'value': str(b.get('value', ''))}
                             for b in briefing if isinstance(b, dict)],
            })

    view: dict[str, Any] = {
        'stage': stage,
        'case': case_view,
        'settings': {k: cfg[k] for k in ('interrogation_seconds', 'answer_seconds', 'vote_seconds', 'briefing_seconds',
                                         'interrogation_total')},
        'clues': [_clue_brief(c, g) for c, g in visible],
        'interrogation': None,
        'dossier': [],
        'briefing': None,
    }

    pool = await _interrogation_pool(db, game.case_id) if cfg['interrogation_total'] else []
    by_id = {q.id: q for q in pool}
    if stage == 'interrogation':
        index = game.interrogation_index
        answered = await db.scalar(select(func.count(InterrogationAnswer.id)).where(
            InterrogationAnswer.game_id == game.id, InterrogationAnswer.index_no == index)) or 0
        block: dict[str, Any] = {'step': index, 'total': cfg['interrogation_total'], 'answered': answered,
                                 'alive': len([p for p in players if p.is_alive]), 'question': None, 'my_answer': None,
                                 'history': []}
        if me is not None and me.is_alive:
            mine = (await db.execute(select(InterrogationAnswer).where(
                InterrogationAnswer.game_id == game.id, InterrogationAnswer.user_id == me.user_id)
                .order_by(InterrogationAnswer.index_no))).scalars().all()
            current = next((a for a in mine if a.index_no == index), None)
            question = await _current_question_for(db, game, me.user_id, pool)
            if question is not None:
                kind = question.kind or 'text'
                block['question'] = {
                    'id': question.id, 'prompt': question.prompt, 'kind': kind,
                    'options': public_options(kind, parse_json_list(question.options_json)),
                    'evidence': [{'id': c.id, 'title': c.title or 'سرنخ', 'kind': c.kind or 'document'}
                                 for c, _ in visible if c.id in public_ids] if kind == 'evidence' else [],
                    'follow_up': question.follow_up_of_id is not None,
                }
            if current is not None:
                block['my_answer'] = {'display': _answer_display(current, by_id.get(current.question_id), clue_titles),
                                      'skipped': current.skipped}
            block['history'] = [{'step': a.index_no, 'prompt': by_id[a.question_id].prompt if a.question_id in by_id else '',
                                 'answer': _answer_display(a, by_id.get(a.question_id), clue_titles), 'skipped': a.skipped}
                                for a in mine if a.index_no < index]
        view['interrogation'] = block
    elif cfg['interrogation_total']:
        # Public interrogation dossier: answers, response times and contradictions with *public discovered* clues.
        rows = (await db.execute(select(InterrogationAnswer).where(InterrogationAnswer.game_id == game.id)
                                 .order_by(InterrogationAnswer.index_no, InterrogationAnswer.user_id))).scalars().all()
        dossier = []
        for player in players:
            entries = []
            for a in [r for r in rows if r.user_id == player.user_id]:
                contradiction = None
                if a.contradiction_clue_id and a.contradiction_clue_id in public_ids:
                    contradiction = {'clue_id': a.contradiction_clue_id, 'title': clue_titles[a.contradiction_clue_id]}
                entries.append({
                    'step': a.index_no, 'prompt': by_id[a.question_id].prompt if a.question_id in by_id else '',
                    'answer': _answer_display(a, by_id.get(a.question_id), clue_titles), 'skipped': a.skipped,
                    'response_ms': a.response_ms, 'follow_up': bool(by_id.get(a.question_id) and by_id[a.question_id].follow_up_of_id),
                    'contradiction': contradiction,
                })
            dossier.append({'user_id': player.user_id, 'name': _name(users[player.user_id]), 'entries': entries})
        view['dossier'] = dossier

    if stage == 'briefing':
        alive = [p for p in players if p.is_alive]
        view['briefing'] = {'ready': len([p for p in alive if p.ready_at is not None]), 'alive': len(alive),
                            'me_ready': bool(me is not None and me.ready_at is not None)}
    return view


async def list_events(db: AsyncSession, game_id: int, after_id: int = 0, limit: int = 200) -> list[dict[str, Any]]:
    rows = (await db.execute(
        select(GameEvent).where(GameEvent.game_id == game_id, GameEvent.id > after_id)
        .order_by(GameEvent.id).limit(min(limit, 500))
    )).scalars().all()
    return [{'id': r.id, 'type': r.type, 'payload': json.loads(r.payload), 'at': r.created_at.isoformat()} for r in rows]
