from __future__ import annotations

from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Game, GameEvent, GamePlayer, Reservation, Spectator, TableModel, User
from app.services import game_service

ACTIVE = ('pending', 'confirmed')


async def can_access_table(db: AsyncSession, table_id: int, viewer: User) -> bool:
    table = await db.get(TableModel, table_id)
    if table is None:
        return False
    if table.host_user_id == viewer.id or viewer.role in {'game_admin', 'super_admin'}:
        return True
    seated = await db.scalar(select(Reservation.id).where(
        Reservation.table_id == table_id, Reservation.user_id == viewer.id, Reservation.status.in_(ACTIVE)))
    if seated:
        return True
    spectating = await db.scalar(select(Spectator.id).where(
        Spectator.table_id == table_id, Spectator.user_id == viewer.id, Spectator.is_active.is_(True)))
    if spectating:
        return True
    latest_game_id = select(Game.id).where(Game.table_id == table_id).order_by(Game.id.desc()).limit(1).scalar_subquery()
    return bool(await db.scalar(select(GamePlayer.id).join(Game, Game.id == GamePlayer.game_id).where(
        Game.id == latest_game_id, GamePlayer.user_id == viewer.id)))


async def table_summary(db: AsyncSession, table: TableModel) -> dict[str, Any]:
    taken = (await db.scalar(
        select(func.count(Reservation.id)).where(Reservation.table_id == table.id, Reservation.status.in_(ACTIVE))
    )) or 0
    specs = (await db.scalar(
        select(func.count(Spectator.id)).where(Spectator.table_id == table.id, Spectator.is_active.is_(True))
    )) or 0
    running = await db.scalar(select(Game.id).where(Game.table_id == table.id, Game.status == 'started'))
    return {
        'id': table.id, 'name': table.name, 'status': table.status, 'max_players': table.max_players,
        'spectator_capacity': table.spectator_capacity, 'host_user_id': table.host_user_id,
        'start_time': table.start_time.isoformat() if table.start_time else None,
        'available_seats': max(0, table.max_players - taken), 'spectators': specs, 'game_id': running,
        'settings': game_service.table_settings(table),
    }


async def build_snapshot(db: AsyncSession, table_id: int, viewer: User, online: set[int]) -> dict[str, Any] | None:
    """Full, viewer-specific picture of a table. Safe to push: contains nothing the viewer may not see."""
    table = await db.get(TableModel, table_id)
    if table is None or not await can_access_table(db, table_id, viewer):
        return None
    summary = await table_summary(db, table)

    seat_rows = (await db.execute(
        select(Reservation, User).join(User, User.id == Reservation.user_id)
        .where(Reservation.table_id == table_id, Reservation.status.in_(ACTIVE)).order_by(Reservation.seat_index)
    )).all()
    seats = [
        {'seat_index': r.seat_index, 'user_id': r.user_id, 'status': r.status, 'connected': r.user_id in online,
         'name': u.display_name or u.first_name or u.username or f'player-{u.id}'}
        for r, u in seat_rows
    ]
    # Separate SELECTs are not one snapshot (READ COMMITTED); keep the counter consistent with `seats`.
    summary['available_seats'] = max(0, table.max_players - len(seats))

    game_id = await db.scalar(select(Game.id).where(Game.table_id == table_id).order_by(Game.id.desc()).limit(1))
    game_state = None
    if game_id is not None:
        game_state = await game_service.get_state(db, game_id, viewer)
        for player in game_state['players']:
            player['connected'] = player['user_id'] in online
        game_state['last_event_id'] = (await db.scalar(
            select(func.max(GameEvent.id)).where(GameEvent.game_id == game_id)
        )) or 0

    return {'table': summary, 'seats': seats, 'online': sorted(online), 'game': game_state}
