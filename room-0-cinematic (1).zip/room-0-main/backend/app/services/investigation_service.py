"""Investigation board: discovered clues, private notes/flags, links, hypotheses and summary.

Everything here is per-player and private: a player's notes, links and theories are never sent to
anyone else. Clue visibility (public vs. team-only) is enforced on every read and write.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from fastapi import HTTPException
from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Clue, ClueLink, ClueNote, Game, GameClue, GamePlayer, Hypothesis, User
from app.services.game_service import _visible_clues
from app.services.investigation_rules import (
    CLUE_STATUSES,
    authored_contradiction,
    contradictions_among,
    entity_edges,
    investigation_progress,
    normalize_link,
    parse_json_list,
)

MAX_LINKS = 60
MAX_HYPOTHESES = 30


async def _game_or_404(db: AsyncSession, game_id: int) -> Game:
    game = await db.get(Game, game_id)
    if game is None:
        raise HTTPException(status_code=404, detail='Game not found')
    return game


async def _player(db: AsyncSession, game_id: int, user_id: int) -> GamePlayer | None:
    return (await db.execute(select(GamePlayer).where(
        GamePlayer.game_id == game_id, GamePlayer.user_id == user_id, GamePlayer.is_spectator.is_(False)))).scalar_one_or_none()


async def _writable(db: AsyncSession, game_id: int, user: User) -> tuple[Game, GamePlayer]:
    game = await _game_or_404(db, game_id)
    player = await _player(db, game_id, user.id)
    if player is None:
        raise HTTPException(status_code=403, detail='You are not a player in this game')
    if game.status != 'started':
        raise HTTPException(status_code=409, detail='The case is closed')
    return game, player


def _clue_dict(clue: Clue, found: GameClue) -> dict[str, Any]:
    return {
        'id': clue.id, 'title': clue.title or 'سرنخ', 'text': clue.text, 'kind': clue.kind or 'document',
        'importance': clue.importance or 'normal', 'round': found.round_no,
        'discovered_at': found.discovered_at.isoformat() if found.discovered_at else None,
        'entities': [e for e in parse_json_list(clue.entities_json) if isinstance(e, dict)],
        'media_url': clue.media_url, 'team_only': (clue.visibility or 'public') != 'public',
        'contradicts_clue_id': clue.contradicts_clue_id,
    }


async def _visible_map(db: AsyncSession, game: Game, team: str | None) -> dict[int, dict[str, Any]]:
    return {c.id: _clue_dict(c, g) for c, g in await _visible_clues(db, game, team)}


def _public(clue: dict[str, Any]) -> dict[str, Any]:
    # the authored contradiction target is a hint for the solution; never send it
    return {k: v for k, v in clue.items() if k != 'contradicts_clue_id'}


def _link_out(link: ClueLink) -> dict[str, Any]:
    return {'id': link.id, 'from': link.from_clue_id, 'to': link.to_clue_id, 'label': link.label,
            'contradiction': link.is_contradiction}


def _hyp_out(h: Hypothesis, clues: dict[int, dict[str, Any]]) -> dict[str, Any]:
    cited = [i for i in parse_json_list(h.clue_ids_json) if isinstance(i, int)]
    pairs = contradictions_among([clues[i] for i in cited if i in clues])
    return {'id': h.id, 'text': h.text, 'clue_ids': cited, 'suspect_user_id': h.suspect_user_id,
            'created_at': h.created_at.isoformat() if h.created_at else None,
            'check': {'cited': len(cited), 'contradictions': [list(p) for p in pairs],
                      'verdict': 'conflict' if pairs else ('unsupported' if not cited else 'consistent')}}


async def board(db: AsyncSession, game_id: int, user: User) -> dict[str, Any]:
    game = await _game_or_404(db, game_id)
    me = await _player(db, game_id, user.id)
    clues = await _visible_map(db, game, me.team if me else None)
    if me is None:  # spectators: public evidence only, no private board
        public = [_public(c) for c in clues.values() if not c['team_only']]
        return {'game_id': game_id, 'readonly': True, 'clues': public, 'relations': entity_edges(public),
                'links': [], 'hypotheses': [], 'progress': 0, 'summary': None}

    notes = {n.clue_id: n for n in (await db.execute(select(ClueNote).where(
        ClueNote.game_id == game_id, ClueNote.user_id == user.id))).scalars().all()}
    links = (await db.execute(select(ClueLink).where(ClueLink.game_id == game_id, ClueLink.user_id == user.id)
                              .order_by(ClueLink.id))).scalars().all()
    hyps = (await db.execute(select(Hypothesis).where(Hypothesis.game_id == game_id, Hypothesis.user_id == user.id)
                             .order_by(Hypothesis.id.desc()))).scalars().all()
    out = []
    for clue in clues.values():
        note = notes.get(clue['id'])
        item = _public(clue)
        item['note'] = {'flagged': note.flagged, 'status': note.status, 'text': note.note or '',
                        'updated_at': note.updated_at.isoformat() if note.updated_at else None} if note else \
            {'flagged': False, 'status': 'new', 'text': '', 'updated_at': None}
        out.append(item)
    checked = sum(1 for c in out if c['note']['status'] == 'checked')
    visible_links = [l for l in links if l.from_clue_id in clues and l.to_clue_id in clues]
    return {
        'game_id': game_id, 'readonly': game.status != 'started', 'clues': out,
        'relations': entity_edges([clues[i] for i in clues]),
        'links': [_link_out(l) for l in visible_links],
        'hypotheses': [_hyp_out(h, clues) for h in hyps],
        'progress': investigation_progress(len(out), checked, len(visible_links), len(hyps)),
        'summary': {
            'discovered': len(out), 'checked': checked, 'flagged': sum(1 for c in out if c['note']['flagged']),
            'links': len(visible_links), 'contradictions': sum(1 for l in visible_links if l.is_contradiction),
            'hypotheses': len(hyps),
        },
    }


async def save_note(db: AsyncSession, game_id: int, user: User, clue_id: int, *, flagged: bool | None,
                    status: str | None, note: str | None) -> dict[str, Any]:
    game, player = await _writable(db, game_id, user)
    clues = await _visible_map(db, game, player.team)
    if clue_id not in clues:
        raise HTTPException(status_code=404, detail='Clue not found')
    if status is not None and status not in CLUE_STATUSES:
        raise HTTPException(status_code=422, detail='Invalid review status')
    for attempt in range(2):
        row = (await db.execute(select(ClueNote).where(ClueNote.game_id == game_id, ClueNote.user_id == user.id,
                                                       ClueNote.clue_id == clue_id))).scalar_one_or_none()
        if row is None:
            row = ClueNote(game_id=game_id, user_id=user.id, clue_id=clue_id)
            db.add(row)
        if flagged is not None:
            row.flagged = flagged
        if status is not None:
            row.status = status
        elif row.status in (None, 'new'):
            row.status = 'reviewing'  # opening + saving anything means it is being reviewed
        if note is not None:
            row.note = note.strip() or None
        row.updated_at = datetime.utcnow()
        try:
            await db.commit()
            break
        except IntegrityError:  # concurrent first save of the same note: retry as an update
            await db.rollback()
            if attempt:
                raise HTTPException(status_code=409, detail='Concurrent update, retry')
    return {'clue_id': clue_id, 'flagged': row.flagged, 'status': row.status, 'text': row.note or ''}


async def add_link(db: AsyncSession, game_id: int, user: User, a: int, b: int, label: str | None) -> dict[str, Any]:
    game, player = await _writable(db, game_id, user)
    clues = await _visible_map(db, game, player.team)
    try:
        low, high = normalize_link(a, b)
    except ValueError:
        raise HTTPException(status_code=422, detail='A clue cannot be linked to itself')
    if low not in clues or high not in clues:
        raise HTTPException(status_code=404, detail='Clue not found')
    count = await db.scalar(select(func.count(ClueLink.id)).where(ClueLink.game_id == game_id, ClueLink.user_id == user.id))
    if (count or 0) >= MAX_LINKS:
        raise HTTPException(status_code=409, detail='Too many links on your board')
    link = ClueLink(game_id=game_id, user_id=user.id, from_clue_id=low, to_clue_id=high,
                    label=(label or '').strip() or None, is_contradiction=authored_contradiction(clues[low], clues[high]))
    db.add(link)
    try:
        await db.commit()
        created = True
    except IntegrityError:  # repeated request: return the existing link
        await db.rollback()
        link = (await db.execute(select(ClueLink).where(
            ClueLink.game_id == game_id, ClueLink.user_id == user.id,
            ClueLink.from_clue_id == low, ClueLink.to_clue_id == high))).scalar_one()
        created = False
    return {**_link_out(link), 'created': created}


async def delete_link(db: AsyncSession, game_id: int, user: User, link_id: int) -> dict[str, Any]:
    await _writable(db, game_id, user)
    result = await db.execute(delete(ClueLink).where(ClueLink.id == link_id, ClueLink.game_id == game_id,
                                                     ClueLink.user_id == user.id))
    await db.commit()
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail='Link not found')
    return {'ok': True}


async def add_hypothesis(db: AsyncSession, game_id: int, user: User, *, request_id: str, text: str,
                         clue_ids: list[int], suspect_user_id: int | None) -> dict[str, Any]:
    game, player = await _writable(db, game_id, user)
    clues = await _visible_map(db, game, player.team)
    cited = list(dict.fromkeys(clue_ids))
    if any(i not in clues for i in cited):
        raise HTTPException(status_code=404, detail='Clue not found')
    if suspect_user_id is not None and await _player(db, game_id, suspect_user_id) is None:
        raise HTTPException(status_code=422, detail='Suspect is not a player in this game')
    existing = (await db.execute(select(Hypothesis).where(
        Hypothesis.game_id == game_id, Hypothesis.user_id == user.id, Hypothesis.request_id == request_id))).scalar_one_or_none()
    if existing is not None:
        return {**_hyp_out(existing, clues), 'created': False}
    count = await db.scalar(select(func.count(Hypothesis.id)).where(Hypothesis.game_id == game_id, Hypothesis.user_id == user.id))
    if (count or 0) >= MAX_HYPOTHESES:
        raise HTTPException(status_code=409, detail='Too many hypotheses')
    hyp = Hypothesis(game_id=game_id, user_id=user.id, request_id=request_id, text=text.strip(),
                     clue_ids_json=json.dumps(cited), suspect_user_id=suspect_user_id, created_at=datetime.utcnow())
    db.add(hyp)
    try:
        await db.commit()
    except IntegrityError:  # concurrent duplicate submit
        await db.rollback()
        hyp = (await db.execute(select(Hypothesis).where(
            Hypothesis.game_id == game_id, Hypothesis.user_id == user.id, Hypothesis.request_id == request_id))).scalar_one()
        return {**_hyp_out(hyp, clues), 'created': False}
    return {**_hyp_out(hyp, clues), 'created': True}
