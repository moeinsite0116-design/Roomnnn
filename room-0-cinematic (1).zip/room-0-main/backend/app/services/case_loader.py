"""Load curated case files (JSON) into the database. Idempotent by slug; never deletes data."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import CaseModel, Clue, Question
from app.services.investigation_rules import CLUE_VISIBILITIES, QUESTION_KINDS

CASES_DIR = Path(__file__).resolve().parents[1] / 'content' / 'cases'
DEFAULT_CASE = CASES_DIR / 'archive_blackout.json'


class CaseFileError(ValueError):
    pass


def read_case_file(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or not data.get('slug') or not data.get('title'):
        raise CaseFileError('case file needs slug and title')
    if not data.get('rounds'):
        raise CaseFileError('case file needs at least one round question')
    slugs = [c.get('slug') for c in data.get('clues', [])]
    if len(slugs) != len(set(slugs)) or not all(slugs):
        raise CaseFileError('clue slugs must be present and unique')
    keys = [q.get('key') for q in data.get('interrogation', [])]
    if len(keys) != len(set(keys)) or not all(keys):
        raise CaseFileError('interrogation question keys must be present and unique')
    for clue in data.get('clues', []):
        if clue.get('visibility', 'public') not in CLUE_VISIBILITIES:
            raise CaseFileError(f"invalid visibility for clue {clue['slug']}")
        if clue.get('contradicts') and clue['contradicts'] not in slugs:
            raise CaseFileError(f"clue {clue['slug']} contradicts unknown clue")
    for question in data.get('interrogation', []):
        if question.get('kind', 'text') not in QUESTION_KINDS:
            raise CaseFileError(f"invalid kind for question {question['key']}")
        for ref in (question.get('requires'),):
            if ref and ref not in slugs:
                raise CaseFileError(f"question {question['key']} requires unknown clue")
        if question.get('follow_up_of') and question['follow_up_of'] not in keys:
            raise CaseFileError(f"question {question['key']} follows unknown question")
        for option in question.get('options', []):
            if option.get('contradicts') and option['contradicts'] not in slugs:
                raise CaseFileError(f"question {question['key']} option contradicts unknown clue")
    return data


async def load_case(db: AsyncSession, data: dict[str, Any], *, published: bool = True) -> CaseModel:
    existing = (await db.execute(select(CaseModel).where(CaseModel.slug == data['slug']))).scalar_one_or_none()
    if existing is not None:
        return existing
    case = CaseModel(
        slug=data['slug'], title=data['title'], summary=data.get('summary'), difficulty=data.get('difficulty', 'medium'),
        is_published=published, code=data.get('code'), objective=data.get('objective'),
        briefing_json=json.dumps(data.get('briefing', []), ensure_ascii=False),
    )
    db.add(case)
    await db.flush()

    clue_ids: dict[str, int] = {}
    clue_rows: dict[str, Clue] = {}
    for index, item in enumerate(data.get('clues', []), start=1):
        clue = Clue(
            case_id=case.id, slug=item['slug'], title=item.get('title'), text=item['text'],
            visibility=item.get('visibility', 'public'), kind=item.get('kind', 'document'),
            importance=item.get('importance', 'normal'), unlock_round=int(item.get('unlock_round', 0)),
            entities_json=json.dumps(item.get('entities', []), ensure_ascii=False),
            media_url=item.get('media_url'), order_index=index,
        )
        db.add(clue)
        clue_rows[item['slug']] = clue
    await db.flush()
    for slug, clue in clue_rows.items():
        clue_ids[slug] = clue.id
    for item in data.get('clues', []):
        if item.get('contradicts'):
            clue_rows[item['slug']].contradicts_clue_id = clue_ids[item['contradicts']]

    question_ids: dict[str, int] = {}
    pending_follow_ups: list[tuple[Question, str]] = []
    for index, item in enumerate(data.get('interrogation', []), start=1):
        kind = item.get('kind', 'text')
        options = []
        for option in item.get('options', []):
            resolved = {k: v for k, v in option.items() if k != 'contradicts'}
            if option.get('contradicts'):
                resolved['contradicts_clue_id'] = clue_ids[option['contradicts']]
            options.append(resolved)
        question = Question(
            case_id=case.id, prompt=item['prompt'], order_index=index, stage='interrogation', kind=kind,
            options_json=json.dumps(options, ensure_ascii=False),
            requires_clue_id=clue_ids.get(item['requires']) if item.get('requires') else None,
            follow_up_option=item.get('follow_up_option'),
        )
        db.add(question)
        await db.flush()
        question_ids[item['key']] = question.id
        if item.get('follow_up_of'):
            pending_follow_ups.append((question, item['follow_up_of']))
    for question, parent_key in pending_follow_ups:
        question.follow_up_of_id = question_ids[parent_key]

    for index, prompt in enumerate(data['rounds'], start=1):
        db.add(Question(case_id=case.id, prompt=prompt, order_index=index, stage='round', kind='text'))
    await db.flush()
    return case


async def load_case_file(db: AsyncSession, path: Path = DEFAULT_CASE, *, published: bool = True) -> CaseModel:
    return await load_case(db, read_case_file(path), published=published)
