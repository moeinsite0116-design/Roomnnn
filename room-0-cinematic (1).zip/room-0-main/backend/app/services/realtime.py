"""WebSocket hub.

Design rules
* Clients never mutate game state over WebSocket; actions go through the REST API (one validated path).
* The hub only pushes **viewer-specific snapshots** built on the server, so a secret can never leak
  through a shared broadcast.
* Pushes are coalesced per table (a burst of changes yields a final, up-to-date snapshot) and snapshots
  carry `last_event_id` / `server_time` so clients can discard stale ones.
* Disconnecting changes presence only; it never changes game state.
"""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from typing import Any

from fastapi import WebSocket

from app.core.config import settings

logger = logging.getLogger('room0.realtime')
REDIS_CHANNEL = 'room0:table-changed'


@dataclass(eq=False)
class Connection:
    websocket: WebSocket
    user_id: int
    table_id: int
    send_lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class RealtimeHub:
    def __init__(self) -> None:
        self._rooms: dict[int, set[Connection]] = {}
        self._push_state: dict[int, dict[str, bool]] = {}
        self._tasks: set[asyncio.Task] = set()
        self._redis: Any = None
        self._listener: asyncio.Task | None = None
        self._stopping = False

    # ------------------------------------------------------------ lifecycle
    async def start(self) -> None:
        if not settings.realtime_use_redis or (self._listener and not self._listener.done()):
            return
        self._stopping = False
        self._listener = asyncio.create_task(self._redis_supervisor())

    async def stop(self) -> None:
        self._stopping = True
        if self._listener:
            self._listener.cancel()
            await asyncio.gather(self._listener, return_exceptions=True)
        if self._redis is not None:
            await self._redis.aclose()
        self._redis, self._listener = None, None

    def reset(self) -> None:  # tests
        self._rooms.clear()
        self._push_state.clear()

    async def _redis_supervisor(self) -> None:
        """Keep Redis fan-out alive across restarts; local delivery remains available meanwhile."""
        import redis.asyncio as aioredis

        delay = 1
        while not self._stopping:
            client = None
            pubsub = None
            try:
                client = aioredis.from_url(settings.redis_url, decode_responses=True, socket_connect_timeout=3, socket_timeout=5)
                await client.ping()
                pubsub = client.pubsub()
                await pubsub.subscribe(REDIS_CHANNEL)
                self._redis = client
                delay = 1
                logger.info('realtime: redis fan-out connected')
                async for message in pubsub.listen():
                    if self._stopping:
                        break
                    if message.get('type') == 'message':
                        try:
                            await self._local_notify(int(message['data']))
                        except Exception:
                            logger.exception('realtime: bad redis message')
                if not self._stopping:
                    raise ConnectionError('Redis subscription ended')
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                # Do not log exception text; Redis URLs may include credentials.
                logger.warning('realtime: Redis unavailable (%s); retrying in %ss', type(exc).__name__, delay)
            finally:
                if self._redis is client:
                    self._redis = None
                if pubsub is not None:
                    try:
                        await pubsub.aclose()
                    except Exception:
                        pass
                if client is not None:
                    try:
                        await client.aclose()
                    except Exception:
                        pass
            if not self._stopping:
                await asyncio.sleep(delay)
                delay = min(delay * 2, 30)

    # ------------------------------------------------------------ membership
    @property
    def redis_connected(self) -> bool:
        return self._redis is not None

    def connection_count(self) -> int:
        return sum(len(room) for room in self._rooms.values())

    def online_users(self, table_id: int) -> set[int]:
        return {c.user_id for c in self._rooms.get(table_id, set())}

    def add(self, conn: Connection) -> None:
        self._rooms.setdefault(conn.table_id, set()).add(conn)

    def remove(self, conn: Connection) -> None:
        room = self._rooms.get(conn.table_id)
        if room:
            room.discard(conn)
            if not room:
                self._rooms.pop(conn.table_id, None)

    # ------------------------------------------------------------ sending
    async def send(self, conn: Connection, payload: dict[str, Any]) -> bool:
        try:
            async with conn.send_lock:
                await asyncio.wait_for(conn.websocket.send_text(json.dumps(payload, ensure_ascii=False)), timeout=5)
            return True
        except Exception:
            self.remove(conn)
            try:
                await conn.websocket.close(code=1011)
            except Exception:
                pass
            return False

    async def push_snapshot(self, conn: Connection, event: str = 'snapshot') -> None:
        from app.db import session as db_session
        from app.db.models import User
        from app.services.table_service import build_snapshot

        async with db_session.async_session() as db:
            viewer = await db.get(User, conn.user_id)
            if viewer is None:
                return
            snap = await build_snapshot(db, conn.table_id, viewer, self.online_users(conn.table_id))
        if snap is not None:
            await self.send(conn, {'event': event, **snap})

    # ------------------------------------------------------------ notification
    async def notify(self, table_id: int) -> None:
        """Something changed at this table. Publishes via Redis when enabled, else delivers locally."""
        if self._redis is not None:
            try:
                await self._redis.publish(REDIS_CHANNEL, str(table_id))
                return
            except Exception as exc:
                logger.warning('realtime: Redis publish failed (%s); delivering locally', type(exc).__name__)
        await self._local_notify(table_id)

    async def _local_notify(self, table_id: int) -> None:
        state = self._push_state.setdefault(table_id, {'dirty': False, 'running': False})
        state['dirty'] = True
        if state['running']:
            return  # the running loop will pick the change up -> coalescing
        state['running'] = True
        try:
            while state['dirty']:
                state['dirty'] = False
                for conn in list(self._rooms.get(table_id, ())):
                    try:
                        await self.push_snapshot(conn)
                    except Exception as exc:
                        logger.warning('realtime: snapshot push failed (%s)', type(exc).__name__)
        finally:
            state['running'] = False
            if not self._rooms.get(table_id):
                self._push_state.pop(table_id, None)

    def schedule(self, table_id: int) -> None:
        """Fire-and-forget notification, to be called after the DB transaction committed."""
        try:
            task = asyncio.get_running_loop().create_task(self.notify(table_id))
        except RuntimeError:
            return
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)


realtime_hub = RealtimeHub()


def schedule_notify(table_id: int | None) -> None:
    if table_id is not None:
        realtime_hub.schedule(table_id)
