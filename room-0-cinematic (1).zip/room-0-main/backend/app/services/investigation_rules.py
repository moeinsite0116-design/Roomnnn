"""Pure investigation rules (no database, no web framework) so they can be unit-tested anywhere.

Interrogation stage ("مرحله شناسایی نفوذی‌ها")
* Every player answers the same number of steps. The server picks each player's next question:
  a follow-up triggered by one of *their own* previous choices wins; otherwise the next shared
  base question in case order. A question may require a clue the player can already see.
* Choice / evidence / text answers can be authored as contradicting a clue. The contradiction is
  stored with the answer but only *shown* once that clue is discovered and is public, so a cover
  story can be exposed later in the game without the server ever revealing the solution.

Clue visibility follows the existing team model: public, or only for one team
(detectives / infiltrators / alliance). Team clues never appear in public payloads.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from itertools import combinations
from typing import Any, Iterable

QUESTION_KINDS = ('text', 'choice', 'evidence')
CLUE_VISIBILITIES = ('public', 'detectives', 'infiltrators', 'alliance')
CLUE_STATUSES = ('new', 'reviewing', 'checked')
IMPORTANCE_ORDER = {'normal': 0, 'key': 1, 'critical': 2}

_ARABIC_TO_PERSIAN = str.maketrans({'ي': 'ی', 'ى': 'ی', 'ك': 'ک', 'ۀ': 'ه', 'ة': 'ه', '\u200c': ' '})
_DIACRITICS = re.compile('[\u064b-\u065f\u0670]')


def normalize_fa(text: str) -> str:
    """Lower-noise Persian text for keyword matching (Arabic letter forms, ZWNJ, diacritics)."""
    text = _DIACRITICS.sub('', (text or '').translate(_ARABIC_TO_PERSIAN))
    return re.sub(r'\s+', ' ', text).strip().casefold()


def parse_json_list(raw: str | None) -> list[Any]:
    if not raw:
        return []
    try:
        value = json.loads(raw)
    except (TypeError, ValueError):
        return []
    return value if isinstance(value, list) else []


@dataclass(frozen=True)
class QuestionView:
    id: int
    order_index: int
    kind: str = 'text'
    requires_clue_id: int | None = None
    follow_up_of_id: int | None = None
    follow_up_option: str | None = None


def select_interrogation_question(
    pool: Iterable[QuestionView],
    answered: dict[int, str | None],
    visible_clue_ids: set[int],
) -> QuestionView | None:
    """Choose the next interrogation question for one player.

    `answered` maps question_id -> chosen option key (None for text/skip) for every step this
    player already went through (answered or skipped). Deterministic: same inputs, same question.
    """
    ordered = sorted(pool, key=lambda q: (q.order_index, q.id))
    eligible = [
        q for q in ordered
        if q.id not in answered and (q.requires_clue_id is None or q.requires_clue_id in visible_clue_ids)
    ]
    for q in eligible:  # follow-ups triggered by this player's own answers come first
        if q.follow_up_of_id is not None and q.follow_up_of_id in answered:
            if q.follow_up_option is None or answered[q.follow_up_of_id] == q.follow_up_option:
                return q
    for q in eligible:
        if q.follow_up_of_id is None:
            return q
    return None


def interrogation_total(pool: Iterable[QuestionView], configured: int) -> int:
    """Steps per player: the configured count, capped by the base (non follow-up) questions."""
    base = sum(1 for q in pool if q.follow_up_of_id is None)
    return max(0, min(int(configured), base))


def public_options(kind: str, options: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Options as sent to players: never includes the authored contradiction mapping."""
    if kind != 'choice':
        return []
    out = []
    for item in options:
        if isinstance(item, dict) and item.get('key') and item.get('label'):
            out.append({'key': str(item['key']), 'label': str(item['label'])})
    return out


def detect_contradiction(
    kind: str,
    options: list[dict[str, Any]],
    *,
    option_key: str | None = None,
    text: str | None = None,
    clue_id: int | None = None,
) -> int | None:
    """Return the clue id an answer is authored to contradict, or None.

    choice:   option {key, contradicts_clue_id}
    evidence: option {key: "clue:<id>", contradicts_clue_id}
    text:     option {keywords: [..], contradicts_clue_id}  (any keyword match, normalized Persian)
    """
    for item in options:
        if not isinstance(item, dict) or not item.get('contradicts_clue_id'):
            continue
        target = int(item['contradicts_clue_id'])
        if kind == 'choice' and option_key is not None and str(item.get('key')) == option_key:
            return target
        if kind == 'evidence' and clue_id is not None and str(item.get('key')) == f'clue:{clue_id}':
            return target
        if kind == 'text' and text:
            haystack = normalize_fa(text)
            for word in item.get('keywords') or []:
                if normalize_fa(str(word)) and normalize_fa(str(word)) in haystack:
                    return target
    return None


def clue_visible_to(visibility: str, viewer_team: str | None, *, game_over: bool = False) -> bool:
    if game_over or visibility == 'public':
        return True
    return viewer_team is not None and visibility == viewer_team


def authored_contradiction(a: dict[str, Any], b: dict[str, Any]) -> bool:
    """True when either clue is authored as contradicting the other."""
    return a.get('contradicts_clue_id') == b.get('id') or b.get('contradicts_clue_id') == a.get('id')


def contradictions_among(clues: list[dict[str, Any]]) -> list[tuple[int, int]]:
    pairs = []
    for a, b in combinations(clues, 2):
        if authored_contradiction(a, b):
            pairs.append(tuple(sorted((a['id'], b['id']))))
    return sorted(set(pairs))


def entity_edges(clues: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Possible relations: two clues mentioning the same person, place, time or object."""
    seen: dict[tuple[str, str], list[int]] = {}
    labels: dict[tuple[str, str], str] = {}
    for clue in clues:
        for ent in clue.get('entities') or []:
            if not isinstance(ent, dict) or not ent.get('label'):
                continue
            key = (str(ent.get('type') or 'object'), normalize_fa(str(ent['label'])))
            seen.setdefault(key, []).append(clue['id'])
            labels.setdefault(key, str(ent['label']).strip())  # first spelling wins
    edges = []
    for key, ids in seen.items():
        unique = sorted(set(ids))
        for a, b in combinations(unique, 2):
            edges.append({'from': a, 'to': b, 'type': key[0], 'label': labels[key]})
    return sorted(edges, key=lambda e: (e['from'], e['to'], e['type'], e['label']))


def normalize_link(a: int, b: int) -> tuple[int, int]:
    if a == b:
        raise ValueError('a clue cannot be linked to itself')
    return (a, b) if a < b else (b, a)


def investigation_progress(discovered: int, checked: int, links: int, hypotheses: int) -> int:
    """0-100 progress meter: reviewing evidence matters most, then connecting and theorising."""
    if discovered <= 0:
        return 0
    review = min(1.0, checked / discovered)
    connect = min(1.0, links / max(1, discovered - 1))
    theory = 1.0 if hypotheses else 0.0
    return round(100 * (0.6 * review + 0.25 * connect + 0.15 * theory))
