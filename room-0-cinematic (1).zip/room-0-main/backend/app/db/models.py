from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


class User(Base):
    __tablename__ = 'users'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True, nullable=False)
    username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    ban_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    role: Mapped[str] = mapped_column(String(32), default='player', nullable=False, index=True)
    display_name: Mapped[str | None] = mapped_column(String(64), nullable=True)
    games_played: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    games_won: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class AppSetting(Base):
    __tablename__ = 'app_settings'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    key: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    value: Mapped[str | None] = mapped_column(Text, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class TableModel(Base):
    __tablename__ = 'tables'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default='waiting', nullable=False)
    max_players: Mapped[int] = mapped_column(Integer, default=6, nullable=False)
    spectator_capacity: Mapped[int] = mapped_column(Integer, default=4, nullable=False)
    start_time: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    host_user_id: Mapped[int | None] = mapped_column(ForeignKey('users.id'), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    # JSON: interrogation_questions / interrogation_seconds / answer_seconds / vote_seconds
    settings_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    reservations: Mapped[list['Reservation']] = relationship(back_populates='table')
    waitlist_entries: Mapped[list['WaitlistEntry']] = relationship(back_populates='table')
    spectators: Mapped[list['Spectator']] = relationship(back_populates='table')
    games: Mapped[list['Game']] = relationship(back_populates='table')


class Reservation(Base):
    __tablename__ = 'reservations'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    table_id: Mapped[int] = mapped_column(ForeignKey('tables.id'), nullable=False)
    seat_index: Mapped[int | None] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(32), default='pending', nullable=False)
    is_confirmed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    requested_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    table: Mapped['TableModel'] = relationship(back_populates='reservations')

    __table_args__ = (
        # one active reservation per user, one active reservation per seat -> race-proof capacity
        Index('uq_active_reservation_user', 'user_id', unique=True,
              postgresql_where=text("status IN ('pending','confirmed')"), sqlite_where=text("status IN ('pending','confirmed')")),
        Index('uq_active_reservation_seat', 'table_id', 'seat_index', unique=True,
              postgresql_where=text("status IN ('pending','confirmed')"), sqlite_where=text("status IN ('pending','confirmed')")),
    )


class WaitlistEntry(Base):
    __tablename__ = 'waitlist_entries'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    table_id: Mapped[int] = mapped_column(ForeignKey('tables.id'), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    position: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    table: Mapped['TableModel'] = relationship(back_populates='waitlist_entries')

    __table_args__ = (
        UniqueConstraint('table_id', 'user_id', name='uq_waitlist_table_user'),
        Index('uq_waitlist_table_position', 'table_id', 'position', unique=True),
    )


class Spectator(Base):
    __tablename__ = 'spectators'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    table_id: Mapped[int] = mapped_column(ForeignKey('tables.id'), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    joined_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    table: Mapped['TableModel'] = relationship(back_populates='spectators')

    __table_args__ = (
        Index('uq_active_spectator_user', 'table_id', 'user_id', unique=True,
              postgresql_where=text('is_active IS TRUE'), sqlite_where=text('is_active = 1')),
    )


class Game(Base):
    __tablename__ = 'games'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    table_id: Mapped[int] = mapped_column(ForeignKey('tables.id'), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default='created', nullable=False)
    case_id: Mapped[int | None] = mapped_column(ForeignKey('cases.id'), nullable=True)
    phase: Mapped[str | None] = mapped_column(String(16), nullable=True)
    round_no: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    phase_deadline: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    winner: Mapped[str | None] = mapped_column(String(32), nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    settings_json: Mapped[str | None] = mapped_column(Text, nullable=True)  # frozen copy of table settings
    interrogation_index: Mapped[int] = mapped_column(Integer, default=0, server_default='0', nullable=False)
    phase_started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    table: Mapped['TableModel'] = relationship(back_populates='games')

    __table_args__ = (
        # at most one running game per table
        Index('uq_running_game_table', 'table_id', unique=True,
              postgresql_where=text("status = 'started'"), sqlite_where=text("status = 'started'")),
    )


class GamePlayer(Base):
    __tablename__ = 'game_players'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    role_name: Mapped[str] = mapped_column(String(64), nullable=False)
    is_alive: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_spectator: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    team: Mapped[str | None] = mapped_column(String(32), nullable=True)
    eliminated_round: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ready_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)  # finished the case-file briefing

    __table_args__ = (UniqueConstraint('game_id', 'user_id', name='uq_game_player'),)


class CaseModel(Base):
    __tablename__ = 'cases'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    slug: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    difficulty: Mapped[str] = mapped_column(String(32), default='medium', nullable=False)
    is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    code: Mapped[str | None] = mapped_column(String(32), nullable=True)
    objective: Mapped[str | None] = mapped_column(Text, nullable=True)
    briefing_json: Mapped[str | None] = mapped_column(Text, nullable=True)  # [{label, value}] shown when the file opens


class Question(Base):
    __tablename__ = 'questions'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey('cases.id'), nullable=False)
    prompt: Mapped[str] = mapped_column(Text, nullable=False)
    order_index: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    # 'round' = discussion question of a voting round; 'interrogation' = pre-stage targeted question
    stage: Mapped[str] = mapped_column(String(16), default='round', server_default='round', nullable=False)
    kind: Mapped[str] = mapped_column(String(16), default='text', server_default='text', nullable=False)  # text|choice|evidence
    options_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    requires_clue_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    follow_up_of_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    follow_up_option: Mapped[str | None] = mapped_column(String(64), nullable=True)


class Clue(Base):
    __tablename__ = 'clues'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey('cases.id'), nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    visibility: Mapped[str] = mapped_column(String(32), default='public', nullable=False)  # public|detectives|infiltrators|alliance
    trigger_condition: Mapped[str | None] = mapped_column(String(255), nullable=True)
    slug: Mapped[str | None] = mapped_column(String(64), nullable=True)
    title: Mapped[str | None] = mapped_column(String(160), nullable=True)
    kind: Mapped[str] = mapped_column(String(24), default='document', server_default='document', nullable=False)
    importance: Mapped[str] = mapped_column(String(16), default='normal', server_default='normal', nullable=False)
    unlock_round: Mapped[int | None] = mapped_column(Integer, nullable=True)  # 0 = known at start, n = round n
    entities_json: Mapped[str | None] = mapped_column(Text, nullable=True)  # [{type: person|place|time|object, label}]
    contradicts_clue_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    media_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    order_index: Mapped[int] = mapped_column(Integer, default=0, server_default='0', nullable=False)


class AdminUser(Base):
    __tablename__ = 'admin_users'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    role: Mapped[str] = mapped_column(String(64), default='moderator', nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class AuthSession(Base):
    """One row per issued access token; lets us revoke tokens server-side."""

    __tablename__ = 'auth_sessions'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    jti: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class InitDataUse(Base):
    """Fingerprint (sha256) of every Telegram initData string exchanged for a session."""

    __tablename__ = 'init_data_uses'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    data_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    uses: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    first_used_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class GameAnswer(Base):
    __tablename__ = 'game_answers'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), index=True, nullable=False)
    round_no: Mapped[int] = mapped_column(Integer, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (UniqueConstraint('game_id', 'round_no', 'user_id', name='uq_answer_once'),)


class GameVote(Base):
    __tablename__ = 'game_votes'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), index=True, nullable=False)
    round_no: Mapped[int] = mapped_column(Integer, nullable=False)
    voter_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    target_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (UniqueConstraint('game_id', 'round_no', 'voter_id', name='uq_vote_once'),)


class GameEvent(Base):
    """Public, append-only game history. Never contains secret information (roles stay out until revealed)."""

    __tablename__ = 'game_events'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), index=True, nullable=False)
    type: Mapped[str] = mapped_column(String(48), nullable=False)
    payload: Mapped[str] = mapped_column(Text, nullable=False, default='{}')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class AdminAction(Base):
    """Append-only audit log of moderation / management actions."""

    __tablename__ = 'admin_actions'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admin_user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True, nullable=False)
    action: Mapped[str] = mapped_column(String(48), nullable=False)
    target_user_id: Mapped[int | None] = mapped_column(ForeignKey('users.id'), index=True, nullable=True)
    target_table_id: Mapped[int | None] = mapped_column(ForeignKey('tables.id'), nullable=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


# ---------------------------------------------------------------- interrogation & investigation
class InterrogationAnswer(Base):
    """One answer (or a recorded skip) per player per interrogation step. Server-chosen question."""

    __tablename__ = 'interrogation_answers'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), index=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    index_no: Mapped[int] = mapped_column(Integer, nullable=False)
    question_id: Mapped[int] = mapped_column(ForeignKey('questions.id'), nullable=False)
    kind: Mapped[str] = mapped_column(String(16), nullable=False)
    text: Mapped[str | None] = mapped_column(Text, nullable=True)
    option_key: Mapped[str | None] = mapped_column(String(64), nullable=True)
    clue_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    response_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    contradiction_clue_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    skipped: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        UniqueConstraint('game_id', 'user_id', 'index_no', name='uq_interrogation_step'),
        UniqueConstraint('game_id', 'user_id', 'question_id', name='uq_interrogation_question'),
    )


class GameClue(Base):
    """A clue that has been discovered in a game (server-controlled; one row per clue per game)."""

    __tablename__ = 'game_clues'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), index=True, nullable=False)
    clue_id: Mapped[int] = mapped_column(ForeignKey('clues.id'), nullable=False)
    round_no: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    discovered_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (UniqueConstraint('game_id', 'clue_id', name='uq_game_clue'),)


class ClueNote(Base):
    """A player's private review state for one clue: flag, status and note."""

    __tablename__ = 'clue_notes'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), index=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    clue_id: Mapped[int] = mapped_column(ForeignKey('clues.id'), nullable=False)
    flagged: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    status: Mapped[str] = mapped_column(String(16), default='new', nullable=False)  # new|reviewing|checked
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (UniqueConstraint('game_id', 'user_id', 'clue_id', name='uq_clue_note'),)


class ClueLink(Base):
    """A connection a player drew on their private investigation board (stored with from < to)."""

    __tablename__ = 'clue_links'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), index=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    from_clue_id: Mapped[int] = mapped_column(ForeignKey('clues.id'), nullable=False)
    to_clue_id: Mapped[int] = mapped_column(ForeignKey('clues.id'), nullable=False)
    label: Mapped[str | None] = mapped_column(String(120), nullable=True)
    is_contradiction: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (UniqueConstraint('game_id', 'user_id', 'from_clue_id', 'to_clue_id', name='uq_clue_link'),)


class Hypothesis(Base):
    """A player's written theory with cited clues. `request_id` makes double-submits idempotent."""

    __tablename__ = 'hypotheses'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey('games.id'), index=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), nullable=False)
    request_id: Mapped[str] = mapped_column(String(64), nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    clue_ids_json: Mapped[str] = mapped_column(Text, nullable=False, default='[]')
    suspect_user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (UniqueConstraint('game_id', 'user_id', 'request_id', name='uq_hypothesis_request'),)
