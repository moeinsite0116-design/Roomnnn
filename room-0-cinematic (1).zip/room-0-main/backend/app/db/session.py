from __future__ import annotations

from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import settings
from app.db.base import Base


def _build_database_url() -> str:
    url = settings.database_url
    if url.startswith('postgresql+psycopg'):
        return url.replace('postgresql+psycopg', 'postgresql+asyncpg', 1)
    return url


def _engine_kwargs(url: str) -> dict:
    if url.startswith('postgresql'):
        # survive DB restarts / idle connection drops; fail fast instead of hanging forever
        return {'pool_pre_ping': True, 'pool_recycle': 1800, 'pool_size': 5, 'max_overflow': 5, 'pool_timeout': 10,
                'connect_args': {'timeout': 10, 'command_timeout': 30}}
    return {}


engine = create_async_engine(_build_database_url(), echo=False, future=True, **_engine_kwargs(_build_database_url()))
async_session = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with async_session() as session:
        yield session
