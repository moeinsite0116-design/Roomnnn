from __future__ import annotations

from pydantic import BaseModel, Field, field_validator


class HealthResponse(BaseModel):
    status: str
    service: str


class OverviewResponse(BaseModel):
    app_name: str
    environment: str
    livekit_enabled: bool
    demo_mode: bool


class AnswerRequest(BaseModel):
    text: str = Field(min_length=1, max_length=500)

    @field_validator('text', mode='before')
    @classmethod
    def _trim_text(cls, value):
        if isinstance(value, str):
            value = value.strip()
            if not value:
                raise ValueError('text must not be blank')
        return value


class StartGameRequest(BaseModel):
    case_id: int | None = None


class InterrogationAnswerRequest(BaseModel):
    question_id: int = Field(gt=0)
    option_key: str | None = Field(default=None, max_length=64)
    text: str | None = Field(default=None, max_length=300)
    clue_id: int | None = Field(default=None, gt=0)

    @field_validator('text', mode='before')
    @classmethod
    def _trim(cls, value):
        return value.strip() if isinstance(value, str) else value


class ClueNoteRequest(BaseModel):
    flagged: bool | None = None
    status: str | None = Field(default=None, pattern='^(new|reviewing|checked)$')
    note: str | None = Field(default=None, max_length=1000)


class ClueLinkRequest(BaseModel):
    from_clue_id: int = Field(gt=0)
    to_clue_id: int = Field(gt=0)
    label: str | None = Field(default=None, max_length=120)


class HypothesisRequest(BaseModel):
    request_id: str = Field(min_length=8, max_length=64, pattern='^[A-Za-z0-9_-]+$')
    text: str = Field(min_length=3, max_length=600)
    clue_ids: list[int] = Field(default_factory=list, max_length=8)
    suspect_user_id: int | None = Field(default=None, gt=0)

    @field_validator('text', mode='before')
    @classmethod
    def _trim_text(cls, value):
        if isinstance(value, str):
            value = value.strip()
            if len(value) < 3:
                raise ValueError('hypothesis is too short')
        return value
