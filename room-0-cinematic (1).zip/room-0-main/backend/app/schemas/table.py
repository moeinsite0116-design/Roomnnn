from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class TableOut(BaseModel):
    id: int
    name: str
    status: str
    max_players: int = 6
    spectator_capacity: int = 4
    start_time: datetime | None = None


class TableCreate(BaseModel):
    name: str = Field(default='میز جدید', min_length=1, max_length=64)
    interrogation_questions: int | None = Field(default=None, ge=0, le=6)
    interrogation_seconds: int | None = Field(default=None, ge=20, le=180)
    answer_seconds: int | None = Field(default=None, ge=20, le=300)
    vote_seconds: int | None = Field(default=None, ge=20, le=300)

    @field_validator('name', mode='before')
    @classmethod
    def _trim_name(cls, value):
        if isinstance(value, str):
            value = value.strip()
            if not value:
                raise ValueError('name must not be blank')
        return value


class ReservationCreate(BaseModel):
    seat_index: int | None = Field(default=None, ge=1, le=6)


class ReservationOut(BaseModel):
    id: int
    table_id: int
    status: str
    is_confirmed: bool
