from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator


class TelegramUserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    telegram_id: int
    username: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    display_name: str | None = None
    role: str = 'player'
    games_played: int = 0
    games_won: int = 0
    created_at: datetime | None = None


class LoginRequest(BaseModel):
    init_data: str = Field(min_length=10, max_length=4096)


class AuthResponse(BaseModel):
    ok: bool = True
    access_token: str
    token_type: str = 'bearer'
    expires_at: datetime
    user: TelegramUserOut


class ProfileUpdate(BaseModel):
    display_name: str = Field(min_length=1, max_length=32)

    @field_validator('display_name', mode='before')
    @classmethod
    def _trim_display_name(cls, value):
        if isinstance(value, str):
            value = value.strip()
            if not value:
                raise ValueError('display_name must not be blank')
        return value


class TableCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    status: str = 'waiting'
    max_players: int = 6
    spectator_capacity: int = 4


class TableResponse(BaseModel):
    id: int
    name: str
    status: str
    max_players: int
    spectator_capacity: int


class PlayerActionRequest(BaseModel):
    action_type: str
    payload: dict | None = None


class VoteRequest(BaseModel):
    target_user_id: int
