from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.config import settings
from app.db.models import Reservation, TableModel, User
from app.db.session import get_db
from app.services.livekit_service import LiveKitTokenError, build_livekit_token, build_room_snapshot

router = APIRouter(prefix='/api/v1/livekit', tags=['livekit'])


class LiveKitTokenRequest(BaseModel):
    table_id: int


@router.get('/status')
def livekit_status() -> dict:
    return {
        'enabled': settings.enable_livekit,
        'url': settings.livekit_url,
        'status': 'configured' if settings.enable_livekit else 'disabled',
        'message': 'LiveKit is active and ready for voice rooms.' if settings.enable_livekit else 'LiveKit is not enabled in this environment.',
    }


@router.post('/token')
async def issue_livekit_token(payload: LiveKitTokenRequest, user: User = Depends(get_current_user),
                              db: AsyncSession = Depends(get_db)) -> dict:
    """Identity, room and publish rights are decided by the server, never by client-sent fields."""
    if not settings.enable_livekit:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail='LiveKit is disabled in this environment',
        )
    if await db.get(TableModel, payload.table_id) is None:
        raise HTTPException(status_code=404, detail='Table not found')

    seated = await db.scalar(select(Reservation.id).where(
        Reservation.table_id == payload.table_id, Reservation.user_id == user.id, Reservation.status == 'confirmed'))
    role = 'player' if seated else 'spectator'
    room_name = f'room0-table-{payload.table_id}'

    try:
        token = build_livekit_token(
            user_id=user.id,
            identity=f'user-{user.id}',
            room_name=room_name,
            role=role,
            can_publish=role == 'player',
        )
    except LiveKitTokenError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {
        'token': token,
        'snapshot': build_room_snapshot(payload.table_id, is_enabled=True, user_role=role),
        'room_name': room_name,
    }
