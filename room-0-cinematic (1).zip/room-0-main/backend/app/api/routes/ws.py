from __future__ import annotations

import asyncio
import json
import logging
from collections import deque
from fnmatch import fnmatch
from time import monotonic

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.api.deps import resolve_token
from app.core.config import settings
from app.db import session as db_session
from app.db.models import TableModel
from app.services import game_service
from app.services.realtime import Connection, realtime_hub
from app.services.table_service import can_access_table

logger = logging.getLogger('room0.ws')
router = APIRouter(prefix='/ws', tags=['realtime'])

CLOSE_UNAUTHORIZED = 4401
CLOSE_FORBIDDEN = 4403
CLOSE_NOT_FOUND = 4404


def _origin_allowed(origin: str | None) -> bool:
    if not origin:  # non-browser clients; browsers always send Origin
        return True
    allowed = list(settings.cors_origins) + list(settings.telegram_allowed_origins)
    return any(fnmatch(origin, pattern) for pattern in allowed)


async def _receive_json(websocket: WebSocket, timeout: float) -> dict | None:
    raw = await asyncio.wait_for(websocket.receive_text(), timeout=timeout)
    if len(raw.encode('utf-8')) > settings.ws_max_message_bytes:
        await websocket.close(code=1009)
        return None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def _after_id(value) -> int:
    return value if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else 0


@router.websocket('/table/{table_id}')
async def table_realtime(websocket: WebSocket, table_id: int) -> None:
    """Live channel for one table.

    Protocol: connect -> first message must be {"type":"auth","token":"<access token>","after_event_id":N?}
    (the token is never put in the URL). Then the server pushes `ready`, `snapshot` (per-viewer), `events`.
    Client messages: ping, resync. Game actions are sent through the REST API, not here.
    """
    if not _origin_allowed(websocket.headers.get('origin')):
        await websocket.close(code=1008)
        return
    await websocket.accept()
    conn: Connection | None = None
    try:
        first = await _receive_json(websocket, settings.ws_auth_timeout_seconds)
        if first is None:
            return
        token = first.get('token')
        if first.get('type') != 'auth' or not isinstance(token, str):
            await websocket.close(code=CLOSE_UNAUTHORIZED)
            return
        try:
            async with db_session.async_session() as db:
                user, _ = await resolve_token(db, token)
                table = await db.get(TableModel, table_id)
                table_exists = table is not None
                user_id = user.id
                if table is not None and not await can_access_table(db, table_id, user):
                    await websocket.close(code=CLOSE_FORBIDDEN)
                    return
        except ValueError:
            await websocket.close(code=CLOSE_UNAUTHORIZED)
            return
        except PermissionError:
            await websocket.close(code=CLOSE_FORBIDDEN)
            return
        if not table_exists:
            await websocket.close(code=CLOSE_NOT_FOUND)
            return

        conn = Connection(websocket=websocket, user_id=user_id, table_id=table_id)
        realtime_hub.add(conn)
        await realtime_hub.send(conn, {'event': 'ready', 'server_time': game_service.utcnow().isoformat()})
        await realtime_hub.push_snapshot(conn)
        await _send_backlog(conn, _after_id(first.get('after_event_id')))
        await realtime_hub.notify(table_id)  # presence changed for everybody else

        recent: deque[float] = deque()
        while True:
            data = await _receive_json(websocket, settings.ws_idle_timeout_seconds)
            if data is None:
                return
            now = monotonic()
            recent.append(now)
            while recent and now - recent[0] > 10:
                recent.popleft()
            if len(recent) > settings.ws_rate_limit_messages:
                await websocket.close(code=1008)
                return

            kind = data.get('type')
            if kind == 'ping':
                try:  # re-validate token and current table membership
                    async with db_session.async_session() as db:
                        current_user, _ = await resolve_token(db, token)
                        if not await can_access_table(db, table_id, current_user):
                            await websocket.close(code=CLOSE_FORBIDDEN)
                            return
                except ValueError:
                    await websocket.close(code=CLOSE_UNAUTHORIZED)
                    return
                except PermissionError:
                    await websocket.close(code=CLOSE_FORBIDDEN)
                    return
                await realtime_hub.send(conn, {'event': 'pong', 'server_time': game_service.utcnow().isoformat()})
            elif kind == 'resync':
                try:
                    async with db_session.async_session() as db:
                        current_user, _ = await resolve_token(db, token)
                        if not await can_access_table(db, table_id, current_user):
                            await websocket.close(code=CLOSE_FORBIDDEN)
                            return
                except ValueError:
                    await websocket.close(code=CLOSE_UNAUTHORIZED)
                    return
                except PermissionError:
                    await websocket.close(code=CLOSE_FORBIDDEN)
                    return
                await realtime_hub.push_snapshot(conn)
                await _send_backlog(conn, _after_id(data.get('after_event_id')))
            else:
                await realtime_hub.send(conn, {'event': 'error', 'code': 'unknown_type'})
    except (WebSocketDisconnect, asyncio.TimeoutError):
        pass
    except Exception:
        logger.exception('websocket error')
    finally:
        if conn is not None:
            realtime_hub.remove(conn)
            # not awaited: the handler may already be cancelled here, and presence must still be announced
            realtime_hub.schedule(table_id)
        try:
            await websocket.close()
        except Exception:
            pass


async def _send_backlog(conn: Connection, after_id: int) -> None:
    """Public game events the client missed while disconnected."""
    
    from app.db.models import Game

    async with db_session.async_session() as db:
        game_id = await db.scalar(select(Game.id).where(Game.table_id == conn.table_id).order_by(Game.id.desc()).limit(1))
        if game_id is None:
            return
        items = await game_service.list_events(db, game_id, after_id)
    if items:
        await realtime_hub.send(conn, {'event': 'events', 'game_id': game_id, 'items': items})
