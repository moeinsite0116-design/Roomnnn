from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.db.models import Game, GamePlayer, User
from app.db.session import get_db
from app.schemas.auth import ProfileUpdate, TelegramUserOut

router = APIRouter(prefix='/api/v1/users', tags=['users'])


@router.get('/me', response_model=TelegramUserOut)
async def my_profile(user: User = Depends(get_current_user)) -> TelegramUserOut:
    """Profile and stats of the authenticated user only."""
    return TelegramUserOut.model_validate(user)


@router.patch('/me', response_model=TelegramUserOut)
async def update_my_profile(
    payload: ProfileUpdate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TelegramUserOut:
    user.display_name = payload.display_name.strip()
    await db.commit()
    await db.refresh(user)
    return TelegramUserOut.model_validate(user)


@router.get('/me/games')
async def my_game_history(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    """Finished games the authenticated user took part in (roles are public once a game is over)."""
    rows = (await db.execute(
        select(Game, GamePlayer).join(GamePlayer, GamePlayer.game_id == Game.id)
        .where(GamePlayer.user_id == user.id, Game.status.in_(['finished', 'aborted']))
        .order_by(Game.id.desc()).limit(50)
    )).all()
    winning_role = {'detectives': 'detective', 'spies': 'spy', 'independent': 'independent'}
    return {'items': [
        {
            'game_id': g.id, 'status': g.status, 'winner': g.winner, 'role': p.role_name,
            'won': bool(g.winner) and winning_role.get(g.winner) == p.role_name,
            'finished_at': g.finished_at.isoformat() if g.finished_at else None,
        }
        for g, p in rows
    ]}
