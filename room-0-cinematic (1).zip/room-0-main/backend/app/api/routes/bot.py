from __future__ import annotations

import hmac
from typing import Annotated

from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.exc import IntegrityError
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core import roles
from app.db.models import User
from app.db.session import get_db

router = APIRouter(prefix='/api/v1/bot', tags=['bot'])


class BotProfileRequest(BaseModel):
    telegram_id: int = Field(gt=0)


class BotIdentifyRequest(BotProfileRequest):
    username: str | None = Field(default=None, max_length=255)
    first_name: str | None = Field(default=None, max_length=255)
    last_name: str | None = Field(default=None, max_length=255)


def _verify_bot_secret(expected: str, supplied: str | None) -> None:
    if not expected or not supplied or not hmac.compare_digest(supplied, expected):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Not authenticated')


@router.post('/identify')
async def bot_identify(
    payload: BotIdentifyRequest,
    supplied_secret: Annotated[str | None, Header(alias='X-ROOM0-BOT-SECRET')] = None,
    db: AsyncSession = Depends(get_db),
) -> dict:
    _verify_bot_secret(settings.bot_api_secret, supplied_secret)
    user = (await db.execute(select(User).where(User.telegram_id == payload.telegram_id))).scalar_one_or_none()
    if user is None:
        user = User(telegram_id=payload.telegram_id)
        db.add(user)
    user.username, user.first_name, user.last_name = payload.username, payload.first_name, payload.last_name
    if payload.telegram_id in settings.super_admin_telegram_ids:
        user.role, user.is_admin = roles.SUPER_ADMIN, True
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        user = (await db.execute(select(User).where(User.telegram_id == payload.telegram_id))).scalar_one_or_none()
        if user is None:
            raise HTTPException(status_code=409, detail='Concurrent registration, retry')
        user.username, user.first_name, user.last_name = payload.username, payload.first_name, payload.last_name
        await db.commit()
    await db.refresh(user)
    return {'registered': True, 'banned': user.is_banned}


@router.post('/profile')
async def bot_profile(
    payload: BotProfileRequest,
    supplied_secret: Annotated[str | None, Header(alias='X-ROOM0-BOT-SECRET')] = None,
    db: AsyncSession = Depends(get_db),
) -> dict:
    _verify_bot_secret(settings.bot_api_secret, supplied_secret)
    user = (await db.execute(select(User).where(User.telegram_id == payload.telegram_id))).scalar_one_or_none()
    if user is None:
        return {'registered': False}
    return {
        'registered': True,
        'banned': user.is_banned,
        'display_name': user.display_name,
        'first_name': user.first_name,
        'role': user.role,
        'games_played': user.games_played,
        'games_won': user.games_won,
    }
