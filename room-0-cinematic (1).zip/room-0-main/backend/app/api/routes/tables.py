from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.config import settings
from app.db.models import Game, Reservation, Spectator, TableModel, User, WaitlistEntry
from app.db.session import get_db
from app.schemas.game import StartGameRequest
from app.schemas.table import ReservationCreate, TableCreate
from app.services import game_service
from app.services.realtime import schedule_notify
from app.services.table_service import table_summary

router = APIRouter(prefix='/api/v1', tags=['tables'])
ACTIVE = ('pending', 'confirmed')


async def _get_table(db: AsyncSession, table_id: int) -> TableModel:
    table = await db.get(TableModel, table_id)
    if table is None:
        raise HTTPException(status_code=404, detail='Table not found')
    return table


async def _lock_table(db: AsyncSession, table_id: int) -> TableModel:
    # Serialize seat/spectator capacity checks on databases that support row locks (PostgreSQL).
    table = (await db.execute(select(TableModel).where(TableModel.id == table_id).with_for_update())).scalar_one_or_none()
    if table is None:
        raise HTTPException(status_code=404, detail='Table not found')
    return table


async def _expire_stale(db: AsyncSession, table_id: int) -> None:
    """Pending (unconfirmed) reservations older than the TTL free their seat."""
    cutoff = datetime.utcnow() - timedelta(minutes=settings.reservation_ttl_minutes)
    await db.execute(
        update(Reservation)
        .where(Reservation.table_id == table_id, Reservation.status == 'pending', Reservation.requested_at < cutoff)
        .values(status='expired')
    )


async def _active_count(db: AsyncSession, table_id: int) -> int:
    return (await db.scalar(
        select(func.count(Reservation.id)).where(Reservation.table_id == table_id, Reservation.status.in_(ACTIVE))
    )) or 0


async def _my_reservation(db: AsyncSession, table_id: int, user_id: int) -> Reservation | None:
    return (await db.execute(
        select(Reservation).where(
            Reservation.table_id == table_id, Reservation.user_id == user_id, Reservation.status.in_(ACTIVE)
        )
    )).scalar_one_or_none()


@router.get('/tables')
async def list_tables(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    tables = (await db.execute(
        select(TableModel).where(TableModel.status != 'closed').order_by(TableModel.id.asc()))).scalars().all()
    mine = {r.table_id: r for r in (await db.execute(
        select(Reservation).where(Reservation.user_id == user.id, Reservation.status.in_(ACTIVE)))).scalars().all()}
    watching = set((await db.execute(select(Spectator.table_id).where(
        Spectator.user_id == user.id, Spectator.is_active.is_(True)))).scalars().all())
    items = []
    for t in tables:
        summary = await table_summary(db, t)
        r = mine.get(t.id)
        summary['my_reservation'] = {'seat_index': r.seat_index, 'status': r.status} if r else None
        summary['is_spectating'] = t.id in watching
        items.append(summary)
    return {'items': items}


@router.get('/tables/{table_id}')
async def get_table(table_id: int, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    table = await _get_table(db, table_id)
    summary = await table_summary(db, table)
    r = await _my_reservation(db, table_id, user.id)
    summary['my_reservation'] = {'seat_index': r.seat_index, 'status': r.status} if r else None
    return summary


@router.post('/tables', status_code=201)
async def create_table(payload: TableCreate, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    open_tables = (await db.scalar(
        select(func.count(TableModel.id)).where(TableModel.host_user_id == user.id, TableModel.status == 'waiting')
    )) or 0
    if open_tables >= settings.max_open_tables_per_user:
        raise HTTPException(status_code=429, detail='Too many open tables')
    table_cfg = game_service.default_table_settings()
    for key in game_service.SETTING_BOUNDS:
        value = getattr(payload, key)
        if value is not None:
            table_cfg[key] = value
    table = TableModel(name=payload.name.strip(), status='waiting', max_players=settings.min_players,
                       spectator_capacity=4, host_user_id=user.id, settings_json=json.dumps(table_cfg))
    db.add(table)
    await db.commit()
    await db.refresh(table)
    return await table_summary(db, table)


@router.post('/tables/{table_id}/reserve', status_code=201)
async def reserve_table(table_id: int, payload: ReservationCreate, user: User = Depends(get_current_user),
                        db: AsyncSession = Depends(get_db)) -> dict:
    table = await _lock_table(db, table_id)
    if table.status != 'waiting':
        raise HTTPException(status_code=409, detail='Table is not open for reservations')
    await _expire_stale(db, table_id)

    taken_seats = set((await db.execute(
        select(Reservation.seat_index).where(Reservation.table_id == table_id, Reservation.status.in_(ACTIVE))
    )).scalars().all())
    if len(taken_seats) >= table.max_players:
        raise HTTPException(status_code=409, detail='Table is full')
    seat = payload.seat_index
    if seat is None:
        seat = next(i for i in range(1, table.max_players + 1) if i not in taken_seats)
    elif seat > table.max_players or seat in taken_seats:
        raise HTTPException(status_code=409, detail='Seat is not available')

    # Spectator at this table cannot also take a seat.
    spec = await db.scalar(select(Spectator.id).where(
        Spectator.table_id == table_id, Spectator.user_id == user.id, Spectator.is_active.is_(True)))
    if spec:
        raise HTTPException(status_code=409, detail='Leave spectating before taking a seat')

    reservation = Reservation(user_id=user.id, table_id=table_id, seat_index=seat, status='pending',
                              is_confirmed=False, requested_at=datetime.utcnow())
    db.add(reservation)
    await db.execute(WaitlistEntry.__table__.delete().where(
        WaitlistEntry.table_id == table_id, WaitlistEntry.user_id == user.id))
    try:
        await db.commit()  # seat reservation and waitlist removal are atomic
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail='Seat taken or you already hold a reservation')
    await db.refresh(reservation)
    schedule_notify(table_id)
    return {'ok': True, 'reservation_id': reservation.id, 'table_id': table_id,
            'seat_index': reservation.seat_index, 'status': reservation.status}


@router.post('/tables/{table_id}/confirm')
async def confirm_reservation(table_id: int, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    """Confirming presence = being ready to play."""
    await _lock_table(db, table_id)
    reservation = await _my_reservation(db, table_id, user.id)
    if reservation is None:
        raise HTTPException(status_code=404, detail='Reservation not found')
    if reservation.status == 'pending' and reservation.requested_at + timedelta(minutes=settings.reservation_ttl_minutes) < datetime.utcnow():
        reservation.status = 'expired'
        await db.commit()
        raise HTTPException(status_code=410, detail='Reservation expired')
    reservation.status = 'confirmed'
    reservation.is_confirmed = True
    await db.commit()
    schedule_notify(table_id)
    return {'ok': True, 'reservation_id': reservation.id, 'status': 'confirmed'}


@router.post('/tables/{table_id}/cancel')
async def cancel_reservation(table_id: int, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    table = await _lock_table(db, table_id)
    if table.status == 'playing':
        raise HTTPException(status_code=409, detail='Cannot leave a table while a game is running')
    reservation = await _my_reservation(db, table_id, user.id)
    if reservation is None:
        raise HTTPException(status_code=404, detail='Reservation not found')
    reservation.status = 'cancelled'
    await db.commit()
    schedule_notify(table_id)
    return {'ok': True, 'reservation_id': reservation.id, 'status': 'cancelled'}


@router.post('/tables/{table_id}/start')
async def start_table_game(table_id: int, payload: StartGameRequest | None = None, user: User = Depends(get_current_user),
                           db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    game = await game_service.start_game(db, table_id, user, payload.case_id if payload else None)
    return await game_service.get_state(db, game.id, user)


@router.post('/tables/{table_id}/waitlist', status_code=201)
async def join_waitlist(table_id: int, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    # Lock the parent row so concurrent joins receive distinct positions on PostgreSQL.
    table = await _lock_table(db, table_id)
    if table.status == 'closed':
        raise HTTPException(status_code=409, detail='Table is closed')
    if await _my_reservation(db, table_id, user.id):
        raise HTTPException(status_code=409, detail='You already hold a seat at this table')
    for attempt in range(3):
        position = ((await db.scalar(select(func.max(WaitlistEntry.position)).where(
            WaitlistEntry.table_id == table_id))) or 0) + 1
        db.add(WaitlistEntry(table_id=table_id, user_id=user.id, position=position))
        try:
            await db.commit()
            return {'ok': True, 'table_id': table_id, 'position': position}
        except IntegrityError:
            await db.rollback()
            exists = await db.scalar(select(WaitlistEntry.id).where(
                WaitlistEntry.table_id == table_id, WaitlistEntry.user_id == user.id))
            if exists:
                raise HTTPException(status_code=409, detail='You are already on the waitlist')
            if attempt == 2:
                raise HTTPException(status_code=409, detail='Waitlist changed concurrently; retry')
            await _lock_table(db, table_id)
    raise HTTPException(status_code=409, detail='Waitlist changed concurrently; retry')


@router.get('/tables/{table_id}/waitlist')
async def my_waitlist_state(table_id: int, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    """Own position and size only; other users' identities are not exposed."""
    size = (await db.scalar(select(func.count(WaitlistEntry.id)).where(WaitlistEntry.table_id == table_id))) or 0
    mine = await db.scalar(select(WaitlistEntry.position).where(
        WaitlistEntry.table_id == table_id, WaitlistEntry.user_id == user.id))
    return {'size': size, 'my_position': mine}


@router.post('/tables/{table_id}/spectate', status_code=201)
async def spectate(table_id: int, response: Response, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    table = await _lock_table(db, table_id)
    if table.status == 'closed':
        raise HTTPException(status_code=409, detail='Table is closed')
    if await _my_reservation(db, table_id, user.id):
        raise HTTPException(status_code=409, detail='Seated players cannot spectate their own table')
    already_spectating = await db.scalar(select(Spectator.id).where(
        Spectator.table_id == table_id, Spectator.user_id == user.id, Spectator.is_active.is_(True)))
    if already_spectating:
        response.status_code = 200
        return {'ok': True, 'table_id': table_id}
    spectator_count = (await db.scalar(select(func.count(Spectator.id)).where(
        Spectator.table_id == table_id, Spectator.is_active.is_(True)))) or 0
    if spectator_count >= table.spectator_capacity:
        raise HTTPException(status_code=409, detail='Spectator capacity reached')
    db.add(Spectator(table_id=table_id, user_id=user.id, is_active=True))
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        existing = await db.scalar(select(Spectator.id).where(
            Spectator.table_id == table_id, Spectator.user_id == user.id, Spectator.is_active.is_(True)))
        if existing:
            response.status_code = 200
            return {'ok': True, 'table_id': table_id}
        raise HTTPException(status_code=409, detail='Spectator capacity reached')
    schedule_notify(table_id)
    return {'ok': True, 'table_id': table_id}


@router.delete('/tables/{table_id}/spectate')
async def stop_spectating(table_id: int, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    await db.execute(update(Spectator).where(
        Spectator.table_id == table_id, Spectator.user_id == user.id).values(is_active=False))
    await db.commit()
    schedule_notify(table_id)
    return {'ok': True}


@router.get('/reservations/me')
async def my_reservations(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict:
    rows = (await db.execute(
        select(Reservation).where(Reservation.user_id == user.id).order_by(Reservation.requested_at.desc()).limit(50)
    )).scalars().all()
    return {'items': [
        {'id': r.id, 'table_id': r.table_id, 'status': r.status, 'seat_index': r.seat_index, 'is_confirmed': r.is_confirmed}
        for r in rows
    ]}
