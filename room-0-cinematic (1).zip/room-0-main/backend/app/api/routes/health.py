from __future__ import annotations

from fastapi import APIRouter

from app.core.config import settings

router = APIRouter(tags=['health'])


@router.get('/api/health')
async def health_check() -> dict[str, str]:
    return {'status': 'ok', 'service': settings.app_name}


@router.get('/api/v1/overview')
async def overview() -> dict[str, str | bool]:
    return {
        'app_name': settings.app_name,
        'environment': settings.environment,
        'livekit_enabled': settings.enable_livekit,
        'demo_mode': settings.enable_demo_mode,
    }
