from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, require_roles
from app.core import roles
from app.db.models import CaseModel, Game, User
from app.db.session import get_db
from app.schemas.auth import VoteRequest
from app.schemas.game import (AnswerRequest, ClueLinkRequest, ClueNoteRequest, HypothesisRequest,
                              InterrogationAnswerRequest)
from app.services import game_service, investigation_service

router = APIRouter(prefix='/api/v1', tags=['games'])


@router.get('/games/health')
async def games_health() -> dict[str, str]:
    return {'status': 'ok', 'module': 'games'}


@router.get('/games/{game_id}')
async def game_state(game_id: int, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    """Viewer-aware state: roles of others are never included until revealed by the rules."""
    return await game_service.get_state(db, game_id, user)


@router.post('/games/{game_id}/answer')
async def submit_answer(game_id: int, payload: AnswerRequest, user: User = Depends(get_current_user),
                        db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await game_service.submit_answer(db, game_id, user, payload.text)


@router.post('/games/{game_id}/vote')
async def submit_vote(game_id: int, payload: VoteRequest, user: User = Depends(get_current_user),
                      db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await game_service.submit_vote(db, game_id, user, payload.target_user_id)


@router.get('/games/{game_id}/events')
async def game_events(game_id: int, after_id: int = Query(default=0, ge=0), _: User = Depends(get_current_user),
                      db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return {'items': await game_service.list_events(db, game_id, after_id)}


@router.get('/games/{game_id}/clues')
async def list_clues(game_id: int, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    """Discovered clues the viewer may see (public + own team). Kept for older clients: id/text present."""
    data = await investigation_service.board(db, game_id, user)
    return {'items': data['clues']}


@router.get('/games/{game_id}/board')
async def investigation_board(game_id: int, user: User = Depends(get_current_user),
                              db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await investigation_service.board(db, game_id, user)


@router.put('/games/{game_id}/clues/{clue_id}/note')
async def save_clue_note(game_id: int, clue_id: int, payload: ClueNoteRequest, user: User = Depends(get_current_user),
                         db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await investigation_service.save_note(db, game_id, user, clue_id, flagged=payload.flagged,
                                                 status=payload.status, note=payload.note)


@router.post('/games/{game_id}/links')
async def add_clue_link(game_id: int, payload: ClueLinkRequest, user: User = Depends(get_current_user),
                        db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await investigation_service.add_link(db, game_id, user, payload.from_clue_id, payload.to_clue_id, payload.label)


@router.delete('/games/{game_id}/links/{link_id}')
async def delete_clue_link(game_id: int, link_id: int, user: User = Depends(get_current_user),
                           db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await investigation_service.delete_link(db, game_id, user, link_id)


@router.post('/games/{game_id}/hypotheses')
async def add_hypothesis(game_id: int, payload: HypothesisRequest, user: User = Depends(get_current_user),
                         db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await investigation_service.add_hypothesis(db, game_id, user, request_id=payload.request_id, text=payload.text,
                                                      clue_ids=payload.clue_ids, suspect_user_id=payload.suspect_user_id)


@router.post('/games/{game_id}/interrogation/answer')
async def submit_interrogation_answer(game_id: int, payload: InterrogationAnswerRequest,
                                      user: User = Depends(get_current_user),
                                      db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await game_service.submit_interrogation_answer(
        db, game_id, user, question_id=payload.question_id, option_key=payload.option_key,
        text=payload.text, clue_id=payload.clue_id)


@router.post('/games/{game_id}/briefing/ready')
async def briefing_ready(game_id: int, user: User = Depends(get_current_user),
                         db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    return await game_service.briefing_ready(db, game_id, user)


@router.post('/games/{game_id}/finish')
async def force_finish_game(game_id: int, admin: User = Depends(require_roles(roles.GAME_ADMIN)),
                            db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    """Admin-only abort: no winner, no stats. Players cannot end a game themselves."""
    game = await db.get(Game, game_id)
    if game is None:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail='Game not found')
    done = await game_service.abort_game(db, game_id)
    if done:
        from datetime import datetime

        from app.db.models import AdminAction
        db.add(AdminAction(admin_user_id=admin.id, action='game.abort', target_table_id=game.table_id,
                           reason=f'game {game_id}', created_at=datetime.utcnow()))
        await db.commit()
    return {'ok': True, 'game_id': game_id, 'status': 'aborted' if done else 'already_finished'}


@router.get('/cases')
async def list_cases(_: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    cases = (await db.execute(
        select(CaseModel).where(CaseModel.is_published.is_(True), CaseModel.is_deleted.is_(False))
    )).scalars().all()
    return {'items': [{'id': c.id, 'title': c.title, 'difficulty': c.difficulty} for c in cases]}
