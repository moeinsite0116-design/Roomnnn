from __future__ import annotations

import hashlib
import logging
import secrets
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_context, get_current_user
from app.core import roles
from app.core.config import settings
from app.core.security import create_access_token, validate_telegram_init_data
from app.db.models import AuthSession, InitDataUse, User
from app.db.session import get_db
from app.schemas.auth import AuthResponse, LoginRequest, TelegramUserOut

logger = logging.getLogger('room0.auth')
router = APIRouter(prefix='/api/v1/auth', tags=['auth'])

_BAD_CREDENTIALS = 'Invalid Telegram credentials'


async def _register_init_data_use(db: AsyncSession, init_data: str) -> None:
    """Replay limit: one initData string may mint at most `init_data_max_uses` sessions."""
    digest = hashlib.sha256(init_data.encode('utf-8')).hexdigest()
    row = (
        await db.execute(select(InitDataUse).where(InitDataUse.data_hash == digest).with_for_update())
    ).scalar_one_or_none()
    if row is None:
        db.add(InitDataUse(data_hash=digest))
        try:
            await db.flush()
        except IntegrityError:  # concurrent first use of the same string
            await db.rollback()
            raise HTTPException(status_code=409, detail='Concurrent login, retry')
        return
    if row.uses >= settings.init_data_max_uses:
        raise HTTPException(status_code=401, detail=_BAD_CREDENTIALS)
    row.uses += 1


@router.post('/telegram', response_model=AuthResponse)
async def telegram_login(payload: LoginRequest, db: AsyncSession = Depends(get_db)) -> AuthResponse:
    """Exchange signed Telegram initData for a server-tracked access token."""
    try:
        data = validate_telegram_init_data(payload.init_data, settings.telegram_bot_token)
    except ValueError:
        raise HTTPException(status_code=401, detail=_BAD_CREDENTIALS)

    tg_user = data.get('user')
    if (not isinstance(tg_user, dict) or not isinstance(tg_user.get('id'), int)
            or isinstance(tg_user.get('id'), bool) or tg_user['id'] <= 0):
        raise HTTPException(status_code=401, detail=_BAD_CREDENTIALS)
    telegram_id = tg_user['id']
    if telegram_id > 9_223_372_036_854_775_807:
        raise HTTPException(status_code=401, detail=_BAD_CREDENTIALS)
    for field in ('username', 'first_name', 'last_name'):
        value = tg_user.get(field)
        if value is not None and (not isinstance(value, str) or len(value) > 255):
            raise HTTPException(status_code=401, detail=_BAD_CREDENTIALS)

    await _register_init_data_use(db, payload.init_data)

    user = (await db.execute(select(User).where(User.telegram_id == telegram_id))).scalar_one_or_none()
    if user is None:
        user = User(telegram_id=telegram_id)
        db.add(user)
    user.username = tg_user.get('username')
    user.first_name = tg_user.get('first_name')
    user.last_name = tg_user.get('last_name')
    if telegram_id in settings.super_admin_telegram_ids and user.role != roles.SUPER_ADMIN:
        user.role = roles.SUPER_ADMIN
        user.is_admin = True
    if user.is_banned:
        await db.commit()
        raise HTTPException(status_code=403, detail='Account is banned')
    await db.flush()

    jti = secrets.token_hex(16)
    token, expires_at = create_access_token(user.id, jti)
    db.add(AuthSession(jti=jti, user_id=user.id, expires_at=expires_at))
    user.last_seen_at = datetime.utcnow()
    await db.commit()
    await db.refresh(user)
    logger.info('login ok user_id=%s', user.id)
    return AuthResponse(access_token=token, expires_at=expires_at, user=TelegramUserOut.model_validate(user))


@router.get('/me', response_model=TelegramUserOut)
async def me(user: User = Depends(get_current_user)) -> TelegramUserOut:
    return TelegramUserOut.model_validate(user)


@router.post('/logout')
async def logout(
    ctx: tuple[User, AuthSession] = Depends(get_current_context),
    db: AsyncSession = Depends(get_db),
) -> dict[str, bool]:
    ctx[1].revoked = True
    await db.commit()
    return {'ok': True}
