from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db, require_roles, require_staff
from app.core import roles
from app.db.models import (
    AdminAction, AuthSession, Game, GamePlayer, Reservation, Spectator, TableModel, User, WaitlistEntry,
)
from app.services.realtime import schedule_notify

router = APIRouter(prefix='/api/v1/admin', tags=['admin'], dependencies=[Depends(require_staff)])

require_moderation = require_roles(roles.MODERATOR, roles.GAME_ADMIN)
ACTIVE = ('pending', 'confirmed')


class BanRequest(BaseModel):
    reason: str = Field(min_length=3, max_length=500)


class RoleRequest(BaseModel):
    role: str = Field(min_length=1, max_length=32)


class CloseTableRequest(BaseModel):
    reason: str = Field(default='', max_length=500)


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


def _user_out(user: User) -> dict[str, Any]:
    return {
        'id': user.id, 'telegram_id': user.telegram_id, 'username': user.username,
        'first_name': user.first_name, 'last_name': user.last_name, 'display_name': user.display_name,
        'role': user.role, 'is_admin': user.is_admin, 'is_banned': user.is_banned, 'ban_reason': user.ban_reason,
        'games_played': user.games_played, 'games_won': user.games_won,
        'created_at': _iso(user.created_at), 'last_seen_at': _iso(user.last_seen_at),
    }


def _audit(db: AsyncSession, admin: User, action: str, *, user_id: int | None = None,
           table_id: int | None = None, reason: str | None = None) -> None:
    db.add(AdminAction(admin_user_id=admin.id, action=action, target_user_id=user_id,
                       target_table_id=table_id, reason=reason, created_at=datetime.utcnow()))


async def _target(db: AsyncSession, user_id: int) -> User:
    user = await db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail='User not found')
    return user


@router.get('/overview')
async def admin_overview(db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    users_total = await db.scalar(select(func.count(User.id))) or 0
    banned_total = await db.scalar(select(func.count(User.id)).where(User.is_banned.is_(True))) or 0
    active_games = await db.scalar(select(func.count(Game.id)).where(Game.status == 'started')) or 0
    finished_games = await db.scalar(select(func.count(Game.id)).where(Game.status == 'finished')) or 0
    tables_reserved = await db.scalar(
        select(func.count(func.distinct(Reservation.table_id))).where(Reservation.status.in_(ACTIVE))
    ) or 0
    admins_total = await db.scalar(select(func.count(User.id)).where(User.role.in_(roles.STAFF_ROLES))) or 0
    winners = dict((await db.execute(
        select(Game.winner, func.count(Game.id)).where(Game.status == 'finished').group_by(Game.winner)
    )).all())
    return {
        'users_total': int(users_total), 'banned_total': int(banned_total), 'active_games': int(active_games),
        'finished_games': int(finished_games), 'tables_reserved': int(tables_reserved),
        'admins_total': int(admins_total),
        'winners': {str(k or 'draw'): int(v) for k, v in winners.items()},
        'status': 'ok',
    }


@router.get('/users')
async def list_admin_users(
    q: str = Query(default='', max_length=64),
    banned: bool | None = None,
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    stmt = select(User)
    term = q.strip().lstrip('@')
    if term:
        # bound parameters only; LIKE wildcards in the input are escaped
        like = '%' + term.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_') + '%'
        conds = [col.ilike(like, escape='\\') for col in (User.username, User.first_name, User.last_name, User.display_name)]
        if term.isdigit():
            conds += [User.telegram_id == int(term), User.id == int(term)]
        stmt = stmt.where(or_(*conds))
    if banned is not None:
        stmt = stmt.where(User.is_banned.is_(banned))
    total = await db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    users = (await db.execute(stmt.order_by(User.id.desc()).limit(limit).offset(offset))).scalars().all()
    return {'total': int(total), 'items': [_user_out(u) for u in users]}


@router.get('/users/{user_id}')
async def admin_user_detail(user_id: int, db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    user = await _target(db, user_id)
    games = (await db.execute(
        select(Game, GamePlayer).join(GamePlayer, GamePlayer.game_id == Game.id)
        .where(GamePlayer.user_id == user_id).order_by(Game.id.desc()).limit(20)
    )).all()
    actions = (await db.execute(
        select(AdminAction).where(AdminAction.target_user_id == user_id).order_by(AdminAction.id.desc()).limit(20)
    )).scalars().all()
    return {
        'user': _user_out(user),
        'games': [{'game_id': g.id, 'status': g.status, 'winner': g.winner,
                   'role': p.role_name if g.status != 'started' else None,
                   'started_at': _iso(g.started_at)} for g, p in games],
        'moderation': [_action_out(a) for a in actions],
    }


@router.post('/users/{user_id}/ban')
async def ban_user(user_id: int, payload: BanRequest, admin: User = Depends(require_moderation),
                   db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    user = await _target(db, user_id)
    if user.id == admin.id:
        raise HTTPException(status_code=400, detail='You cannot ban yourself')
    if user.role == roles.SUPER_ADMIN or (roles.is_staff(user.role) and admin.role != roles.SUPER_ADMIN):
        raise HTTPException(status_code=403, detail='Only a super admin can ban staff; super admins cannot be banned')
    reason = payload.reason.strip()
    user.is_banned, user.ban_reason = True, reason
    # kill every live session immediately (HTTP and WebSocket re-check sessions)
    await db.execute(update(AuthSession).where(AuthSession.user_id == user.id).values(revoked=True))
    # Free all seats in waiting tables; keep the record untouched in a running game.
    seats = (await db.execute(select(Reservation.table_id).join(
        TableModel, TableModel.id == Reservation.table_id).where(
        Reservation.user_id == user.id, Reservation.status.in_(ACTIVE), TableModel.status == 'waiting'))).scalars().all()
    if seats:
        await db.execute(update(Reservation).where(
            Reservation.user_id == user.id, Reservation.table_id.in_(set(seats)), Reservation.status.in_(ACTIVE)
        ).values(status='cancelled'))
    await db.execute(update(Spectator).where(Spectator.user_id == user.id).values(is_active=False))
    await db.execute(WaitlistEntry.__table__.delete().where(WaitlistEntry.user_id == user.id))
    _audit(db, admin, 'user.ban', user_id=user.id, reason=reason)
    await db.commit()
    for table_id in set(seats):
        schedule_notify(table_id)
    return {'ok': True, 'user': _user_out(user)}


@router.post('/users/{user_id}/unban')
async def unban_user(user_id: int, payload: CloseTableRequest | None = None, admin: User = Depends(require_moderation),
                     db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    user = await _target(db, user_id)
    if not user.is_banned:
        raise HTTPException(status_code=409, detail='User is not banned')
    user.is_banned, user.ban_reason = False, None
    _audit(db, admin, 'user.unban', user_id=user.id, reason=(payload.reason.strip() if payload else '') or None)
    await db.commit()
    return {'ok': True, 'user': _user_out(user)}


@router.post('/users/{user_id}/role')
async def set_user_role(user_id: int, payload: RoleRequest, admin: User = Depends(require_roles(roles.SUPER_ADMIN)),
                        db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    if payload.role not in roles.ALL_ROLES or payload.role == roles.SUPER_ADMIN:
        raise HTTPException(status_code=400, detail='Invalid role (super_admin is granted via ADMIN_IDS)')
    user = await _target(db, user_id)
    if user.id == admin.id:
        raise HTTPException(status_code=400, detail='You cannot change your own role')
    old = user.role
    user.role = payload.role
    user.is_admin = roles.is_staff(user.role)
    _audit(db, admin, 'user.role', user_id=user.id, reason=f'{old} -> {user.role}')
    await db.commit()
    return {'ok': True, 'user': _user_out(user)}


@router.post('/users/{user_id}/toggle-admin')
async def toggle_admin(user_id: int, admin: User = Depends(require_roles(roles.SUPER_ADMIN)),
                       db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    user = await _target(db, user_id)
    if user.role == roles.SUPER_ADMIN:
        raise HTTPException(status_code=400, detail='Cannot change a super admin')
    user.role = roles.PLAYER if user.is_admin else roles.MODERATOR
    user.is_admin = user.role != roles.PLAYER
    _audit(db, admin, 'user.role', user_id=user.id, reason=f'toggle -> {user.role}')
    await db.commit()
    return {'ok': True, 'user_id': user.id, 'is_admin': user.is_admin}


@router.get('/tables')
async def list_admin_tables(include_closed: bool = False, db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    stmt = select(TableModel).order_by(TableModel.id.desc())
    if not include_closed:
        stmt = stmt.where(TableModel.status != 'closed')
    tables = (await db.execute(stmt.limit(200))).scalars().all()
    counts = dict((await db.execute(
        select(Reservation.table_id, func.count(Reservation.id)).where(Reservation.status.in_(ACTIVE))
        .group_by(Reservation.table_id))).all())
    running = dict((await db.execute(select(Game.table_id, Game.id).where(Game.status == 'started'))).all())
    return {'items': [{
        'id': t.id, 'name': t.name, 'status': t.status, 'max_players': t.max_players,
        'spectator_capacity': t.spectator_capacity, 'host_user_id': t.host_user_id,
        'seated': int(counts.get(t.id, 0)), 'game_id': running.get(t.id),
    } for t in tables]}


@router.post('/tables/{table_id}/close')
async def close_table(table_id: int, payload: CloseTableRequest | None = None, admin: User = Depends(require_moderation),
                      db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    table = await db.get(TableModel, table_id)
    if table is None:
        raise HTTPException(status_code=404, detail='Table not found')
    claimed = await db.execute(update(TableModel).where(TableModel.id == table_id, TableModel.status == 'waiting')
                               .values(status='closed'))
    if claimed.rowcount != 1:
        raise HTTPException(status_code=409, detail='Only a waiting table can be closed (finish the running game first)')
    await db.execute(update(Reservation).where(Reservation.table_id == table_id, Reservation.status.in_(ACTIVE))
                     .values(status='cancelled'))
    await db.execute(update(Spectator).where(Spectator.table_id == table_id).values(is_active=False))
    await db.execute(WaitlistEntry.__table__.delete().where(WaitlistEntry.table_id == table_id))
    _audit(db, admin, 'table.close', table_id=table_id, reason=(payload.reason.strip() if payload else '') or None)
    await db.commit()
    schedule_notify(table_id)
    return {'ok': True, 'table_id': table_id, 'status': 'closed'}


@router.get('/games')
async def list_admin_games(status: str | None = Query(default=None, pattern='^(started|finished|aborted)$'),
                           limit: int = Query(default=50, ge=1, le=200),
                           db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    stmt = select(Game).order_by(Game.id.desc()).limit(limit)
    if status:
        stmt = stmt.where(Game.status == status)
    games = (await db.execute(stmt)).scalars().all()
    return {'items': [{
        'id': g.id, 'table_id': g.table_id, 'status': g.status, 'phase': g.phase, 'round_no': g.round_no,
        'winner': g.winner, 'started_at': _iso(g.started_at), 'finished_at': _iso(g.finished_at),
        'phase_deadline': _iso(g.phase_deadline),
    } for g in games]}


def _action_out(a: AdminAction) -> dict[str, Any]:
    return {'id': a.id, 'admin_user_id': a.admin_user_id, 'action': a.action, 'target_user_id': a.target_user_id,
            'target_table_id': a.target_table_id, 'reason': a.reason, 'created_at': _iso(a.created_at)}


@router.get('/actions')
async def list_admin_actions(limit: int = Query(default=100, ge=1, le=500),
                             db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    rows = (await db.execute(select(AdminAction).order_by(AdminAction.id.desc()).limit(limit))).scalars().all()
    return {'items': [_action_out(a) for a in rows]}


@router.get('/status')
async def service_status() -> dict[str, Any]:
    from app.api.routes.monitoring import check_database, check_redis, start_time
    from app.core.logging import recent_errors
    from app.services.realtime import realtime_hub
    from time import monotonic

    return {
        'database': await check_database(), 'redis': await check_redis(),
        'ws_connections': realtime_hub.connection_count(),
        'uptime_seconds': round(monotonic() - start_time, 1),
        'recent_errors': list(reversed(recent_errors))[:50],
    }
