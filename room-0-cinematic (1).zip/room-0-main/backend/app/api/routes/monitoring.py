from __future__ import annotations

import asyncio
from time import monotonic

from fastapi import APIRouter, Depends

from app.api.deps import require_staff
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.core.config import settings

router = APIRouter(prefix='/api/v1', tags=['monitoring'])
start_time = monotonic()


async def check_database() -> bool:
    from app.db import session as db_session

    try:
        async with db_session.async_session() as db:
            await asyncio.wait_for(db.execute(text('SELECT 1')), timeout=5)
        return True
    except Exception:
        return False


async def check_redis() -> bool | None:
    """None = Redis not used by this deployment."""
    if not settings.realtime_use_redis:
        return None
    try:
        import redis.asyncio as aioredis

        client = aioredis.from_url(settings.redis_url)
        try:
            return bool(await asyncio.wait_for(client.ping(), timeout=3))
        finally:
            await client.aclose()
    except Exception:
        return False


@router.get('/metrics', dependencies=[Depends(require_staff)])
async def get_metrics() -> dict[str, float | int | str]:
    from app.services.realtime import realtime_hub

    return {
        'uptime_seconds': round(monotonic() - start_time, 2),
        'environment': settings.environment,
        'app_name': settings.app_name,
        'ws_connections': realtime_hub.connection_count(),
        'status': 'ok',
    }


@router.get('/ready')
async def ready_check():
    """Readiness for load balancers / systemd checks: the database must answer."""
    database, redis_ok = await check_database(), await check_redis()
    redis_listener_ready = True
    if settings.realtime_use_redis:
        from app.services.realtime import realtime_hub
        redis_listener_ready = realtime_hub.redis_connected
    ready = database and redis_ok is not False and redis_listener_ready
    body = {'status': 'ready' if ready else 'not_ready', 'service': settings.app_name,
            'database': database, 'redis': redis_ok, 'realtime_listener': redis_listener_ready}
    return JSONResponse(status_code=200 if ready else 503, content=body)
