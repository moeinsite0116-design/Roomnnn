from __future__ import annotations

from datetime import datetime

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import roles
from app.core.security import decode_access_token
from app.db.models import AuthSession, User
from app.db.session import get_db

bearer_scheme = HTTPBearer(auto_error=False)

_UNAUTHORIZED = HTTPException(status_code=401, detail='Not authenticated', headers={'WWW-Authenticate': 'Bearer'})


async def resolve_token(db: AsyncSession, token: str) -> tuple[User, AuthSession]:
    """Validate a bearer token against the server-side session table.

    Raises ValueError (not authenticated) or PermissionError (banned). Used by HTTP and WebSocket auth.
    """
    try:
        payload = decode_access_token(token)
        user_id = int(payload['sub'])
    except (ValueError, KeyError):
        raise ValueError('invalid token')

    session = (await db.execute(select(AuthSession).where(AuthSession.jti == payload['jti']))).scalar_one_or_none()
    if session is None or session.revoked or session.user_id != user_id or session.expires_at <= datetime.utcnow():
        raise ValueError('invalid session')
    user = await db.get(User, user_id)
    if user is None:
        raise ValueError('unknown user')
    if user.is_banned:
        raise PermissionError('banned')
    user.last_seen_at = datetime.utcnow()
    await db.commit()
    return user, session


async def get_current_context(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> tuple[User, AuthSession]:
    """Identity comes only from a server-issued, server-tracked token — never from client-sent fields."""
    if credentials is None or credentials.scheme.lower() != 'bearer':
        raise _UNAUTHORIZED
    try:
        return await resolve_token(db, credentials.credentials)
    except ValueError:
        raise _UNAUTHORIZED
    except PermissionError:
        raise HTTPException(status_code=403, detail='Account is banned')


async def get_current_user(ctx: tuple[User, AuthSession] = Depends(get_current_context)) -> User:
    return ctx[0]


def require_roles(*allowed: str):
    """Server-side permission check. super_admin always passes."""
    permitted = set(allowed) | {roles.SUPER_ADMIN}

    async def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in permitted:
            raise HTTPException(status_code=403, detail='Insufficient permissions')
        return user

    return checker


require_staff = require_roles(*roles.STAFF_ROLES)
