from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.routes.admin import router as admin_router
from app.api.routes.bot import router as bot_router
from app.api.routes.auth import router as auth_router
from app.api.routes.games import router as games_router
from app.api.routes.health import router as health_router
from app.api.routes.livekit import router as livekit_router
from app.api.routes.monitoring import router as monitoring_router
from app.api.routes.tables import router as tables_router
from app.api.routes.users import router as users_router
from app.api.routes.ws import router as ws_router
from app.core.config import settings
from app.core.logging import setup_logging
from app.core.middleware import rate_limit_middleware, security_headers_middleware

setup_logging()
logger = logging.getLogger('room0')


async def _game_ticker() -> None:
    """Advance games whose phase deadline passed. Safe with several workers: transitions are compare-and-set."""
    from sqlalchemy import select

    from app.db.models import Game
    from app.db import session as db_session
    from app.services.game_service import advance_if_due, utcnow

    while True:
        try:
            async with db_session.async_session() as db:
                ids = (await db.execute(
                    select(Game.id).where(Game.status == 'started', Game.phase_deadline <= utcnow())
                )).scalars().all()
            for game_id in ids:
                async with db_session.async_session() as db:
                    await advance_if_due(db, game_id)
        except asyncio.CancelledError:
            raise
        except Exception:  # keep the loop alive; details go to the (redacted) log
            logger.exception('game ticker error')
        await asyncio.sleep(2)


@asynccontextmanager
async def lifespan(_: FastAPI):
    from app.services.realtime import realtime_hub

    await realtime_hub.start()
    task = asyncio.create_task(_game_ticker()) if settings.enable_game_ticker else None
    try:
        yield
    finally:
        if task:
            task.cancel()
        await realtime_hub.stop()


app = FastAPI(title=settings.app_name, version=settings.app_version, lifespan=lifespan)

app.middleware('http')(security_headers_middleware)
app.middleware('http')(rate_limit_middleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allow_headers=['Content-Type', 'Authorization', 'X-Telegram-Init-Data'],
)

app.include_router(health_router)
app.include_router(auth_router)
app.include_router(bot_router)
app.include_router(users_router)
app.include_router(tables_router)
app.include_router(games_router)
app.include_router(ws_router)
app.include_router(livekit_router)
app.include_router(admin_router)
app.include_router(monitoring_router)


@app.get('/')
async def root() -> dict[str, str]:
    return {'message': 'ROOM 0 API is running'}


@app.exception_handler(HTTPException)
async def http_exception_handler(_, exc: HTTPException) -> JSONResponse:
    return JSONResponse(status_code=exc.status_code, content={'detail': exc.detail}, headers=exc.headers)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    # Only field locations and messages are returned, never the submitted values.
    errors = [{'loc': list(e.get('loc', [])), 'msg': e.get('msg', 'invalid')} for e in exc.errors()]
    return JSONResponse(status_code=422, content={'detail': 'Invalid request', 'errors': errors})


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.error('Unhandled error on %s %s: %s', request.method, request.url.path, type(exc).__name__, exc_info=True)
    return JSONResponse(status_code=500, content={'detail': 'Internal server error'})
