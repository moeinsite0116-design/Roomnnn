"""interrogation stage, clue discovery and investigation board

Revision ID: 20261026_investigation
Revises: 20261025_table_guards

Additive only: new nullable/defaulted columns and new tables. No data is deleted.
The initial revision builds its tables from the current ORM metadata, so on a brand-new database some
of these columns already exist; every step therefore checks the live schema first.
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

from app.db.base import Base
from app.db import models  # noqa: F401

revision = '20261026_investigation'
down_revision = '20261025_table_guards'
branch_labels = None
depends_on = None

NEW_COLUMNS: dict[str, list[sa.Column]] = {
    'tables': [sa.Column('settings_json', sa.Text(), nullable=True)],
    'games': [
        sa.Column('settings_json', sa.Text(), nullable=True),
        sa.Column('interrogation_index', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('phase_started_at', sa.DateTime(), nullable=True),
    ],
    'game_players': [sa.Column('ready_at', sa.DateTime(), nullable=True)],
    'cases': [
        sa.Column('code', sa.String(length=32), nullable=True),
        sa.Column('objective', sa.Text(), nullable=True),
        sa.Column('briefing_json', sa.Text(), nullable=True),
    ],
    'questions': [
        sa.Column('stage', sa.String(length=16), nullable=False, server_default='round'),
        sa.Column('kind', sa.String(length=16), nullable=False, server_default='text'),
        sa.Column('options_json', sa.Text(), nullable=True),
        sa.Column('requires_clue_id', sa.Integer(), nullable=True),
        sa.Column('follow_up_of_id', sa.Integer(), nullable=True),
        sa.Column('follow_up_option', sa.String(length=64), nullable=True),
    ],
    'clues': [
        sa.Column('slug', sa.String(length=64), nullable=True),
        sa.Column('title', sa.String(length=160), nullable=True),
        sa.Column('kind', sa.String(length=24), nullable=False, server_default='document'),
        sa.Column('importance', sa.String(length=16), nullable=False, server_default='normal'),
        sa.Column('unlock_round', sa.Integer(), nullable=True),
        sa.Column('entities_json', sa.Text(), nullable=True),
        sa.Column('contradicts_clue_id', sa.Integer(), nullable=True),
        sa.Column('media_url', sa.String(length=500), nullable=True),
        sa.Column('order_index', sa.Integer(), nullable=False, server_default='0'),
    ],
}
NEW_TABLES = ('interrogation_answers', 'game_clues', 'clue_notes', 'clue_links', 'hypotheses')


def upgrade() -> None:
    bind = op.get_bind()
    inspector = inspect(bind)
    for table, columns in NEW_COLUMNS.items():
        existing = {c['name'] for c in inspector.get_columns(table)}
        for column in columns:
            if column.name not in existing:
                op.add_column(table, column)
    for name in NEW_TABLES:
        Base.metadata.tables[name].create(bind=bind, checkfirst=True)


def downgrade() -> None:
    bind = op.get_bind()
    for name in reversed(NEW_TABLES):
        Base.metadata.tables[name].drop(bind=bind, checkfirst=True)
    if bind.dialect.name == 'sqlite':
        # SQLite cannot drop columns without rebuilding tables; the extra nullable/defaulted
        # columns are harmless to the previous code, so they are intentionally left in place.
        return
    inspector = inspect(bind)
    for table, columns in NEW_COLUMNS.items():
        existing = {c['name'] for c in inspector.get_columns(table)}
        for column in columns:
            if column.name in existing:
                op.drop_column(table, column.name)
