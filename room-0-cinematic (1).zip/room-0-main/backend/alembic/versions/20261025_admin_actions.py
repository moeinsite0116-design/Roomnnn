"""admin audit log

Revision ID: 20261025_admin_actions
Revises: 20261024_initial
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = '20261025_admin_actions'
down_revision = '20261024_initial'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'admin_actions',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('admin_user_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('action', sa.String(length=48), nullable=False),
        sa.Column('target_user_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('target_table_id', sa.Integer(), sa.ForeignKey('tables.id'), nullable=True),
        sa.Column('reason', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
    )
    op.create_index('ix_admin_actions_admin_user_id', 'admin_actions', ['admin_user_id'])
    op.create_index('ix_admin_actions_target_user_id', 'admin_actions', ['target_user_id'])


def downgrade() -> None:
    op.drop_index('ix_admin_actions_target_user_id', table_name='admin_actions')
    op.drop_index('ix_admin_actions_admin_user_id', table_name='admin_actions')
    op.drop_table('admin_actions')
