"""guard active spectators and waitlist positions

Revision ID: 20261025_table_guards
Revises: 20261025_admin_actions
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = '20261025_table_guards'
down_revision = '20261025_admin_actions'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Normalize historical duplicates before adding unique guards.
    op.execute(sa.text("""
        WITH ranked AS (
            SELECT id, table_id, ROW_NUMBER() OVER (PARTITION BY table_id ORDER BY position, id) AS new_position
            FROM waitlist_entries
        )
        UPDATE waitlist_entries
        SET position = (SELECT new_position FROM ranked WHERE ranked.id = waitlist_entries.id)
    """))
    op.execute(sa.text("""
        UPDATE spectators SET is_active = FALSE
        WHERE is_active = TRUE AND id NOT IN (
            SELECT MAX(id) FROM spectators WHERE is_active = TRUE GROUP BY table_id, user_id
        )
    """))
    # The legacy initial migration builds tables from current ORM metadata, so a clean database
    # may already have these indexes. Existing databases may not. Make both upgrade paths safe.
    bind = op.get_bind()
    indexes = {name for table in ('waitlist_entries', 'spectators') for name in
               (item['name'] for item in inspect(bind).get_indexes(table))}
    if 'uq_waitlist_table_position' not in indexes:
        op.create_index('uq_waitlist_table_position', 'waitlist_entries', ['table_id', 'position'], unique=True)
    if 'uq_active_spectator_user' not in indexes:
        op.create_index(
            'uq_active_spectator_user', 'spectators', ['table_id', 'user_id'], unique=True,
            postgresql_where=sa.text('is_active IS TRUE'), sqlite_where=sa.text('is_active = 1'),
        )


def downgrade() -> None:
    op.drop_index('uq_active_spectator_user', table_name='spectators')
    op.drop_index('uq_waitlist_table_position', table_name='waitlist_entries')
