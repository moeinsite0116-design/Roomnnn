"""initial schema

Revision ID: 20261024_initial
Revises:
"""
from __future__ import annotations

from alembic import op

from app.db.base import Base
from app.db import models  # noqa: F401

revision = '20261024_initial'
down_revision = None
branch_labels = None
depends_on = None


# Frozen list: tables added later get their own migration, so this revision stays repeatable.
INITIAL_TABLES = (
    'users', 'app_settings', 'tables', 'reservations', 'waitlist_entries', 'spectators', 'cases', 'games',
    'game_players', 'questions', 'clues', 'admin_users', 'auth_sessions', 'init_data_uses', 'game_answers',
    'game_votes', 'game_events',
)


def _tables():
    return [Base.metadata.tables[name] for name in INITIAL_TABLES]


def upgrade() -> None:
    Base.metadata.create_all(bind=op.get_bind(), tables=_tables())


def downgrade() -> None:
    Base.metadata.drop_all(bind=op.get_bind(), tables=_tables())
