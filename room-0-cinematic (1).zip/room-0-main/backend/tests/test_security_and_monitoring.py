from __future__ import annotations


def test_health_endpoint(client) -> None:
    response = client.get('/api/health')
    assert response.status_code == 200
    assert response.json()['status'] == 'ok'


def test_ready_endpoint(client) -> None:
    response = client.get('/api/v1/ready')
    assert response.status_code == 200
    assert response.json()['status'] == 'ready' and response.json()['database'] is True


def test_ready_reports_database_down(client, monkeypatch) -> None:
    from app.api.routes import monitoring

    async def down() -> bool:
        return False

    monkeypatch.setattr(monitoring, 'check_database', down)
    response = client.get('/api/v1/ready')
    assert response.status_code == 503 and response.json()['status'] == 'not_ready'


def test_security_headers(client) -> None:
    response = client.get('/api/health')
    assert response.headers['X-Frame-Options'] == 'DENY'
    assert response.headers['X-Content-Type-Options'] == 'nosniff'


def test_unhandled_error_hides_stack_trace(client) -> None:
    from app.main import app

    @app.get('/api/v1/__boom')
    async def boom():
        raise RuntimeError('secret internals')

    from fastapi.testclient import TestClient

    try:
        res = TestClient(app, raise_server_exceptions=False).get('/api/v1/__boom')
        assert res.status_code == 500 and res.json() == {'detail': 'Internal server error'}
        assert 'secret' not in res.text
    finally:
        app.router.routes = [r for r in app.router.routes if getattr(r, 'path', '') != '/api/v1/__boom']


def test_authentication_endpoint_has_stricter_rate_limit(client, monkeypatch) -> None:
    from app.core.config import settings
    monkeypatch.setattr(settings, 'login_rate_limit_per_minute', 1)
    first = client.post('/api/v1/auth/telegram', json={'init_data': 'invalid-init-data'})
    second = client.post('/api/v1/auth/telegram', json={'init_data': 'invalid-init-data'})
    assert first.status_code == 401
    assert second.status_code == 429


def test_whitespace_game_answer_is_rejected(client) -> None:
    from tests.conftest import make_users, seat_all
    users = make_users(client)
    table_id = seat_all(client, users)
    game = client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).json()
    response = client.post(f'/api/v1/games/{game["id"]}/answer', json={'text': '   '}, headers=users[0]['h'])
    assert response.status_code == 422


def test_ready_reports_redis_unavailable(client, monkeypatch) -> None:
    from app.api.routes import monitoring
    from app.core.config import settings

    monkeypatch.setattr(settings, 'realtime_use_redis', True)

    async def redis_down():
        return False

    monkeypatch.setattr(monitoring, 'check_redis', redis_down)
    response = client.get('/api/v1/ready')
    assert response.status_code == 503
    assert response.json()['redis'] is False


def test_redis_publish_error_falls_back_to_local_delivery(monkeypatch) -> None:
    import asyncio
    from app.services.realtime import RealtimeHub

    class BrokenRedis:
        async def publish(self, *_args):
            raise ConnectionError('do not expose this text')

    hub = RealtimeHub()
    hub._redis = BrokenRedis()
    calls = []

    async def local_notify(table_id):
        calls.append(table_id)

    monkeypatch.setattr(hub, '_local_notify', local_notify)
    asyncio.run(hub.notify(123))
    assert calls == [123]
