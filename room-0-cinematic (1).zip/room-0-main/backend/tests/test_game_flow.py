from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import text

from tests.conftest import auth_header, login, make_users, seat_all


def start(client, users, table_id):
    res = client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h'])
    assert res.status_code == 200, res.text
    return res.json()


def roles_by_user(sync_engine, game_id):
    with sync_engine.begin() as conn:
        rows = conn.execute(text('SELECT user_id, role_name FROM game_players WHERE game_id = :g'), {'g': game_id}).all()
    return {r[0]: r[1] for r in rows}


def answer_all(client, users, game_id):
    for u in users:
        res = client.post(f'/api/v1/games/{game_id}/answer', json={'text': 'پاسخ'}, headers=u['h'])
        if res.status_code not in (200, 403):
            raise AssertionError(res.text)


# ---------------------------------------------------------------- tables / seats
def test_capacity_and_single_reservation(client) -> None:
    users = make_users(client, 7)
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=users[0]['h']).json()['id']
    for u in users[:6]:
        assert client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=u['h']).status_code == 201
    assert client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=users[6]['h']).status_code == 409  # full
    assert client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=users[0]['h']).status_code == 409  # duplicate


def test_seat_cannot_be_double_booked(client) -> None:
    users = make_users(client, 2)
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=users[0]['h']).json()['id']
    assert client.post(f'/api/v1/tables/{table_id}/reserve', json={'seat_index': 3}, headers=users[0]['h']).status_code == 201
    assert client.post(f'/api/v1/tables/{table_id}/reserve', json={'seat_index': 3}, headers=users[1]['h']).status_code == 409
    assert client.post(f'/api/v1/tables/{table_id}/reserve', json={'seat_index': 9}, headers=users[1]['h']).status_code == 422


def test_spectator_capacity(client) -> None:
    users = make_users(client, 6)
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=users[0]['h']).json()['id']
    codes = [client.post(f'/api/v1/tables/{table_id}/spectate', headers=u['h']).status_code for u in users[:5]]
    assert codes == [201, 201, 201, 201, 409]
    assert client.post(f'/api/v1/tables/{table_id}/spectate', headers=users[0]['h']).status_code == 200
    assert client.get('/api/v1/tables', headers=users[0]['h']).json()['items'][0]['spectators'] == 4


def test_waitlist_positions_are_unique(client) -> None:
    users = make_users(client, 3)
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=users[0]['h']).json()['id']
    positions = [client.post(f'/api/v1/tables/{table_id}/waitlist', headers=u['h']).json()['position'] for u in users]
    assert positions == [1, 2, 3]


def test_blank_table_name_rejected(client) -> None:
    user = make_users(client, 1)[0]
    assert client.post('/api/v1/tables', json={'name': '   '}, headers=user['h']).status_code == 422


def test_unauthenticated_tables_rejected(client) -> None:
    assert client.get('/api/v1/tables').status_code == 401
    assert client.post('/api/v1/tables', json={'name': 'x'}).status_code == 401


# ---------------------------------------------------------------- start rules
def test_start_needs_six_confirmed_and_host(client) -> None:
    users = make_users(client, 6)
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=users[0]['h']).json()['id']
    for u in users[:5]:
        client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=u['h'])
        client.post(f'/api/v1/tables/{table_id}/confirm', headers=u['h'])
    assert client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).status_code == 409  # only 5
    client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=users[5]['h'])
    client.post(f'/api/v1/tables/{table_id}/confirm', headers=users[5]['h'])
    assert client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[1]['h']).status_code == 403  # not host
    assert client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).status_code == 200


def test_double_start_rejected(client) -> None:
    users = make_users(client)
    table_id = seat_all(client, users)
    start(client, users, table_id)
    assert client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).status_code == 409


def test_cannot_leave_table_during_game(client) -> None:
    users = make_users(client)
    table_id = seat_all(client, users)
    start(client, users, table_id)
    assert client.post(f'/api/v1/tables/{table_id}/cancel', headers=users[2]['h']).status_code == 409


# ---------------------------------------------------------------- secrecy
def test_roles_are_secret(client, sync_engine) -> None:
    users = make_users(client)
    table_id = seat_all(client, users)
    state = start(client, users, table_id)
    game_id = state['id']
    truth = roles_by_user(sync_engine, game_id)

    for u in users:
        view = client.get(f'/api/v1/games/{game_id}', headers=u['h']).json()
        assert view['me']['role'] == truth[u['id']]
        assert all(p['role'] is None for p in view['players'])  # nobody else's role is exposed
        if truth[u['id']] != 'spy':
            assert 'teammates' not in view['me']

    outsider = make_users(client, 1, base=5000)[0]
    view = client.get(f'/api/v1/games/{game_id}', headers=outsider['h']).json()
    assert view['me'] == {'is_player': False}
    assert all(p['role'] is None for p in view['players'])
    assert '"role_name"' not in str(view)
    # removed leaky endpoints
    assert client.get(f'/api/v1/games/{game_id}/players', headers=users[0]['h']).status_code in (404, 405)


# ---------------------------------------------------------------- answer / vote rules
def test_answer_rules(client) -> None:
    users = make_users(client)
    game_id = start(client, users, seat_all(client, users))['id']
    url = f'/api/v1/games/{game_id}/answer'
    assert client.post(url, json={'text': 'a'}, headers=users[0]['h']).status_code == 200
    assert client.post(url, json={'text': 'b'}, headers=users[0]['h']).status_code == 409  # twice
    assert client.post(url, json={'text': ''}, headers=users[1]['h']).status_code == 422
    assert client.post(url, json={'text': '   '}, headers=users[1]['h']).status_code == 422
    outsider = make_users(client, 1, base=6000)[0]
    assert client.post(url, json={'text': 'x'}, headers=outsider['h']).status_code == 403
    assert client.post(f'/api/v1/games/{game_id}/vote', json={'target_user_id': users[1]['id']},
                       headers=users[0]['h']).status_code == 409  # wrong phase


def test_vote_rules_and_full_round(client, sync_engine) -> None:
    users = make_users(client)
    game_id = start(client, users, seat_all(client, users))['id']
    answer_all(client, users, game_id)
    state = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    assert state['phase'] == 'vote' and len(state['answers']) == 6

    vurl = f'/api/v1/games/{game_id}/vote'
    assert client.post(vurl, json={'target_user_id': users[0]['id']}, headers=users[0]['h']).status_code == 422  # self
    assert client.post(vurl, json={'target_user_id': 999999}, headers=users[0]['h']).status_code == 422
    victim = users[5]
    assert client.post(vurl, json={'target_user_id': victim['id']}, headers=users[0]['h']).status_code == 200
    assert client.post(vurl, json={'target_user_id': users[2]['id']}, headers=users[0]['h']).status_code == 409  # twice
    for u in users[1:5]:
        client.post(vurl, json={'target_user_id': victim['id']}, headers=u['h'])
    client.post(vurl, json={'target_user_id': users[0]['id']}, headers=victim['h'])

    after = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    dead = [p for p in after['players'] if not p['is_alive']]
    assert [p['user_id'] for p in dead] == [victim['id']]
    assert dead[0]['role'] is not None                      # revealed on elimination
    if after['status'] == 'started':
        assert after['round_no'] == 2 and after['phase'] == 'answer'
    # eliminated player can no longer act
    assert client.post(f'/api/v1/games/{game_id}/answer', json={'text': 'x'}, headers=victim['h']).status_code in (403, 409)


def test_detectives_win_by_voting_out_both_spies(client, sync_engine) -> None:
    users = make_users(client)
    game_id = start(client, users, seat_all(client, users))['id']
    truth = roles_by_user(sync_engine, game_id)
    spies = [u for u in users if truth[u['id']] == 'spy']
    detectives = [u for u in users if truth[u['id']] == 'detective']
    vurl = f'/api/v1/games/{game_id}/vote'

    for spy in spies:
        answer_all(client, users, game_id)
        view = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
        alive = [u for u in users if any(p['user_id'] == u['id'] and p['is_alive'] for p in view['players'])]
        for u in alive:
            target = spy if u['id'] != spy['id'] else detectives[0]
            client.post(vurl, json={'target_user_id': target['id']}, headers=u['h'])

    final = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    assert final['status'] == 'finished' and final['winner'] == 'detectives'
    assert {p['user_id']: p['role'] for p in final['players']} == truth      # all roles revealed at the end

    # stats written exactly once; reservations released; table reusable
    me = client.get('/api/v1/users/me', headers=detectives[0]['h']).json()
    assert me['games_played'] == 1 and me['games_won'] == 1
    assert client.get('/api/v1/users/me', headers=spies[0]['h']).json()['games_won'] == 0
    history = client.get('/api/v1/users/me/games', headers=detectives[0]['h']).json()['items']
    assert history[0]['game_id'] == game_id and history[0]['won'] is True
    table = [t for t in client.get('/api/v1/tables', headers=users[0]['h']).json()['items']][0]
    assert table['status'] == 'waiting' and table['available_seats'] == 6

    # a finished game accepts nothing further
    assert client.post(f'/api/v1/games/{game_id}/answer', json={'text': 'x'}, headers=users[0]['h']).status_code == 409
    again = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    assert again['winner'] == 'detectives'
    assert client.get('/api/v1/users/me', headers=detectives[0]['h']).json()['games_played'] == 1


def test_tie_eliminates_nobody(client) -> None:
    users = make_users(client)
    game_id = start(client, users, seat_all(client, users))['id']
    answer_all(client, users, game_id)
    vurl = f'/api/v1/games/{game_id}/vote'
    for i, u in enumerate(users):  # circular votes: everyone gets exactly one vote
        client.post(vurl, json={'target_user_id': users[(i + 1) % 6]['id']}, headers=u['h'])
    view = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    assert all(p['is_alive'] for p in view['players']) and view['round_no'] == 2


# ---------------------------------------------------------------- timers
def test_deadline_moves_phases_and_missing_votes_are_abstentions(client, sync_engine) -> None:
    users = make_users(client)
    game_id = start(client, users, seat_all(client, users))['id']
    past = (datetime.utcnow() - timedelta(seconds=5)).isoformat(sep=' ')

    with sync_engine.begin() as conn:
        conn.execute(text('UPDATE games SET phase_deadline = :d WHERE id = :g'), {'d': past, 'g': game_id})
    state = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    assert state['phase'] == 'vote'                       # nobody answered; deadline passed
    assert client.post(f'/api/v1/games/{game_id}/answer', json={'text': 'late'}, headers=users[0]['h']).status_code == 409

    with sync_engine.begin() as conn:
        conn.execute(text('UPDATE games SET phase_deadline = :d WHERE id = :g'), {'d': past, 'g': game_id})
    state = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    assert state['round_no'] == 2 and state['phase'] == 'answer'
    assert all(p['is_alive'] for p in state['players'])  # no votes -> no elimination


def test_repeated_advance_is_idempotent(client, sync_engine) -> None:
    users = make_users(client)
    game_id = start(client, users, seat_all(client, users))['id']
    past = (datetime.utcnow() - timedelta(seconds=5)).isoformat(sep=' ')
    with sync_engine.begin() as conn:
        conn.execute(text('UPDATE games SET phase_deadline = :d WHERE id = :g'), {'d': past, 'g': game_id})
    for _ in range(4):
        state = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    assert state['round_no'] == 1 and state['phase'] == 'vote'


# ---------------------------------------------------------------- admin
def test_only_game_admin_can_force_finish(client, sync_engine) -> None:
    users = make_users(client)
    game_id = start(client, users, seat_all(client, users))['id']
    assert client.post(f'/api/v1/games/{game_id}/finish', headers=users[0]['h']).status_code == 403
    with sync_engine.begin() as conn:
        conn.execute(text("UPDATE users SET role = 'game_admin' WHERE telegram_id = 1000"))
    res = client.post(f'/api/v1/games/{game_id}/finish', headers=users[0]['h'])
    assert res.status_code == 200 and res.json()['status'] == 'aborted'
    assert client.post(f'/api/v1/games/{game_id}/finish', headers=users[0]['h']).json()['status'] == 'already_finished'
    assert client.get('/api/v1/users/me', headers=users[1]['h']).json()['games_played'] == 0  # abort = no stats
