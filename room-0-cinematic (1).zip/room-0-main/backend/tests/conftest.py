from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
from urllib.parse import urlencode

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from app.core.config import settings
from app.core.middleware import reset_rate_limit
from app.db import models  # noqa: F401  (register tables)
from app.db.base import Base
from app.db import session as db_session
from app.db.session import get_db
from app.services.realtime import realtime_hub
from app.main import app


def make_init_data(telegram_id: int = 42, *, auth_date: int | None = None, bot_token: str | None = None,
                   username: str = 'ali', extra: str = '') -> str:
    """Build a correctly signed Telegram initData string (official algorithm)."""
    token = bot_token or settings.telegram_bot_token
    payload = {
        'auth_date': str(auth_date if auth_date is not None else int(time.time())),
        'query_id': 'q' + extra,
        'user': json.dumps({'id': telegram_id, 'first_name': 'Ali', 'username': username}, separators=(',', ':')),
    }
    check = '\n'.join(f'{k}={payload[k]}' for k in sorted(payload))
    secret = hmac.new(b'WebAppData', token.encode(), hashlib.sha256).digest()
    sig = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    return urlencode({**payload, 'hash': sig})


# Set TEST_DATABASE_URL=postgresql+psycopg://user:pass@host:port/db to run the suite against real PostgreSQL.
# WARNING: every test drops and recreates all tables in that database — never point it at production.
TEST_DATABASE_URL = os.environ.get('TEST_DATABASE_URL', '')


@pytest.fixture(autouse=True)
def use_test_telegram_bot_token(monkeypatch):
    # Deterministic fake secret used only by tests; production must provide BOT_TOKEN.
    monkeypatch.setattr(settings, 'telegram_bot_token', 'test-bot-token-not-valid-in-production')


def async_url(url: str) -> str:
    if url.startswith('sqlite:///'):
        return url.replace('sqlite:///', 'sqlite+aiosqlite:///', 1)
    return url.replace('postgresql+psycopg://', 'postgresql+asyncpg://', 1)


@pytest.fixture()
def db_url(tmp_path):
    if TEST_DATABASE_URL:
        sync = create_engine(TEST_DATABASE_URL)
        Base.metadata.drop_all(sync)
        with sync.begin() as conn:
            conn.exec_driver_sql('DROP TABLE IF EXISTS alembic_version')
        Base.metadata.create_all(sync)
        sync.dispose()
        return TEST_DATABASE_URL
    path = tmp_path / 'test.db'
    sync = create_engine(f'sqlite:///{path}')
    Base.metadata.create_all(sync)
    sync.dispose()
    return f'sqlite:///{path}'


@pytest.fixture()
def sync_engine(db_url):
    engine = create_engine(db_url)
    yield engine
    engine.dispose()


@pytest.fixture()
def client(db_url, monkeypatch):
    monkeypatch.setattr(settings, 'enable_game_ticker', False)
    monkeypatch.setattr(settings, 'enable_demo_mode', True)
    # Legacy suites exercise the voting rounds directly; the new stages have their own tests
    # (tests/test_interrogation_and_board.py) that switch them back on.
    monkeypatch.setattr(settings, 'interrogation_questions_default', 0)
    monkeypatch.setattr(settings, 'briefing_seconds', 0)
    engine = create_async_engine(async_url(db_url), poolclass=NullPool)
    maker = async_sessionmaker(engine, expire_on_commit=False)

    async def override_get_db():
        async with maker() as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    monkeypatch.setattr(db_session, 'async_session', maker)
    realtime_hub.reset()
    reset_rate_limit()
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()
    realtime_hub.reset()


def login(client: TestClient, telegram_id: int = 42, **kw) -> dict:
    res = client.post('/api/v1/auth/telegram', json={'init_data': make_init_data(telegram_id, **kw)})
    assert res.status_code == 200, res.text
    return res.json()


def auth_header(token: str) -> dict[str, str]:
    return {'Authorization': f'Bearer {token}'}


def make_users(client: TestClient, count: int = 6, base: int = 1000) -> list[dict]:
    """Log in `count` players; returns [{'tid','token','id','h'}]."""
    users = []
    for i in range(count):
        data = login(client, base + i, username=f'u{i}', extra=str(i))
        users.append({'tid': base + i, 'token': data['access_token'], 'id': data['user']['id'],
                      'h': auth_header(data['access_token'])})
    return users


def seat_all(client: TestClient, users: list[dict]) -> int:
    """First user hosts a table, everyone reserves and confirms. Returns table_id."""
    table_id = client.post('/api/v1/tables', json={'name': 'میز تست'}, headers=users[0]['h']).json()['id']
    for u in users:
        assert client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=u['h']).status_code == 201
        assert client.post(f'/api/v1/tables/{table_id}/confirm', headers=u['h']).status_code == 200
    return table_id
