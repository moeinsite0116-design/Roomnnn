from __future__ import annotations

import jwt

from app.core.config import settings
from tests.conftest import make_users, seat_all


def test_livekit_token_requires_auth_and_server_decides_role(client, monkeypatch) -> None:
    monkeypatch.setattr(settings, 'enable_livekit', True)
    assert client.post('/api/v1/livekit/token', json={'table_id': 1}).status_code == 401

    users = make_users(client)
    table_id = seat_all(client, users)
    outsider = make_users(client, 1, base=9000)[0]

    player = client.post('/api/v1/livekit/token', json={'table_id': table_id, 'user_id': 999, 'role': 'player'},
                         headers=users[0]['h'])
    assert player.status_code == 200
    claims = jwt.decode(player.json()['token'], settings.livekit_api_secret, algorithms=['HS256'])
    assert claims['sub'] == str(users[0]['id']) and claims['can_publish'] is True

    spectator = client.post('/api/v1/livekit/token', json={'table_id': table_id, 'role': 'player'}, headers=outsider['h'])
    claims = jwt.decode(spectator.json()['token'], settings.livekit_api_secret, algorithms=['HS256'])
    assert claims['sub'] == str(outsider['id']) and claims['can_publish'] is False

    assert client.post('/api/v1/livekit/token', json={'table_id': 12345}, headers=outsider['h']).status_code == 404
