from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_project_manifest_exists() -> None:
    assert (ROOT / 'README.md').exists()
    assert (ROOT / 'backend').exists()
    assert (ROOT / 'frontend').exists()
