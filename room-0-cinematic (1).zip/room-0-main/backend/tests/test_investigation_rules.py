"""Pure rule tests: run with pytest, or without any third-party package via
`python -m unittest tests.test_investigation_rules` from backend/."""
from __future__ import annotations

import unittest

from app.services.investigation_rules import (
    QuestionView,
    clue_visible_to,
    contradictions_among,
    detect_contradiction,
    entity_edges,
    interrogation_total,
    investigation_progress,
    normalize_fa,
    normalize_link,
    public_options,
    select_interrogation_question,
)

POOL = [
    QuestionView(id=1, order_index=1, kind='choice'),
    QuestionView(id=2, order_index=2, kind='choice'),
    QuestionView(id=3, order_index=3, kind='choice', follow_up_of_id=2, follow_up_option='kitchen'),
    QuestionView(id=4, order_index=4, kind='choice', follow_up_of_id=2, follow_up_option='hall'),
    QuestionView(id=5, order_index=5, kind='evidence', requires_clue_id=50),
    QuestionView(id=6, order_index=6, kind='text'),
]


class InterrogationSelectionTest(unittest.TestCase):
    def test_base_questions_in_case_order(self) -> None:
        self.assertEqual(select_interrogation_question(POOL, {}, set()).id, 1)
        self.assertEqual(select_interrogation_question(POOL, {1: 'a'}, set()).id, 2)

    def test_follow_up_depends_on_own_previous_answer(self) -> None:
        self.assertEqual(select_interrogation_question(POOL, {1: 'a', 2: 'kitchen'}, set()).id, 3)
        self.assertEqual(select_interrogation_question(POOL, {1: 'a', 2: 'hall'}, set()).id, 4)

    def test_follow_up_not_asked_without_trigger_and_clue_requirement(self) -> None:
        # no trigger, clue 50 not visible -> skip 3,4,5 -> text question 6
        self.assertEqual(select_interrogation_question(POOL, {1: 'a', 2: 'stairs'}, set()).id, 6)
        self.assertEqual(select_interrogation_question(POOL, {1: 'a', 2: 'stairs'}, {50}).id, 5)

    def test_never_repeats_and_ends(self) -> None:
        answered = {q.id: None for q in POOL}
        self.assertIsNone(select_interrogation_question(POOL, answered, {50}))

    def test_total_is_capped_by_base_questions(self) -> None:
        self.assertEqual(interrogation_total(POOL, 3), 3)
        self.assertEqual(interrogation_total(POOL, 99), 4)
        self.assertEqual(interrogation_total(POOL, 0), 0)


class ContradictionTest(unittest.TestCase):
    OPTIONS = [
        {'key': 'kitchen', 'label': 'آشپزخانه', 'contradicts_clue_id': 7},
        {'key': 'stairs', 'label': 'راه‌پله'},
        {'key': 'clue:9', 'contradicts_clue_id': 8},
        {'keywords': ['چای', 'كتري'], 'contradicts_clue_id': 7},
    ]

    def test_choice(self) -> None:
        self.assertEqual(detect_contradiction('choice', self.OPTIONS, option_key='kitchen'), 7)
        self.assertIsNone(detect_contradiction('choice', self.OPTIONS, option_key='stairs'))

    def test_evidence(self) -> None:
        self.assertEqual(detect_contradiction('evidence', self.OPTIONS, clue_id=9), 8)
        self.assertIsNone(detect_contradiction('evidence', self.OPTIONS, clue_id=10))

    def test_text_keywords_with_arabic_letter_forms(self) -> None:
        self.assertEqual(detect_contradiction('text', self.OPTIONS, text='داشتم كتری را روشن می‌کردم'), 7)
        self.assertIsNone(detect_contradiction('text', self.OPTIONS, text='در راه‌پله بودم'))

    def test_public_options_hide_contradiction_mapping(self) -> None:
        out = public_options('choice', self.OPTIONS)
        self.assertEqual(out, [{'key': 'kitchen', 'label': 'آشپزخانه'}, {'key': 'stairs', 'label': 'راه‌پله'}])
        self.assertNotIn('contradicts_clue_id', str(out))


class VisibilityAndBoardTest(unittest.TestCase):
    def test_team_clues_only_for_that_team(self) -> None:
        self.assertTrue(clue_visible_to('public', None))
        self.assertTrue(clue_visible_to('infiltrators', 'infiltrators'))
        self.assertFalse(clue_visible_to('infiltrators', 'detectives'))
        self.assertFalse(clue_visible_to('detectives', None))
        self.assertTrue(clue_visible_to('detectives', None, game_over=True))

    def test_contradiction_pairs_and_entity_edges(self) -> None:
        clues = [
            {'id': 1, 'contradicts_clue_id': None, 'entities': [{'type': 'place', 'label': 'اتاق ۰۰۷'}]},
            {'id': 2, 'contradicts_clue_id': 1, 'entities': [{'type': 'place', 'label': 'اتاق  ۰۰۷'}]},
            {'id': 3, 'contradicts_clue_id': None, 'entities': [{'type': 'time', 'label': '۲۱:۰۴'}]},
        ]
        self.assertEqual(contradictions_among(clues), [(1, 2)])
        self.assertEqual(entity_edges(clues), [{'from': 1, 'to': 2, 'type': 'place', 'label': 'اتاق ۰۰۷'}])

    def test_links_are_normalized_and_self_links_rejected(self) -> None:
        self.assertEqual(normalize_link(9, 3), (3, 9))
        with self.assertRaises(ValueError):
            normalize_link(4, 4)

    def test_progress(self) -> None:
        self.assertEqual(investigation_progress(0, 0, 0, 0), 0)
        self.assertEqual(investigation_progress(4, 4, 3, 1), 100)
        self.assertEqual(investigation_progress(4, 2, 0, 0), 30)

    def test_normalize(self) -> None:
        self.assertEqual(normalize_fa('  كليد  ي '), 'کلید ی')


if __name__ == '__main__':
    unittest.main()
