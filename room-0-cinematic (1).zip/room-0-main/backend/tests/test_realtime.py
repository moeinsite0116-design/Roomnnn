from __future__ import annotations

import pytest
from sqlalchemy import text
from starlette.websockets import WebSocketDisconnect

from tests.conftest import make_users, seat_all


def auth(ws, token, after=None):
    msg = {'type': 'auth', 'token': token}
    if after is not None:
        msg['after_event_id'] = after
    ws.send_json(msg)


def recv_until(ws, predicate, limit=20):
    for _ in range(limit):
        message = ws.receive_json()
        if predicate(message):
            return message
    raise AssertionError('expected websocket message never arrived')


def is_snapshot(m):
    return m.get('event') == 'snapshot'


def truth_roles(sync_engine, game_id):
    with sync_engine.begin() as conn:
        return dict(conn.execute(text('SELECT user_id, role_name FROM game_players WHERE game_id=:g'), {'g': game_id}).all())


# ---------------------------------------------------------------- access control
def test_ws_rejects_invalid_token(client) -> None:
    with pytest.raises(WebSocketDisconnect) as exc:
        with client.websocket_connect('/ws/table/1') as ws:
            auth(ws, 'garbage')
            ws.receive_json()
    assert exc.value.code == 4401


def test_ws_requires_auth_message_first(client) -> None:
    with pytest.raises(WebSocketDisconnect) as exc:
        with client.websocket_connect('/ws/table/1') as ws:
            ws.send_json({'type': 'ping'})
            ws.receive_json()
    assert exc.value.code == 4401


def test_ws_unknown_table(client) -> None:
    u = make_users(client, 1)[0]
    with pytest.raises(WebSocketDisconnect) as exc:
        with client.websocket_connect('/ws/table/9999') as ws:
            auth(ws, u['token'])
            ws.receive_json()
    assert exc.value.code == 4404


def test_ws_foreign_origin_rejected(client) -> None:
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect('/ws/table/1', headers={'origin': 'https://evil.example'}) as ws:
            ws.receive_json()


def test_ws_nonmember_rejected(client) -> None:
    host = make_users(client, 1)[0]
    outsider = make_users(client, 1, base=9000)[0]
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=host['h']).json()['id']
    with pytest.raises(WebSocketDisconnect) as exc:
        with client.websocket_connect(f'/ws/table/{table_id}') as ws:
            auth(ws, outsider['token'])
            ws.receive_json()
    assert exc.value.code == 4403


def test_ws_closes_when_table_membership_is_revoked(client) -> None:
    host, guest = make_users(client, 2)
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=host['h']).json()['id']
    assert client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=guest['h']).status_code == 201
    with client.websocket_connect(f'/ws/table/{table_id}') as ws:
        auth(ws, guest['token'])
        recv_until(ws, is_snapshot)
        assert client.post(f'/api/v1/tables/{table_id}/cancel', headers=guest['h']).status_code == 200
        ws.send_json({'type': 'ping'})
        with pytest.raises(WebSocketDisconnect) as exc:
            ws.receive_json()
        assert exc.value.code == 4403


def test_ws_banned_user_rejected(client, sync_engine) -> None:
    u = make_users(client, 1)[0]
    with sync_engine.begin() as conn:
        conn.execute(text('UPDATE users SET is_banned = TRUE'))
    with pytest.raises(WebSocketDisconnect) as exc:
        with client.websocket_connect('/ws/table/1') as ws:
            auth(ws, u['token'])
            ws.receive_json()
    assert exc.value.code == 4403


# ---------------------------------------------------------------- protocol
def test_ws_message_validation(client) -> None:
    u = make_users(client, 1)[0]
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=u['h']).json()['id']
    with client.websocket_connect(f'/ws/table/{table_id}') as ws:
        auth(ws, u['token'])
        assert ws.receive_json()['event'] == 'ready'
        ws.send_json({'type': 'bogus'})
        assert recv_until(ws, lambda m: m.get('event') == 'error')['code'] == 'unknown_type'
        ws.send_text('not json')
        assert recv_until(ws, lambda m: m.get('event') == 'error')['code'] == 'unknown_type'
        ws.send_json({'type': 'ping'})
        assert recv_until(ws, lambda m: m.get('event') == 'pong')
        ws.send_text('x' * 5000)
        with pytest.raises(WebSocketDisconnect) as exc:
            ws.receive_json()
        assert exc.value.code == 1009


def test_ws_logout_closes_live_socket_on_next_ping(client) -> None:
    u = make_users(client, 1)[0]
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=u['h']).json()['id']
    with client.websocket_connect(f'/ws/table/{table_id}') as ws:
        auth(ws, u['token'])
        recv_until(ws, is_snapshot)
        assert client.post('/api/v1/auth/logout', headers=u['h']).status_code == 200
        ws.send_json({'type': 'ping'})
        with pytest.raises(WebSocketDisconnect) as exc:
            recv_until(ws, lambda m: m.get('event') == 'pong')
        assert exc.value.code == 4401


# ---------------------------------------------------------------- live sync
def test_ws_pushes_live_seat_changes_and_presence(client) -> None:
    a, b = make_users(client, 2)
    table_id = client.post('/api/v1/tables', json={'name': 't'}, headers=a['h']).json()['id']
    with client.websocket_connect(f'/ws/table/{table_id}') as wa:
        auth(wa, a['token'])
        first = recv_until(wa, is_snapshot)
        assert first['seats'] == [] and a['id'] in first['online']

        assert client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=b['h']).status_code == 201
        snap = recv_until(wa, lambda m: is_snapshot(m) and len(m['seats']) == 1)
        assert snap['seats'][0]['user_id'] == b['id'] and snap['table']['available_seats'] == 5

        with client.websocket_connect(f'/ws/table/{table_id}') as wb:
            auth(wb, b['token'])
            recv_until(wb, is_snapshot)
            recv_until(wa, lambda m: is_snapshot(m) and b['id'] in m['online'])
        # b left: presence flips for a, seat is kept (disconnect != leaving)
        gone = recv_until(wa, lambda m: is_snapshot(m) and b['id'] not in m['online'])
        assert len(gone['seats']) == 1


def test_ws_snapshots_never_leak_roles(client, sync_engine) -> None:
    users = make_users(client)
    table_id = seat_all(client, users)
    game_id = client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).json()['id']
    truth = truth_roles(sync_engine, game_id)
    outsider = make_users(client, 1, base=7000)[0]

    for viewer in (users[0], users[3]):
        with client.websocket_connect(f'/ws/table/{table_id}') as ws:
            auth(ws, viewer['token'])
            snap = recv_until(ws, is_snapshot)
            game = snap['game']
            assert all(p['role'] is None for p in game['players'])
            assert game['me']['role'] == truth[viewer['id']]

    with pytest.raises(WebSocketDisconnect) as exc:
        with client.websocket_connect(f'/ws/table/{table_id}') as ws:
            auth(ws, outsider['token'])
            ws.receive_json()
    assert exc.value.code == 4403


def test_ws_game_changes_are_pushed_and_reconnect_restores_state(client) -> None:
    users = make_users(client)
    table_id = seat_all(client, users)
    game_id = client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).json()['id']

    with client.websocket_connect(f'/ws/table/{table_id}') as ws:
        auth(ws, users[0]['token'])
        snap = recv_until(ws, is_snapshot)
        last_id = snap['game']['last_event_id']
        assert snap['game']['phase'] == 'answer'

    # player is offline while the round moves on
    for u in users:
        client.post(f'/api/v1/games/{game_id}/answer', json={'text': 'x'}, headers=u['h'])

    with client.websocket_connect(f'/ws/table/{table_id}') as ws:
        auth(ws, users[0]['token'], after=last_id)
        backlog = recv_until(ws, lambda m: m.get('event') == 'events')
        assert backlog['items'] and all(i['id'] > last_id for i in backlog['items'])
        state = recv_until(ws, is_snapshot)['game']
        assert state['phase'] == 'vote' and state['my_answer'] == 'x'

        # live push while connected
        client.post(f'/api/v1/games/{game_id}/vote', json={'target_user_id': users[1]['id']}, headers=users[0]['h'])
        pushed = recv_until(ws, lambda m: is_snapshot(m) and m['game']['my_vote'] == users[1]['id'])
        assert pushed['game']['progress']['voted'] == 1


def test_disconnect_does_not_alter_game(client) -> None:
    users = make_users(client)
    table_id = seat_all(client, users)
    game_id = client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).json()['id']
    before = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    with client.websocket_connect(f'/ws/table/{table_id}') as ws:
        auth(ws, users[2]['token'])
        recv_until(ws, is_snapshot)
    after = client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()
    assert [p['is_alive'] for p in before['players']] == [p['is_alive'] for p in after['players']]
    assert after['phase'] == before['phase'] and after['round_no'] == before['round_no']
