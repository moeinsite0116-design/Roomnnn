from __future__ import annotations

from sqlalchemy import text

from app.core.config import settings
from tests.conftest import login, make_init_data, make_users, seat_all


def set_role(sync_engine, telegram_id: int, role: str) -> None:
    with sync_engine.begin() as conn:
        conn.execute(text('UPDATE users SET role = :r, is_admin = :a WHERE telegram_id = :t'),
                     {'r': role, 'a': role != 'player', 't': telegram_id})


def staff(client, sync_engine, telegram_id: int, role: str) -> dict:
    login(client, telegram_id)
    set_role(sync_engine, telegram_id, role)
    data = login(client, telegram_id, extra='s')
    return {'Authorization': f"Bearer {data['access_token']}", 'id': data['user']['id']}


def hdr(s: dict) -> dict:
    return {'Authorization': s['Authorization']}


def test_player_cannot_use_admin_panel(client) -> None:
    p = make_users(client, 1)[0]
    for path in ('/api/v1/admin/overview', '/api/v1/admin/users', '/api/v1/admin/status', '/api/v1/admin/actions'):
        assert client.get(path, headers=p['h']).status_code == 403
    assert client.post(f"/api/v1/admin/users/{p['id']}/ban", json={'reason': 'abcd'}, headers=p['h']).status_code == 403
    assert client.get('/api/v1/admin/users').status_code == 401


def test_analyst_is_read_only(client, sync_engine) -> None:
    target = make_users(client, 1)[0]
    analyst = staff(client, sync_engine, 500, 'analyst')
    assert client.get('/api/v1/admin/users', headers=hdr(analyst)).status_code == 200
    assert client.post(f"/api/v1/admin/users/{target['id']}/ban", json={'reason': 'spam spam'},
                       headers=hdr(analyst)).status_code == 403


def test_ban_with_reason_revokes_sessions_and_is_audited(client, sync_engine) -> None:
    target = make_users(client, 1)[0]
    mod = staff(client, sync_engine, 501, 'moderator')
    url = f"/api/v1/admin/users/{target['id']}/ban"
    assert client.post(url, json={'reason': ''}, headers=hdr(mod)).status_code == 422
    res = client.post(url, json={'reason': 'تقلب در رأی‌گیری'}, headers=hdr(mod))
    assert res.status_code == 200 and res.json()['user']['ban_reason'] == 'تقلب در رأی‌گیری'
    assert client.get('/api/v1/auth/me', headers=target['h']).status_code == 401
    relog = client.post('/api/v1/auth/telegram', json={'init_data': make_init_data(1000, extra='again')})
    assert relog.status_code == 403
    actions = client.get('/api/v1/admin/actions', headers=hdr(mod)).json()['items']
    assert actions[0]['action'] == 'user.ban' and actions[0]['target_user_id'] == target['id']
    assert actions[0]['admin_user_id'] == mod['id']
    # unban restores access
    assert client.post(f"/api/v1/admin/users/{target['id']}/unban", json={}, headers=hdr(mod)).status_code == 200
    assert client.post('/api/v1/auth/telegram', json={'init_data': make_init_data(1000, extra='x')}).status_code == 200
    detail = client.get(f"/api/v1/admin/users/{target['id']}", headers=hdr(mod)).json()
    assert [a['action'] for a in detail['moderation']] == ['user.unban', 'user.ban']


def test_moderator_cannot_ban_self_or_staff(client, sync_engine) -> None:
    mod = staff(client, sync_engine, 502, 'moderator')
    other = staff(client, sync_engine, 503, 'support')
    assert client.post(f"/api/v1/admin/users/{mod['id']}/ban", json={'reason': 'self ban'},
                       headers=hdr(mod)).status_code == 400
    assert client.post(f"/api/v1/admin/users/{other['id']}/ban", json={'reason': 'staff ban'},
                       headers=hdr(mod)).status_code == 403




def test_ban_releases_confirmed_seat_in_waiting_table(client, sync_engine) -> None:
    mod = staff(client, sync_engine, 2000, 'moderator')
    users = make_users(client, 6, base=3000)
    table_id = client.post('/api/v1/tables', json={'name': 'ban seat'}, headers=users[0]['h']).json()['id']
    for u in users[:2]:
        assert client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=u['h']).status_code == 201
        assert client.post(f'/api/v1/tables/{table_id}/confirm', headers=u['h']).status_code == 200
    response = client.post(f'/api/v1/admin/users/{users[1]["id"]}/ban', json={'reason': 'abuse'}, headers=mod['h'])
    assert response.status_code == 200
    table = client.get(f'/api/v1/tables/{table_id}', headers=users[0]['h']).json()
    assert table['available_seats'] == 5
    assert client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=users[1]['h']).status_code in (401, 403)


def test_user_search_is_parameterised(client, sync_engine) -> None:
    make_users(client, 3)  # usernames u0, u1, u2 / telegram 1000..1002
    mod = staff(client, sync_engine, 504, 'analyst')
    get = lambda q: client.get('/api/v1/admin/users', params={'q': q}, headers=hdr(mod)).json()
    assert [u['username'] for u in get('u1')['items']] == ['u1']
    assert get('1002')['items'][0]['telegram_id'] == 1002
    assert get('%')['total'] == 0
    assert get("' OR 1=1 --")['total'] == 0
    assert get('')['total'] == 4


def test_role_change_only_by_super_admin(client, sync_engine, monkeypatch) -> None:
    target = make_users(client, 1)[0]
    mod = staff(client, sync_engine, 505, 'game_admin')
    url = f"/api/v1/admin/users/{target['id']}/role"
    assert client.post(url, json={'role': 'moderator'}, headers=hdr(mod)).status_code == 403
    monkeypatch.setattr(settings, 'super_admin_telegram_ids', [777])
    sa = login(client, 777)
    h = {'Authorization': f"Bearer {sa['access_token']}"}
    assert client.post(url, json={'role': 'super_admin'}, headers=h).status_code == 400
    assert client.post(url, json={'role': 'hacker'}, headers=h).status_code == 400
    res = client.post(url, json={'role': 'moderator'}, headers=h)
    assert res.status_code == 200 and res.json()['user']['role'] == 'moderator'


def test_close_table_and_running_table_protection(client, sync_engine) -> None:
    users = make_users(client, 6)
    mod = staff(client, sync_engine, 506, 'moderator')
    table_id = seat_all(client, users)
    empty = client.post('/api/v1/tables', json={'name': 'خالی'}, headers=users[1]['h']).json()['id']
    client.post(f'/api/v1/tables/{empty}/waitlist', headers=users[2]['h'])
    assert client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).status_code == 200
    assert client.post(f'/api/v1/admin/tables/{table_id}/close', json={}, headers=hdr(mod)).status_code == 409
    res = client.post(f'/api/v1/admin/tables/{empty}/close', json={'reason': 'spam'}, headers=hdr(mod))
    assert res.status_code == 200
    ids = [t['id'] for t in client.get('/api/v1/tables', headers=users[3]['h']).json()['items']]
    assert empty not in ids and table_id in ids
    assert client.post(f'/api/v1/tables/{empty}/reserve', json={}, headers=users[3]['h']).status_code == 409
    games = client.get('/api/v1/admin/games', params={'status': 'started'}, headers=hdr(mod)).json()['items']
    assert len(games) == 1 and games[0]['table_id'] == table_id
    tables = client.get('/api/v1/admin/tables', headers=hdr(mod)).json()['items']
    assert next(t for t in tables if t['id'] == table_id)['seated'] == 6


def test_service_status_and_overview(client, sync_engine) -> None:
    an = staff(client, sync_engine, 507, 'analyst')
    status = client.get('/api/v1/admin/status', headers=hdr(an)).json()
    assert status['database'] is True and isinstance(status['recent_errors'], list)
    ov = client.get('/api/v1/admin/overview', headers=hdr(an)).json()
    assert ov['users_total'] == 1 and ov['admins_total'] == 1 and ov['active_games'] == 0


def test_errors_are_recorded_redacted() -> None:
    import logging

    from app.core.logging import recent_errors, setup_logging

    setup_logging()
    logging.getLogger('room0').error('failed with Bearer abc.def.ghi and 123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
    last = recent_errors[-1]['message']
    assert 'abc.def.ghi' not in last and 'AAAAAAAA' not in last
