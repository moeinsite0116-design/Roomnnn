"""End-to-end API tests for «مرحله شناسایی نفوذی‌ها», the case-file briefing and the investigation board."""
from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import text

from app.core.config import settings
from tests.conftest import make_users, seat_all


def enable_stages(monkeypatch, questions: int = 3) -> None:
    monkeypatch.setattr(settings, 'interrogation_questions_default', questions)
    monkeypatch.setattr(settings, 'briefing_seconds', 40)


def start(client, users):
    table_id = seat_all(client, users)
    res = client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h'])
    assert res.status_code == 200, res.text
    return res.json(), table_id


def state(client, game_id, user):
    return client.get(f'/api/v1/games/{game_id}', headers=user['h']).json()


def answer_current(client, game_id, user, choice_index: int = 0, prefer: str | None = None):
    q = state(client, game_id, user)['interrogation']['question']
    body = {'question_id': q['id']}
    if q['kind'] == 'choice':
        keys = [o['key'] for o in q['options']]
        body['option_key'] = prefer if prefer in keys else keys[choice_index]
    elif q['kind'] == 'evidence':
        body['clue_id'] = q['evidence'][0]['id']
    else:
        body['text'] = 'رفتار نگهبان عجیب بود'
    return client.post(f'/api/v1/games/{game_id}/interrogation/answer', json=body, headers=user['h']), q


def roles(sync_engine, game_id):
    with sync_engine.begin() as conn:
        return dict(conn.execute(text('SELECT user_id, team FROM game_players WHERE game_id=:g'), {'g': game_id}).all())


def test_game_starts_with_interrogation_and_personalised_follow_up(client, monkeypatch) -> None:
    enable_stages(monkeypatch)
    users = make_users(client)
    game, _ = start(client, users)
    assert game['phase'] == 'interrogation' and game['stage'] == 'interrogation'
    block = game['interrogation']
    assert block['step'] == 1 and block['total'] == 3
    assert block['question']['kind'] == 'choice'
    assert 'contradicts_clue_id' not in str(block)               # authored solution hints never sent
    assert game['case']['title'] and 'objective' not in game['case']  # file is still closed

    game_id = game['id']
    for u in users:
        res, _ = answer_current(client, game_id, u)
        assert res.status_code == 200, res.text
    # step 2: everyone gets the shared "where were you" question; two players choose kitchen
    for i, u in enumerate(users):
        res, q = answer_current(client, game_id, u, prefer='kitchen' if i < 2 else 'stairs')
        assert res.status_code == 200 and 'کجا' in q['prompt']
    kitchen_q = state(client, game_id, users[0])['interrogation']['question']
    stairs_q = state(client, game_id, users[3])['interrogation']['question']
    assert kitchen_q['follow_up'] is True and 'آشپزخانه' in kitchen_q['prompt']
    assert stairs_q['follow_up'] is False and kitchen_q['id'] != stairs_q['id']


def test_interrogation_rejects_duplicates_stale_questions_and_outsiders(client, monkeypatch) -> None:
    enable_stages(monkeypatch)
    users = make_users(client)
    game, _ = start(client, users)
    game_id = game['id']
    res, q = answer_current(client, game_id, users[0])
    assert res.status_code == 200
    again = client.post(f'/api/v1/games/{game_id}/interrogation/answer',
                        json={'question_id': q['id'], 'option_key': q['options'][0]['key']}, headers=users[0]['h'])
    assert again.status_code == 409
    bad = client.post(f'/api/v1/games/{game_id}/interrogation/answer',
                      json={'question_id': q['id'], 'option_key': 'not-an-option'}, headers=users[1]['h'])
    assert bad.status_code == 422
    stale = client.post(f'/api/v1/games/{game_id}/interrogation/answer',
                        json={'question_id': 999999, 'option_key': 'dark'}, headers=users[1]['h'])
    assert stale.status_code == 409
    outsider = make_users(client, 1, base=7100)[0]
    res, _ = None, None
    res = client.post(f'/api/v1/games/{game_id}/interrogation/answer',
                      json={'question_id': q['id'], 'option_key': 'dark'}, headers=outsider['h'])
    assert res.status_code == 403
    # own answer is visible to its author only while the stage runs
    assert state(client, game_id, users[0])['interrogation']['my_answer']['display']
    assert state(client, game_id, users[1])['interrogation']['my_answer'] is None
    assert state(client, game_id, users[1])['dossier'] == []


def test_deadline_records_skips_then_briefing_and_ready_starts_rounds(client, sync_engine, monkeypatch) -> None:
    enable_stages(monkeypatch, questions=1)
    users = make_users(client)
    game, _ = start(client, users)
    game_id = game['id']
    answer_current(client, game_id, users[0])
    with sync_engine.begin() as conn:
        conn.execute(text('UPDATE games SET phase_deadline = :t WHERE id = :g'),
                     {'t': datetime.utcnow() - timedelta(seconds=1), 'g': game_id})
    after = state(client, game_id, users[0])
    assert after['phase'] == 'briefing' and after['stage'] == 'briefing'
    assert after['case']['objective'] and after['case']['briefing']
    with sync_engine.begin() as conn:
        skipped = conn.execute(text('SELECT COUNT(*) FROM interrogation_answers WHERE game_id=:g AND skipped = TRUE'),
                               {'g': game_id}).scalar()
    assert skipped == 5
    dossier = after['dossier']
    assert len(dossier) == 6 and sum(1 for d in dossier for e in d['entries'] if e['skipped']) == 5
    for i, u in enumerate(users):
        res = client.post(f'/api/v1/games/{game_id}/briefing/ready', headers=u['h'])
        assert res.status_code == 200
        if i < 5:
            assert res.json()['phase'] == 'briefing'
    assert client.post(f'/api/v1/games/{game_id}/briefing/ready', headers=users[0]['h']).json()['phase'] == 'answer'
    rounds = state(client, game_id, users[0])
    assert rounds['phase'] == 'answer' and rounds['round_no'] == 1 and rounds['question']


def test_contradiction_is_shown_only_after_the_public_clue_is_discovered(client, sync_engine, monkeypatch) -> None:
    enable_stages(monkeypatch, questions=2)
    users = make_users(client)
    game, _ = start(client, users)
    game_id = game['id']
    for u in users:
        answer_current(client, game_id, u)
    for i, u in enumerate(users):
        answer_current(client, game_id, u, prefer='kitchen' if i == 0 else 'stairs')
    view = state(client, game_id, users[1])
    assert view['stage'] == 'briefing'          # kitchen photo is a round-1 clue, discovered at the briefing
    entry = [e for d in view['dossier'] if d['user_id'] == users[0]['id'] for e in d['entries'] if e['step'] == 2][0]
    assert entry['answer'] == 'آشپزخانه' and entry['contradiction'] and entry['contradiction']['title'] == 'عکس آشپزخانه'
    others = [e for d in view['dossier'] if d['user_id'] != users[0]['id'] for e in d['entries']]
    assert all(e['contradiction'] is None for e in others)
    assert all(isinstance(e['response_ms'], int) for e in others)


def test_team_secrets_never_reach_other_teams(client, sync_engine, monkeypatch) -> None:
    enable_stages(monkeypatch)
    users = make_users(client)
    game, _ = start(client, users)
    game_id = game['id']
    team = roles(sync_engine, game_id)
    for u in users:
        view = state(client, game_id, u)
        board = client.get(f'/api/v1/games/{game_id}/board', headers=u['h']).json()
        titles = {c['title'] for c in view['clues']} | {c['title'] for c in board['clues']}
        mine = team[u['id']]
        assert ('دستور عملیات نفوذی‌ها' in titles) == (mine == 'infiltrators')
        assert ('یادداشت محرمانهٔ کارآگاه‌ها' in titles) == (mine == 'detectives')
        assert ('شنیدهٔ مستقل' in titles) == (mine == 'alliance')
        assert 'contradicts_clue_id' not in str(board)
    outsider = make_users(client, 1, base=7200)[0]
    public = client.get(f'/api/v1/games/{game_id}/board', headers=outsider['h']).json()
    assert public['readonly'] is True and all(not c['team_only'] for c in public['clues'])
    events = client.get(f'/api/v1/games/{game_id}/events', headers=outsider['h']).json()['items']
    assert 'نفوذی' not in str(events)


def test_board_notes_links_hypotheses_are_private_and_idempotent(client, monkeypatch) -> None:
    users = make_users(client)  # legacy flow: round 1 starts immediately, round-1 clues are discovered
    game, _ = start(client, users)
    game_id = game['id']
    board = client.get(f'/api/v1/games/{game_id}/board', headers=users[0]['h']).json()
    public = [c for c in board['clues'] if not c['team_only']]
    assert len(public) >= 3
    a, b = public[0]['id'], public[1]['id']

    url = f'/api/v1/games/{game_id}/clues/{a}/note'
    assert client.put(url, json={'flagged': True, 'note': 'ساعت‌ها نمی‌خواند'}, headers=users[0]['h']).status_code == 200
    assert client.put(url, json={'status': 'checked'}, headers=users[0]['h']).json()['status'] == 'checked'
    assert client.put(url, json={'status': 'solved'}, headers=users[0]['h']).status_code == 422

    link = client.post(f'/api/v1/games/{game_id}/links', json={'from_clue_id': b, 'to_clue_id': a}, headers=users[0]['h'])
    again = client.post(f'/api/v1/games/{game_id}/links', json={'from_clue_id': a, 'to_clue_id': b}, headers=users[0]['h'])
    assert link.json()['created'] is True and again.json()['created'] is False and again.json()['id'] == link.json()['id']
    assert client.post(f'/api/v1/games/{game_id}/links', json={'from_clue_id': a, 'to_clue_id': a},
                       headers=users[0]['h']).status_code == 422

    body = {'request_id': 'hyp-0001-abc', 'text': 'کارت مهمان را کسی از آشپزخانه برداشته', 'clue_ids': [a, b]}
    first = client.post(f'/api/v1/games/{game_id}/hypotheses', json=body, headers=users[0]['h']).json()
    second = client.post(f'/api/v1/games/{game_id}/hypotheses', json=body, headers=users[0]['h']).json()
    assert first['created'] is True and second['created'] is False and first['id'] == second['id']

    mine = client.get(f'/api/v1/games/{game_id}/board', headers=users[0]['h']).json()
    assert mine['summary'] == {'discovered': len(mine['clues']), 'checked': 1, 'flagged': 1, 'links': 1,
                               'contradictions': 0, 'hypotheses': 1}
    assert 0 < mine['progress'] <= 100
    theirs = client.get(f'/api/v1/games/{game_id}/board', headers=users[1]['h']).json()
    assert theirs['links'] == [] and theirs['hypotheses'] == []
    assert all(c['note']['text'] == '' for c in theirs['clues'])
    outsider = make_users(client, 1, base=7300)[0]
    assert client.put(url, json={'flagged': True}, headers=outsider['h']).status_code == 403


def test_linking_authored_contradiction_is_flagged_without_revealing_others(client, sync_engine) -> None:
    users = make_users(client)
    game, _ = start(client, users)
    game_id = game['id']
    with sync_engine.begin() as conn:  # jump to round 2, where the vent report and the guard statement appear
        conn.execute(text("UPDATE games SET phase='vote', phase_deadline=:t WHERE id=:g"),
                     {'t': datetime.utcnow() - timedelta(seconds=1), 'g': game_id})
    assert state(client, game_id, users[0])['round_no'] == 2
    clues = {c['title']: c['id'] for c in client.get(f'/api/v1/games/{game_id}/board', headers=users[0]['h']).json()['clues']}
    res = client.post(f'/api/v1/games/{game_id}/links', json={
        'from_clue_id': clues['اظهارات نگهبان'], 'to_clue_id': clues['گزارش فنی دریچهٔ تهویه']}, headers=users[0]['h'])
    assert res.status_code == 200 and res.json()['contradiction'] is True
    calm = client.post(f'/api/v1/games/{game_id}/links', json={
        'from_clue_id': clues['لاگ کارت‌خوان'], 'to_clue_id': clues['گزارش اولیهٔ نگهبانی']}, headers=users[0]['h'])
    assert calm.json()['contradiction'] is False


def test_table_settings_are_validated_and_applied(client, monkeypatch) -> None:
    enable_stages(monkeypatch)
    users = make_users(client)
    bad = client.post('/api/v1/tables', json={'name': 't', 'answer_seconds': 5}, headers=users[0]['h'])
    assert bad.status_code == 422
    created = client.post('/api/v1/tables', json={'name': 't', 'interrogation_questions': 2, 'interrogation_seconds': 30},
                          headers=users[0]['h']).json()
    assert created['settings']['interrogation_questions'] == 2 and created['settings']['interrogation_seconds'] == 30
