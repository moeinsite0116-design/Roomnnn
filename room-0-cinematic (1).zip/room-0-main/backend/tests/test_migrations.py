"""Alembic migrations: upgrade/downgrade/upgrade on a clean DB and no drift against the models."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from sqlalchemy import create_engine, inspect

from app.db import models  # noqa: F401
from app.db.base import Base

BACKEND = Path(__file__).resolve().parents[1]


def alembic(url: str, *args: str) -> None:
    env = {**os.environ, 'DATABASE_URL': url}
    res = subprocess.run([sys.executable, '-m', 'alembic', *args], cwd=BACKEND, env=env, capture_output=True, text=True)
    assert res.returncode == 0, res.stderr[-2000:]


def test_upgrade_downgrade_upgrade_and_no_drift(db_url) -> None:
    engine = create_engine(db_url)
    Base.metadata.drop_all(engine)  # start from an empty database
    try:
        alembic(db_url, 'upgrade', 'head')
        alembic(db_url, 'upgrade', 'head')  # repeatable: second run is a no-op
        tables = set(inspect(engine).get_table_names())
        assert set(Base.metadata.tables) <= tables and 'alembic_version' in tables
        index_map = {table: {item['name'] for item in inspect(engine).get_indexes(table)}
                     for table in ('waitlist_entries', 'spectators')}
        assert 'uq_waitlist_table_position' in index_map['waitlist_entries']
        assert 'uq_active_spectator_user' in index_map['spectators']

        from alembic.autogenerate import compare_metadata
        from alembic.migration import MigrationContext

        with engine.connect() as conn:
            diff = compare_metadata(MigrationContext.configure(conn), Base.metadata)
        assert diff == []

        alembic(db_url, 'downgrade', '20261024_initial')
        assert 'admin_actions' not in inspect(engine).get_table_names()
        alembic(db_url, 'downgrade', 'base')
        assert set(inspect(engine).get_table_names()) <= {'alembic_version'}
        alembic(db_url, 'upgrade', 'head')
        assert 'admin_actions' in inspect(engine).get_table_names()
    finally:
        engine.dispose()
