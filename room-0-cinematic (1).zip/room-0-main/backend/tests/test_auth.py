from __future__ import annotations

import time

import pytest
from sqlalchemy import text

from app.core.config import settings
from app.core.security import validate_telegram_init_data
from tests.conftest import auth_header, login, make_init_data


def test_valid_init_data_unit() -> None:
    result = validate_telegram_init_data(make_init_data(42), settings.telegram_bot_token)
    assert result['user']['id'] == 42


def test_invalid_signature_unit() -> None:
    with pytest.raises(ValueError):
        validate_telegram_init_data('hash=bad&auth_date=1', 'token123')


def test_wrong_bot_token_rejected_unit() -> None:
    with pytest.raises(ValueError):
        validate_telegram_init_data(make_init_data(42, bot_token='other-token'), settings.telegram_bot_token)


def test_future_init_data_rejected_unit() -> None:
    future = int(time.time()) + 120
    with pytest.raises(ValueError, match='future'):
        validate_telegram_init_data(make_init_data(42, auth_date=future), settings.telegram_bot_token)


def test_missing_and_duplicate_auth_fields_rejected() -> None:
    with pytest.raises(ValueError):
        validate_telegram_init_data('hash=' + 'a' * 64, settings.telegram_bot_token)
    data = make_init_data(42)
    with pytest.raises(ValueError, match='duplicate'):
        validate_telegram_init_data(data + '&auth_date=123', settings.telegram_bot_token)


def test_expired_init_data_rejected_unit() -> None:
    old = int(time.time()) - settings.init_data_max_age_seconds - 10
    with pytest.raises(ValueError):
        validate_telegram_init_data(make_init_data(42, auth_date=old), settings.telegram_bot_token)


def test_login_valid(client) -> None:
    data = login(client, 42)
    assert data['token_type'] == 'bearer'
    assert data['user']['telegram_id'] == 42
    assert data['user']['role'] == 'player'
    me = client.get('/api/v1/auth/me', headers=auth_header(data['access_token']))
    assert me.status_code == 200 and me.json()['telegram_id'] == 42


def test_login_tampered_rejected(client) -> None:
    bad = make_init_data(42).replace('Ali', 'Eve')
    assert client.post('/api/v1/auth/telegram', json={'init_data': bad}).status_code == 401


def test_login_expired_rejected(client) -> None:
    old = int(time.time()) - settings.init_data_max_age_seconds - 10
    res = client.post('/api/v1/auth/telegram', json={'init_data': make_init_data(42, auth_date=old)})
    assert res.status_code == 401


def test_init_data_reuse_is_capped(client) -> None:
    init = make_init_data(42)
    codes = [client.post('/api/v1/auth/telegram', json={'init_data': init}).status_code
             for _ in range(settings.init_data_max_uses + 1)]
    assert codes[:-1] == [200] * settings.init_data_max_uses
    assert codes[-1] == 401


def test_me_requires_token(client) -> None:
    unauthenticated = client.get('/api/v1/auth/me')
    assert unauthenticated.status_code == 401
    assert unauthenticated.headers.get('www-authenticate') == 'Bearer'
    assert client.get('/api/v1/auth/me', headers=auth_header('garbage')).status_code == 401


def test_client_cannot_choose_identity(client) -> None:
    token = login(client, 42)['access_token']
    res = client.get('/api/v1/auth/me', headers={**auth_header(token), 'X-Telegram-Init-Data': make_init_data(99)})
    assert res.json()['telegram_id'] == 42


def test_logout_revokes_token(client) -> None:
    token = login(client, 42)['access_token']
    assert client.post('/api/v1/auth/logout', headers=auth_header(token)).status_code == 200
    assert client.get('/api/v1/auth/me', headers=auth_header(token)).status_code == 401


def test_banned_user_blocked(client, sync_engine) -> None:
    token = login(client, 42)['access_token']
    with sync_engine.begin() as conn:
        conn.execute(text("UPDATE users SET is_banned = TRUE, ban_reason = 'cheating' WHERE telegram_id = 42"))
    assert client.get('/api/v1/auth/me', headers=auth_header(token)).status_code == 403
    res = client.post('/api/v1/auth/telegram', json={'init_data': make_init_data(42, extra='2')})
    assert res.status_code == 403
    assert 'cheating' not in res.text


def test_profile_update_and_validation(client) -> None:
    token = login(client, 42)['access_token']
    h = auth_header(token)
    ok = client.patch('/api/v1/users/me', json={'display_name': '  Sara  '}, headers=h)
    assert ok.status_code == 200 and ok.json()['display_name'] == 'Sara'
    assert client.patch('/api/v1/users/me', json={'display_name': ''}, headers=h).status_code == 422
    assert client.patch('/api/v1/users/me', json={'display_name': 'x' * 33}, headers=h).status_code == 422
    assert client.patch('/api/v1/users/me', json={'display_name': 'a', 'role': 'super_admin'}, headers=h).json()['role'] == 'player'


def test_admin_requires_staff_role(client, sync_engine) -> None:
    assert client.get('/api/v1/admin/overview').status_code == 401
    token = login(client, 42)['access_token']
    assert client.get('/api/v1/admin/overview', headers=auth_header(token)).status_code == 403
    with sync_engine.begin() as conn:
        conn.execute(text("UPDATE users SET role = 'analyst' WHERE telegram_id = 42"))
    assert client.get('/api/v1/admin/overview', headers=auth_header(token)).status_code == 200
    uid = client.get('/api/v1/auth/me', headers=auth_header(token)).json()['id']
    assert client.post(f'/api/v1/admin/users/{uid}/toggle-admin', headers=auth_header(token)).status_code == 403


def test_super_admin_bootstrap(client, monkeypatch) -> None:
    monkeypatch.setattr(settings, 'super_admin_telegram_ids', [777])
    data = login(client, 777)
    assert data['user']['role'] == 'super_admin'
    assert client.get('/api/v1/admin/overview', headers=auth_header(data['access_token'])).status_code == 200


def test_bot_internal_profile_requires_secret(client, monkeypatch) -> None:
    monkeypatch.setattr(settings, 'bot_api_secret', 's' * 40)
    assert client.post('/api/v1/bot/profile', json={'telegram_id': 42}).status_code == 401
    user = login(client, 42)['user']
    response = client.post('/api/v1/bot/profile', json={'telegram_id': user['telegram_id']},
                           headers={'X-ROOM0-BOT-SECRET': 's' * 40})
    assert response.status_code == 200 and response.json()['registered'] is True


def test_bot_identify_requires_secret_and_registers(client, monkeypatch) -> None:
    monkeypatch.setattr(settings, 'bot_api_secret', 'b' * 40)
    url = '/api/v1/bot/identify'
    payload = {'telegram_id': 984321, 'first_name': 'Test', 'username': 'testbotuser'}
    assert client.post(url, json=payload).status_code == 401
    response = client.post(url, json=payload, headers={'X-ROOM0-BOT-SECRET': 'b' * 40})
    assert response.status_code == 200 and response.json()['registered'] is True
    assert client.post('/api/v1/auth/telegram', json={'init_data': make_init_data(984321, extra='after-bot')}).status_code == 200


def test_production_settings_reject_demo_and_weak_bot_secret() -> None:
    from pydantic import ValidationError
    from app.core.config import Settings

    with pytest.raises(ValidationError, match='ENABLE_DEMO_MODE'):
        Settings(
            environment='production', jwt_secret_key='j' * 40,
            telegram_bot_token='123456:real-looking-token', telegram_bot_username='room0bot',
            telegram_app_url='https://room0.example.org', bot_api_secret='b' * 40,
            cors_origins=['https://room0.example.org'],
            telegram_allowed_origins=['https://room0.example.org', 'https://web.telegram.org'],
            enable_demo_mode=True,
        )
