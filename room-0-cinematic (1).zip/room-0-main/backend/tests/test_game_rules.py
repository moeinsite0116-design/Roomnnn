from __future__ import annotations

import random
from collections import Counter

import pytest

from app.services.game_service import assign_roles, determine_game_winner, tally_votes


def P(role, alive=True):
    return {'role_name': role, 'is_alive': alive}


def test_detective_victory() -> None:
    players = [P('detective'), P('detective'), P('detective'), P('spy', False), P('spy', False), P('independent')]
    assert determine_game_winner(players) == 'detectives'


def test_spies_win_on_parity() -> None:
    # 2 spies vs 1 detective + 1 independent alive -> spies >= others
    players = [P('spy'), P('spy'), P('detective'), P('independent'), P('detective', False), P('detective', False)]
    assert determine_game_winner(players) == 'spies'


def test_game_continues_when_no_side_has_won() -> None:
    players = [P('spy'), P('spy'), P('detective'), P('detective'), P('detective'), P('independent')]
    assert determine_game_winner(players) is None


def test_independent_only_survivor_without_spies() -> None:
    assert determine_game_winner([P('independent'), P('detective', False), P('spy', False)]) == 'independent'


def test_draw_when_nobody_alive() -> None:
    assert determine_game_winner([P('spy', False), P('detective', False)]) == 'draw'


def test_tally_plurality_and_tie() -> None:
    assert tally_votes({1: 5, 2: 5, 3: 4}) == 5
    assert tally_votes({1: 5, 2: 4}) is None  # tie -> nobody eliminated
    assert tally_votes({}) is None


def test_assign_roles_distribution_and_randomness() -> None:
    ids = [1, 2, 3, 4, 5, 6]
    roles = assign_roles(ids)
    assert Counter(roles.values()) == {'detective': 3, 'spy': 2, 'independent': 1}
    seen = {tuple(assign_roles(ids, random.Random(i)).items()) for i in range(30)}
    assert len(seen) > 5  # not a fixed order any more


def test_assign_roles_requires_six() -> None:
    with pytest.raises(ValueError):
        assign_roles([1, 2, 3])
