"""Concurrent requests through the real ASGI app (one event loop, interleaving at every DB await)."""
from __future__ import annotations

import asyncio

import httpx
from sqlalchemy import text

from app.main import app
from tests.conftest import make_users, seat_all


async def _gather(calls):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url='http://testserver') as ac:
        return await asyncio.gather(*(ac.request(m, url, json=body, headers=h) for m, url, body, h in calls))


def run(calls):
    return asyncio.run(_gather(calls))


def test_concurrent_reservations_of_one_seat(client) -> None:
    users = make_users(client, 6)
    table_id = client.post('/api/v1/tables', json={'name': 'race'}, headers=users[0]['h']).json()['id']
    res = run([('POST', f'/api/v1/tables/{table_id}/reserve', {'seat_index': 3}, u['h']) for u in users])
    assert sorted(r.status_code for r in res) == [201] + [409] * 5


def test_same_user_double_reserve_and_double_start(client) -> None:
    users = make_users(client, 6)
    table_id = client.post('/api/v1/tables', json={'name': 'race'}, headers=users[0]['h']).json()['id']
    res = run([('POST', f'/api/v1/tables/{table_id}/reserve', {}, users[1]['h'])] * 4)
    assert sorted(r.status_code for r in res) == [201, 409, 409, 409]
    client.post(f'/api/v1/tables/{table_id}/cancel', headers=users[1]['h'])
    for u in users:
        client.post(f'/api/v1/tables/{table_id}/reserve', json={}, headers=u['h'])
        client.post(f'/api/v1/tables/{table_id}/confirm', headers=u['h'])
    res = run([('POST', f'/api/v1/tables/{table_id}/start', {}, users[0]['h'])] * 3)
    assert sorted(r.status_code for r in res) == [200, 409, 409]


def test_six_players_act_concurrently_round_resolves_once(client, sync_engine) -> None:
    users = make_users(client, 6)
    table_id = seat_all(client, users)
    game_id = client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).json()['id']

    res = run([('POST', f'/api/v1/games/{game_id}/answer', {'text': 'جواب'}, u['h']) for u in users]
              + [('POST', f'/api/v1/games/{game_id}/answer', {'text': 'دوباره'}, users[0]['h'])])
    assert sorted(r.status_code for r in res) == [200] * 6 + [409]
    assert client.get(f'/api/v1/games/{game_id}', headers=users[0]['h']).json()['phase'] == 'vote'

    target = users[5]['id']
    calls = [('POST', f'/api/v1/games/{game_id}/vote', {'target_user_id': target}, u['h']) for u in users[:5]]
    calls += [('POST', f'/api/v1/games/{game_id}/vote', {'target_user_id': users[0]['id']}, users[5]['h'])]
    calls += [('POST', f'/api/v1/games/{game_id}/vote', {'target_user_id': target}, users[1]['h'])]  # duplicate
    res = run(calls)
    assert sorted(r.status_code for r in res).count(200) == 6
    with sync_engine.begin() as conn:
        resolved = conn.execute(text("SELECT COUNT(*) FROM game_events WHERE game_id = :g AND type = 'round.resolved'"),
                                {'g': game_id}).scalar()
        votes = conn.execute(text('SELECT COUNT(*) FROM game_votes WHERE game_id = :g'), {'g': game_id}).scalar()
        alive = conn.execute(text('SELECT COUNT(*) FROM game_players WHERE game_id = :g AND is_alive = TRUE'),
                             {'g': game_id}).scalar()
    assert resolved == 1 and votes == 6 and alive == 5


def test_concurrent_force_finish_counts_once(client, sync_engine) -> None:
    users = make_users(client, 6)
    table_id = seat_all(client, users)
    game_id = client.post(f'/api/v1/tables/{table_id}/start', json={}, headers=users[0]['h']).json()['id']
    with sync_engine.begin() as conn:
        conn.execute(text("UPDATE users SET role = 'game_admin' WHERE telegram_id = 1000"))
    res = run([('POST', f'/api/v1/games/{game_id}/finish', None, users[0]['h'])] * 4)
    statuses = [r.json()['status'] for r in res]
    assert statuses.count('aborted') == 1 and statuses.count('already_finished') == 3
    with sync_engine.begin() as conn:
        assert conn.execute(text("SELECT COUNT(*) FROM game_events WHERE game_id = :g AND type = 'game.aborted'"),
                            {'g': game_id}).scalar() == 1
        assert conn.execute(text('SELECT SUM(games_played) FROM users')).scalar() == 0
