from __future__ import annotations

from datetime import timedelta

import jwt
import pytest

from app.core.config import settings
from app.core.security import JWT_ALGORITHM, create_access_token, decode_access_token


def test_token_roundtrip() -> None:
    token, _ = create_access_token(5, 'abc')
    payload = decode_access_token(token)
    assert payload['sub'] == '5' and payload['jti'] == 'abc'


def test_expired_token_rejected() -> None:
    token, _ = create_access_token(5, 'abc', timedelta(seconds=-5))
    with pytest.raises(ValueError):
        decode_access_token(token)


def test_token_signed_with_other_key_rejected() -> None:
    forged = jwt.encode({'sub': '1', 'jti': 'x', 'exp': 9999999999}, 'not-the-secret', algorithm=JWT_ALGORITHM)
    with pytest.raises(ValueError):
        decode_access_token(forged)


def test_alg_none_rejected() -> None:
    forged = jwt.encode({'sub': '1', 'jti': 'x', 'exp': 9999999999}, None, algorithm='none')
    with pytest.raises(ValueError):
        decode_access_token(forged)


def test_default_secret_forbidden_in_production() -> None:
    from app.core.config import Settings

    with pytest.raises(ValueError):
        Settings(environment='production', _env_file=None)
