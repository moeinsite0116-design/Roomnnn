# ROOM 0 Architecture

## پلتفرم

- Frontend: React + TypeScript + Vite + Tailwind
- Backend: FastAPI + SQLAlchemy + Pydantic
- Database: PostgreSQL
- Cache: Redis
- Optional voice backend: LiveKit token endpoint موجود است؛ کلاینت صوتی هنوز به Mini App متصل نیست و Permissions-Policy میکروفون را بسته نگه می‌دارد.
- Telegram bot: سرویس polling مستقل، قفل توزیع‌شده Redis، فرمان‌های `/start`, `/menu`, `/help`, `/profile`, `/support`, `/admin`, `/resume`.

## اصول

- وضعیت معتبر تنها در سرور است.
- نقش‌ها فقط برای کاربر مربوطه و سرور قابل مشاهده‌اند.
- احراز هویت بر اساس `Telegram initData` انجام می‌شود.
- API عمومی از داده‌های خصوصی نقش‌ها چشم‌پوشی می‌کند.
- عملیات بازی با قیدهای یکتا و compare-and-set محافظت می‌شوند؛ قفل ردیف میز در PostgreSQL رزرو/شروع/لغو را سریالی می‌کند.
- rate limit درون‌حافظه‌ای و per worker است؛ برای چند backend worker نیاز به limiter توزیع‌شده دارد.
- Bot polling در Redis lock محصور است؛ فقط یک bot service در هر Redis instance اجرا شود.

## قرارداد رویدادها

- `table.created`
- `table.updated`
- `seat.reserved`
- `seat.released`
- `game.started`
- `vote.submitted`
- `game.finished`
- `connection.restored`
