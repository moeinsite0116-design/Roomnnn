# راهنمای استقرار ROOM 0 روی VPS لینوکسی

این راهنما برای Ubuntu 22.04/24.04 یا Debian 12 نوشته شده و همه‌ی دستورها را می‌توان از گوشی اندرویدی هم اجرا کرد (بخش «مدیریت از گوشی» را ببینید). دو روش نصب وجود دارد:

- **روش A — Docker Compose** (پیشنهادی؛ حدود ۲ تا ۳ گیگابایت فضا لازم دارد)
- **روش B — نصب مستقیم با Python، Node.js و systemd** (برای VPS کم‌حجم یا جایی که Docker در دسترس نیست)

> هیچ‌کدام از دستورهای این راهنما داده‌های دیتابیس را پاک نمی‌کنند. هرگز `docker compose down -v` یا `DROP DATABASE` را اجرا نکنید؛ این دو دستور داده‌ها را برای همیشه حذف می‌کنند.

## ۰. پیش‌نیازهای مشترک

1. یک دامنه یا زیردامنه، مثلاً `room0.example.com`، که رکورد DNS از نوع A آن به IP سرور اشاره کند.
2. پورت‌های 80 و 443 روی سرور باز باشند (`sudo ufw allow 80,443/tcp` و `sudo ufw allow OpenSSH`).
3. یک ربات تلگرام که از طریق @BotFather ساخته‌اید، به‌همراه توکنش.
4. در @BotFather با دستور `/newapp` یا Bot Settings → Menu Button، آدرس `https://room0.example.com` را به‌عنوان Mini App ربات ثبت کنید. ورود کاربران فقط از داخل تلگرام انجام می‌شود، چون سرور امضای `initData` تلگرام را بررسی می‌کند.

سورس پروژه را به سرور منتقل کنید (با `scp`، `git clone` یا آپلود ZIP):

```bash
sudo mkdir -p /opt/room0 && sudo chown $USER /opt/room0
cd /opt/room0 && unzip ~/room-0-final.zip -d . # یا git clone ...
cp .env.example .env && chmod 600 .env
nano .env
```

### متغیرهای ضروری `.env`

| متغیر | توضیح |
|---|---|
| `ENVIRONMENT=production` | در این حالت برنامه با secret ضعیف یا `DEBUG=true` اصلاً اجرا نمی‌شود. |
| `DOMAIN` | دامنه‌ی سایت (در روش Docker، Caddy گواهی HTTPS آن را خودکار می‌گیرد). |
| `JWT_SECRET_KEY` | حداقل ۳۲ کاراکتر تصادفی: `python3 -c "import secrets;print(secrets.token_urlsafe(48))"` |
| `BOT_TOKEN` | توکن واقعی @BotFather؛ هم برای bot service و هم بررسی امضای initData. |
| `BOT_USERNAME` | نام کاربری بدون @؛ برای دکمهٔ بازگشت از مرورگر. |
| `TELEGRAM_APP_URL` | URL یکتای HTTPS Mini App، همان آدرسی که در BotFather ثبت می‌شود. |
| `BOT_API_SECRET` | مقدار تصادفی حداقل ۳۲ کاراکتر برای ارتباط داخلی bot/backend. |
| `ADMIN_IDS` | شناسه‌های عددی مدیران کل؛ همان شناسه‌ها در Mini App مجوز super admin می‌گیرند. |
| `POSTGRES_PASSWORD` | رمز دیتابیس؛ برای Compose مقدار hex تولید کنید تا داخل URL اتصال نیاز به escape نداشته باشد: `openssl rand -hex 32`. |
| `CORS_ORIGINS` و `TELEGRAM_ALLOWED_ORIGINS` | آدرس سایت، مثل `https://room0.example.com`. مقدار `https://web.telegram.org` را هم در دومی نگه دارید. |

| `DATABASE_URL` و `REDIS_URL` | فقط در روش B لازم‌اند؛ در Docker به‌طور خودکار ساخته می‌شوند. |

بقیه‌ی متغیرها مقدار پیش‌فرض مناسب دارند و توضیح هرکدام در `.env.example` آمده است.

## روش A — Docker Compose

```bash
# نصب Docker (یک‌بار)
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER && newgrp docker

cd /opt/room0
docker compose -f docker-compose.prod.yml up -d --build
docker compose -f docker-compose.prod.yml ps        # همه باید Up/healthy باشند
curl -s https://room0.example.com/api/v1/ready       # {"status":"ready","database":true,"redis":true}
```

- migrationها هر بار که بک‌اند بالا می‌آید، خودکار اجرا می‌شوند (`alembic upgrade head`). این دستور فقط تغییرات جدید را اعمال می‌کند و داده‌ای را حذف نمی‌کند.
- ربات از polling استفاده می‌کند، نه webhook؛ قفل Redis توزیع‌شده فقط یک نمونه را فعال نگه می‌دارد و برای شروع `/start` را به ربات بفرستید. نام کاربری و URL Mini App باید در BotFather با `BOT_USERNAME` و `TELEGRAM_APP_URL` هماهنگ باشند.
- همه‌ی سرویس‌ها `restart: unless-stopped` دارند، پس بعد از ری‌استارت سرور خودکار بالا می‌آیند. سرویس Docker هم به‌طور پیش‌فرض enable است (`sudo systemctl enable docker`).
- PostgreSQL و Redis هیچ پورتی را بیرون از سرور باز نمی‌کنند و فقط Caddy روی پورت‌های 80 و 443 در دسترس است.

| کار | دستور |
|---|---|
| لاگ زنده | `docker compose -f docker-compose.prod.yml logs -f --tail=100 backend bot` |
| توقف | `docker compose -f docker-compose.prod.yml stop` |
| اجرای دوباره | `docker compose -f docker-compose.prod.yml start` |
| ری‌استارت بک‌اند | `docker compose -f docker-compose.prod.yml restart backend` |
| به‌روزرسانی | فایل‌های جدید را جایگزین کنید (`.env` را نگه دارید)، بعد: `./scripts/backup.sh` (با `BACKUP_MODE=docker`) و `docker compose -f docker-compose.prod.yml up -d --build` |
| ساخت مدیر بدون env | `docker compose -f docker-compose.prod.yml exec backend python /app/scripts/create_admin.py <telegram_id>` |
| وضعیت migration | `docker compose -f docker-compose.prod.yml exec backend alembic current` |

## روش B — نصب مستقیم (بدون Docker)

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip postgresql redis-server caddy curl unzip
# Node 20 فقط برای build فرانت‌اند لازم است:
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs
```

> اگر Python نصب‌شده روی سرور قدیمی‌تر از 3.11 است، نسخه‌ی 3.12 را نصب کنید. یک راه ساده: `curl -LsSf https://astral.sh/uv/install.sh | sh` و بعد `uv venv --python 3.12 /opt/room0/.venv`.

```bash
# کاربر سیستمی و دیتابیس
sudo useradd --system --home /opt/room0 --shell /usr/sbin/nologin room0
sudo -u postgres psql -c "CREATE USER room0 WITH PASSWORD 'رمز-قوی';"
sudo -u postgres psql -c "CREATE DATABASE room0 OWNER room0;"
# در .env:  DATABASE_URL=postgresql+psycopg://room0:رمز-قوی@127.0.0.1:5432/room0

# بک‌اند
cd /opt/room0
python3 -m venv .venv
.venv/bin/pip install -r backend/requirements.txt
cd backend && set -a && . ../.env && set +a && ../.venv/bin/alembic upgrade head && cd ..

# فرانت‌اند (خروجی استاتیک در frontend/dist)
cd frontend && npm ci && npm run build && cd ..

sudo chown -R room0:room0 /opt/room0

# سرویس systemd (با ری‌استارت سرور خودکار بالا می‌آید و اگر خطا بدهد دوباره اجرا می‌شود)
sudo cp deploy/systemd/room0-backend.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now room0-backend

# Caddy برای HTTPS و reverse proxy
sudo cp deploy/Caddyfile.direct /etc/caddy/Caddyfile
sudo sed -i 's/room0.example.com/دامنه-شما/' /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

| کار | دستور |
|---|---|
| وضعیت | `systemctl status room0-backend` |
| لاگ زنده | `journalctl -u room0-backend -f` |
| لاگ Caddy | `journalctl -u caddy -f` |
| توقف / اجرا / ری‌استارت | `sudo systemctl stop/start/restart room0-backend` |
| به‌روزرسانی | `./scripts/backup.sh` ← جایگزینی فایل‌ها ← `.venv/bin/pip install -r backend/requirements.txt` ← `cd frontend && npm ci && npm run build` ← `sudo systemctl restart room0-backend` (migration در `ExecStartPre` اجرا می‌شود) |

برای اجرای بیش از یک worker، مقدار `REALTIME_USE_REDIS=true` را تنظیم کنید و `--workers` را در فایل سرویس افزایش دهید.

## پشتیبان‌گیری و بازیابی

```bash
./scripts/backup.sh                      # روش B
BACKUP_MODE=docker ./scripts/backup.sh   # روش A
# خروجی: backups/room0-YYYYmmdd-HHMMSS.sql.gz و لینک backups/latest.sql.gz؛ نسخه‌های قدیمی‌تر از KEEP_DAYS روز حذف می‌شوند
```

پشتیبان خودکار روزانه با cron (`crontab -e`):

```
30 3 * * * cd /opt/room0 && BACKUP_MODE=docker ./scripts/backup.sh >> /opt/room0/backups/backup.log 2>&1
```

بازیابی (قبل از جایگزینی، اسکریپت خودش یک پشتیبان ایمنی از وضعیت فعلی می‌گیرد و از شما تأیید می‌خواهد):

```bash
BACKUP_MODE=docker ./scripts/restore.sh backups/room0-20261024-030000.sql.gz
```

فایل‌های پشتیبان را مرتب به جای دیگری هم منتقل کنید، مثلاً با `scp` به کامپیوتر یا گوشی خودتان.

## مدیریت از گوشی اندرویدی

1. اپ **Termux** را نصب کنید (نسخه‌ی F-Droid) و این دستورها را بزنید: `pkg install openssh` و `ssh user@IP-سرور`. اپ‌های JuiceSSH یا ConnectBot هم کار می‌کنند.
2. برای ورود با کلید: `ssh-keygen` و بعد `ssh-copy-id user@IP`.
3. همه‌ی دستورهای جدول‌های بالا کوتاه‌اند و از گوشی قابل اجرا هستند. برای اینکه کار با قطع اینترنت گوشی نیمه‌کاره نماند، `tmux` را نصب کنید (`sudo apt install tmux`) و دستورهای طولانی مثل build را داخل `tmux` اجرا کنید.
4. برای ویرایش `.env` از `nano .env` استفاده کنید (ذخیره با Ctrl+O و خروج با Ctrl+X).

## عیب‌یابی

| نشانه | بررسی |
|---|---|
| سایت باز نمی‌شود | `dig +short دامنه` باید IP سرور را برگرداند. باز بودن پورت‌های 80 و 443 را چک کنید و لاگ caddy را ببینید (گرفتن گواهی HTTPS ممکن است یک دقیقه طول بکشد). |
| `ready` مقدار `database:false` یا `realtime_listener:false` برمی‌گرداند | PostgreSQL/Redis و اتصال subscriber ریل‌تایم را بررسی کنید. |
| `ready` مقدار `database:false` برمی‌گرداند | PostgreSQL را بررسی کنید (`docker compose ... logs postgres` یا `systemctl status postgresql`) و مقدار `DATABASE_URL` و رمز را چک کنید. |
| بک‌اند اجرا نمی‌شود و پیام `Refusing to start in production` می‌دهد | `JWT_SECRET_KEY` حداقل ۳۲ کاراکتر باشد، `BOT_TOKEN` واقعی باشد، `BOT_API_SECRET` حداقل ۳۲ کاراکتر و `ENABLE_DEMO_MODE=false` باشد و `DEBUG=false` باشد. |
| «ورود با تلگرام ناموفق بود» | `BOT_TOKEN` باید مال همان رباتی باشد که Mini App را باز می‌کند. ساعت سرور را با `timedatectl` چک کنید. initData قدیمی‌تر از `INIT_DATA_MAX_AGE_SECONDS` ثانیه رد می‌شود. |
| اتصال زنده («در حال اتصال مجدد») | Origin سایت باید در `TELEGRAM_ALLOWED_ORIGINS` باشد. اگر پروکسی دیگری جلوی Caddy قرار دارد، باید WebSocket را عبور دهد. |
| خطای 429 | محدودیت `RATE_LIMIT_PER_MINUTE` اعمال شده است. پشت پروکسی، `--proxy-headers` باید فعال باشد (به‌طور پیش‌فرض فعال است). |
| ربات پاسخ نمی‌دهد | `docker compose -f docker-compose.prod.yml logs --tail=100 bot` را بررسی کنید؛ توکن، username، Redis و آدرس backend باید درست باشند. فقط یک نمونهٔ bot را scale کنید. |
| خطاهای اخیر | پنل مدیریت ← «وضعیت سرویس» آخرین خطاها را نشان می‌دهد؛ توکن‌ها و initData قبل از نمایش پاک می‌شوند. |


## سرویس ربات تلگرام

در Docker Compose ربات یک سرویس مستقل polling است. برای آن webhook تنظیم نکنید و سرویس را به بیش از یک replica افزایش ندهید؛ قفل Redis بین نسخه‌های یکسان از برنامه از polling هم‌زمان جلوگیری می‌کند. `/start` با API داخلی ثبت/به‌روزرسانی حداقلی پروفایل می‌کند، اما مجوز و ورود به بازی همچنان بر اساس `initData` امضاشده و نشست بک‌اند است. `/profile` از بک‌اند آمار همان شناسهٔ تلگرام را می‌گیرد و `/admin` فقط دکمهٔ پنل را به مدیر شناخته‌شده نشان می‌دهد؛ endpointهای مدیریت در خود backend مجوز را دوباره بررسی می‌کنند.

برای نصب مستقیم (بدون Compose)، وابستگی‌های `bot/requirements.txt` را در venv جدا نصب کنید و کاربر سیستم `room0` را بسازید. فایل bot env را حاوی فقط envهای نام‌برده بسازید. سرویس نمونهٔ systemd در `deploy/systemd/room0-bot.service` قرار دارد. به‌جای `.env` برنامه، فایل محدودشدهٔ `/etc/room0/bot.env` بسازید و فقط `BOT_TOKEN`، `BOT_USERNAME`، `TELEGRAM_APP_URL`، `BOT_API_SECRET`، `REDIS_URL`، `SUPPORT_URL` و `LOG_LEVEL` را در آن بنویسید; مجوزش را `chmod 600` کنید. `BOT_API_SECRET` باید با مقدار backend یکی باشد و در لاگ یا مخزن قرار نگیرد.

## نسخهٔ سینمایی (بازجویی + پرونده + تخته)
- migration جدید `20261026_investigation` فقط جدول/ستون اضافه می‌کند و با بالا آمدن بک‌اند خودکار اجرا می‌شود.
- نصب پروندهٔ «آرشیو خاموش» (idempotent با slug): `scripts/seed_case.py` — python scripts/seed_case.py                       # bundled «آرشیو خاموش» case
- متغیرهای جدید: `INTERROGATION_QUESTIONS_DEFAULT`، `INTERROGATION_SECONDS`، `BRIEFING_SECONDS`؛ `SENSITIVE_RATE_LIMIT_PER_MINUTE` پیش‌فرض ۹۰.
