from __future__ import annotations

import asyncio
import logging
import os
import signal
import time
from pathlib import Path
from dataclasses import dataclass
from urllib.parse import urlsplit

import httpx
import redis.asyncio as redis
from telegram import (BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, MenuButtonWebApp, Update, WebAppInfo)
from telegram.ext import (Application, ApplicationBuilder, ApplicationHandlerStop, CommandHandler, ContextTypes, TypeHandler)

logging.basicConfig(level=os.getenv('LOG_LEVEL', 'INFO').upper(), format='%(asctime)s %(levelname)s %(name)s: %(message)s')
logging.getLogger('httpx').setLevel(logging.WARNING)
logging.getLogger('telegram').setLevel(logging.WARNING)
logger = logging.getLogger('room0.bot')


@dataclass(frozen=True)
class Config:
    token: str
    app_url: str
    username: str
    api_url: str
    api_secret: str
    redis_url: str
    support_url: str

    @classmethod
    def from_env(cls) -> 'Config':
        cfg = cls(
            token=os.getenv('BOT_TOKEN', '').strip(),
            app_url=os.getenv('TELEGRAM_APP_URL', '').strip().rstrip('/'),
            username=os.getenv('BOT_USERNAME', '').strip().lstrip('@'),
            api_url=os.getenv('BOT_API_BASE_URL', 'http://backend:8000').strip().rstrip('/'),
            api_secret=os.getenv('BOT_API_SECRET', '').strip(),
            redis_url=os.getenv('REDIS_URL', 'redis://redis:6379/0').strip(),
            support_url=os.getenv('SUPPORT_URL', '').strip(),
        )
        parsed = urlsplit(cfg.app_url)
        if not cfg.token:
            raise ValueError('BOT_TOKEN is required')
        if parsed.scheme != 'https' or not parsed.netloc or parsed.username or parsed.password:
            raise ValueError('TELEGRAM_APP_URL must be an HTTPS URL')
        if not cfg.api_secret or len(cfg.api_secret) < 32:
            raise ValueError('BOT_API_SECRET must be at least 32 characters')
        if not cfg.username:
            raise ValueError('BOT_USERNAME is required')
        return cfg


def app_keyboard(cfg: Config, *, admin: bool = False) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton('🎮 ورود به ROOM 0', web_app=WebAppInfo(url=cfg.app_url))]]
    if admin:
        rows.append([InlineKeyboardButton('🛠 پنل مدیریت', web_app=WebAppInfo(url=cfg.app_url))])
    return InlineKeyboardMarkup(rows)


async def _backend_call(cfg: Config, route: str, payload: dict) -> dict:
    timeout = httpx.Timeout(5.0, connect=3.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(
            f'{cfg.api_url}/api/v1/bot/{route}',
            json=payload,
            headers={'X-ROOM0-BOT-SECRET': cfg.api_secret},
        )
    if response.status_code != 200:
        raise RuntimeError('profile lookup failed')
    data = response.json()
    if not isinstance(data, dict):
        raise RuntimeError('invalid profile response')
    return data


def _config(context: ContextTypes.DEFAULT_TYPE) -> Config:
    return context.application.bot_data['config']


async def deduplicate_update(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Use Redis to suppress Telegram redelivery after process restart."""
    update_id = getattr(update, 'update_id', None)
    redis_client = context.application.bot_data.get('redis')
    if update_id is None or redis_client is None:
        raise RuntimeError('Telegram update deduplication is not configured')
    inserted = await redis_client.set(f'room0:telegram:update:{update_id}', '1', nx=True, ex=7 * 24 * 60 * 60)
    if not inserted:
        logger.info('duplicate Telegram update suppressed')
        raise ApplicationHandlerStop


async def _private_only(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    if update.effective_chat and update.effective_chat.type == 'private':
        return True
    cfg = _config(context)
    await update.effective_message.reply_text(f'برای استفاده از ROOM 0، در پیام خصوصی به @{cfg.username} پیام بده.')
    return False


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _private_only(update, context):
        return
    cfg = _config(context)
    user = update.effective_user
    try:
        identification = await _backend_call(cfg, 'identify', {
            'telegram_id': user.id, 'username': user.username,
            'first_name': user.first_name, 'last_name': user.last_name,
        })
        if identification.get('banned'):
            await update.effective_message.reply_text('حساب شما مسدود شده است. برای پیگیری با پشتیبانی تماس بگیرید.')
            return
    except Exception as exc:
        logger.warning('start identity lookup failed (%s)', type(exc).__name__)
    text = (
        'به ROOM 0 خوش آمدی. بازی، ساخت میز و رأی‌گیری داخل Mini App انجام می‌شود. '
        'برای ورود امن و شروع بازی، دکمهٔ زیر را بزن.'
    )
    await update.effective_message.reply_text(text, reply_markup=app_keyboard(cfg))


async def resume(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _private_only(update, context):
        return
    await update.effective_message.reply_text('برای برگشت به میز یا بازی قبلی، Mini App را دوباره باز کن:', reply_markup=app_keyboard(_config(context)))


async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _private_only(update, context):
        return
    await update.effective_message.reply_text('منوی اصلی ROOM 0:', reply_markup=app_keyboard(_config(context)))


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        'راهنمای سریع ROOM 0:\n'
        '۱) «ورود به ROOM 0» را بزن.\n'
        '۲) داخل Mini App میز بساز یا به میز دیگری بپیوند.\n'
        '۳) نقش و بازی فقط داخل Mini App نمایش داده می‌شود.\n\n'
        'فرمان‌ها: /start، /menu، /resume، /help، /profile، /support، /admin'
    )


async def profile(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _private_only(update, context):
        return
    cfg = _config(context)
    user = update.effective_user
    try:
        data = await _backend_call(cfg, 'profile', {'telegram_id': user.id})
    except Exception as exc:
        logger.warning('profile command failed (%s)', type(exc).__name__)
        await update.effective_message.reply_text('الان نتونستم پروفایلت را از سرور بگیرم. کمی بعد دوباره بزن.')
        return
    if not data.get('registered'):
        await update.effective_message.reply_text(
            'پروفایلت هنوز ساخته نشده. یک‌بار از دکمهٔ زیر وارد Mini App شو.',
            reply_markup=app_keyboard(cfg),
        )
        return
    name = str(data.get('display_name') or data.get('first_name') or user.first_name or 'بازیکن')[:64]
    await update.effective_message.reply_text(
        f'پروفایل {name}\nبازی‌ها: {int(data.get("games_played", 0))}\n'
        f'بردها: {int(data.get("games_won", 0))}\nنقش: {data.get("role", "player")}'
    )


async def support(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    cfg = _config(context)
    text = 'برای راهنمایی از /help استفاده کن.'
    if cfg.support_url:
        text += f'\nارتباط با پشتیبانی: {cfg.support_url}'
    await update.effective_message.reply_text(text)


async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _private_only(update, context):
        return
    cfg = _config(context)
    try:
        data = await _backend_call(cfg, 'profile', {'telegram_id': update.effective_user.id})
    except Exception as exc:
        logger.warning('admin command failed (%s)', type(exc).__name__)
        await update.effective_message.reply_text('بررسی مجوز مدیریت فعلاً ممکن نیست؛ کمی بعد دوباره تلاش کن.')
        return
    if data.get('banned') or not data.get('registered') or data.get('role') not in {
        'analyst', 'support', 'moderator', 'game_admin', 'super_admin'
    }:
        await update.effective_message.reply_text('این فرمان فقط برای مدیران مجاز است.')
        return
    await update.effective_message.reply_text(
        'پنل مدیریت فقط پس از احراز هویت و بررسی مجوز سمت سرور باز می‌شود.',
        reply_markup=app_keyboard(cfg, admin=True),
    )


async def configure_bot(application: Application, cfg: Config) -> None:
    await application.bot.set_my_commands([
        BotCommand('start', 'ورود به ROOM 0'), BotCommand('menu', 'منوی اصلی'),
        BotCommand('resume', 'بازگشت به بازی'), BotCommand('help', 'راهنمای استفاده'),
        BotCommand('profile', 'پروفایل و آمار'), BotCommand('support', 'پشتیبانی'),
        BotCommand('admin', 'پنل مدیریت'),
    ])
    await application.bot.set_chat_menu_button(
        menu_button=MenuButtonWebApp(text='ورود به بازی', web_app=WebAppInfo(url=cfg.app_url))
    )


async def configure_bot_with_retry(
    application: Application,
    cfg: Config,
    *,
    attempts: int = 5,
    initial_delay_seconds: float = 2.0,
) -> None:
    """Configure Telegram commands/menu before polling, retrying transient Bot API failures."""
    if attempts < 1:
        raise ValueError('attempts must be at least one')
    delay = initial_delay_seconds
    for attempt in range(1, attempts + 1):
        try:
            await configure_bot(application, cfg)
            logger.info('Telegram commands and Mini App menu configured')
            return
        except Exception as exc:
            logger.warning(
                'Telegram menu setup failed on attempt %s/%s (%s)',
                attempt, attempts, type(exc).__name__,
            )
            if attempt == attempts:
                raise RuntimeError(
                    f'Telegram Bot API setup failed after {attempts} attempts; service will restart and retry'
                ) from None
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30.0)


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Do not log exception text: third-party API exceptions may contain the bot token in request URLs.
    logger.error('Telegram update failed (%s)', type(context.error).__name__ if context.error else 'unknown')


def build_application(cfg: Config) -> Application:
    application: Application = ApplicationBuilder().token(cfg.token).build()
    application.bot_data['config'] = cfg
    application.add_handler(TypeHandler(Update, deduplicate_update), group=-1)
    for command, handler in (
        ('start', start), ('menu', menu), ('resume', resume), ('help', help_command),
        ('profile', profile), ('support', support), ('admin', admin),
    ):
        application.add_handler(CommandHandler(command, handler))
    application.add_error_handler(on_error)
    return application


async def run() -> None:
    cfg = Config.from_env()
    app = build_application(cfg)
    client = redis.from_url(cfg.redis_url, decode_responses=True, socket_connect_timeout=5, socket_timeout=5)
    app.bot_data['redis'] = client
    lock = client.lock('room0:telegram-polling-lock', timeout=60, blocking=False)
    try:
        acquired = await lock.acquire()
    except Exception as exc:
        await client.aclose()
        logger.critical('Redis polling lock unavailable (%s); bot will restart and retry', type(exc).__name__)
        raise RuntimeError('could not acquire Telegram polling lock') from None
    if not acquired:
        await client.aclose()
        raise RuntimeError('another Telegram polling instance already owns the lock')

    health_file = Path(os.getenv('BOT_HEALTH_FILE', '/tmp/room0-bot-health'))
    health_file.unlink(missing_ok=True)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:
            pass

    async def renew_lock() -> None:
        while not stop.is_set():
            try:
                await asyncio.wait_for(stop.wait(), timeout=15)
            except asyncio.TimeoutError:
                if not await lock.extend(60, replace_ttl=True):
                    raise RuntimeError('Telegram polling lock was lost')
                health_file.write_text(str(time.time()), encoding='ascii')

    renewal: asyncio.Task | None = None
    initialized = False
    try:
        await app.initialize()
        initialized = True
        try:
            bot_identity = await app.bot.get_me()
        except Exception as exc:
            logger.critical('Telegram Bot API identity check failed (%s); bot will restart and retry', type(exc).__name__)
            raise RuntimeError('Telegram Bot API identity check failed') from None
        if not bot_identity.username or bot_identity.username.casefold() != cfg.username.casefold():
            logger.critical('Configured BOT_USERNAME does not match the identity returned by Telegram')
            raise ValueError('BOT_USERNAME does not match BOT_TOKEN')
        await configure_bot_with_retry(app, cfg)
        await app.start()
        if app.updater is None:
            raise RuntimeError('Telegram updater is unavailable')
        try:
            await app.updater.start_polling(
                drop_pending_updates=False, allowed_updates=Update.ALL_TYPES, bootstrap_retries=5,
            )
        except Exception as exc:
            logger.critical('Telegram polling could not start (%s); bot will restart and retry', type(exc).__name__)
            raise RuntimeError('Telegram polling startup failed') from None
        logger.info('Telegram bot started in polling mode')
        health_file.write_text(str(time.time()), encoding='ascii')
        renewal = asyncio.create_task(renew_lock())
        stop_task = asyncio.create_task(stop.wait())
        done, pending = await asyncio.wait({stop_task, renewal}, return_when=asyncio.FIRST_COMPLETED)
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        for task in done:
            error = task.exception()
            if error:
                raise error
    finally:
        health_file.unlink(missing_ok=True)
        if renewal:
            renewal.cancel()
            await asyncio.gather(renewal, return_exceptions=True)
        try:
            if app.updater and app.updater.running:
                await app.updater.stop()
            if app.running:
                await app.stop()
        finally:
            try:
                if initialized:
                    await app.shutdown()
            finally:
                try:
                    if lock.owned():
                        await lock.release()
                finally:
                    await client.aclose()


def main() -> None:
    try:
        asyncio.run(run())
    except Exception as exc:
        # No exception string, to avoid accidental URL/token disclosure.
        logger.critical('Bot stopped (%s)', type(exc).__name__)
        raise SystemExit(1) from None


if __name__ == '__main__':
    main()
