from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest
from telegram import InlineKeyboardMarkup

from bot.main import (Config, app_keyboard, build_application, configure_bot, configure_bot_with_retry, deduplicate_update, start)


@pytest.fixture
def config() -> Config:
    return Config(
        token='123456:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890',
        app_url='https://room0.example.org', username='room0bot',
        api_url='http://backend:8000', api_secret='s' * 40,
        redis_url='redis://redis:6379/0', support_url='',
    )


def test_keyboard_opens_https_mini_app(config: Config) -> None:
    markup = app_keyboard(config)
    assert isinstance(markup, InlineKeyboardMarkup)
    button = markup.inline_keyboard[0][0]
    assert button.web_app.url == 'https://room0.example.org'


def test_admin_keyboard_has_same_secure_destination(config: Config) -> None:
    markup = app_keyboard(config, admin=True)
    assert len(markup.inline_keyboard) == 2
    assert all(row[0].web_app.url == config.app_url for row in markup.inline_keyboard)


def test_start_command_sends_mini_app_button(config: Config, monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, object]] = []

    async def backend_call(_cfg, route, payload):
        assert route == 'identify'
        assert payload['telegram_id'] == 42
        return {'registered': True, 'banned': False}

    async def reply_text(text, reply_markup=None):
        calls.append((text, reply_markup))

    monkeypatch.setattr('bot.main._backend_call', backend_call)
    update = SimpleNamespace(
        effective_user=SimpleNamespace(id=42, username='yasin', first_name='Yasin', last_name=None),
        effective_chat=SimpleNamespace(type='private'),
        effective_message=SimpleNamespace(reply_text=reply_text),
    )
    context = SimpleNamespace(application=SimpleNamespace(bot_data={'config': config}))
    asyncio.run(start(update, context))
    assert len(calls) == 1
    assert calls[0][1].inline_keyboard[0][0].web_app.url == config.app_url
    assert 'Mini App' in calls[0][0]


def test_command_handlers_are_registered_without_running_network(config: Config) -> None:
    app = build_application(config)
    commands = {handler.command for handlers in app.handlers.values() for handler in handlers
                if hasattr(handler, 'command')}
    assert {'start', 'menu', 'resume', 'help', 'profile', 'support', 'admin'} <= commands


class FakeBot:
    def __init__(self, fail_menu: bool = False):
        self.commands = None
        self.menu_button = None
        self.fail_menu = fail_menu
        self.menu_calls = 0

    async def set_my_commands(self, commands):
        self.commands = commands

    async def set_chat_menu_button(self, *, menu_button):
        self.menu_calls += 1
        if self.fail_menu:
            raise RuntimeError('simulated Telegram API error')
        self.menu_button = menu_button


def test_configure_bot_success_uses_explicit_config(config: Config) -> None:
    fake_bot = FakeBot()
    asyncio.run(configure_bot(SimpleNamespace(bot=fake_bot), config))
    assert len(fake_bot.commands) == 7
    assert fake_bot.menu_button.web_app.url == config.app_url


def test_configure_bot_failure_is_reported_and_retryable(config: Config, caplog) -> None:
    fake_bot = FakeBot(fail_menu=True)
    async def exercise():
        with pytest.raises(RuntimeError, match='after 2 attempts'):
            await configure_bot_with_retry(
                SimpleNamespace(bot=fake_bot), config, attempts=2, initial_delay_seconds=0,
            )
    asyncio.run(exercise())
    assert fake_bot.menu_calls == 2
    assert 'Telegram menu setup failed on attempt 2/2' in caplog.text


def test_configure_bot_retry_recovers(config: Config) -> None:
    class EventuallyWorks(FakeBot):
        async def set_chat_menu_button(self, *, menu_button):
            self.menu_calls += 1
            if self.menu_calls == 1:
                raise RuntimeError('temporary failure')
            self.menu_button = menu_button

    fake_bot = EventuallyWorks()
    asyncio.run(configure_bot_with_retry(SimpleNamespace(bot=fake_bot), config, attempts=2, initial_delay_seconds=0))
    assert fake_bot.menu_button.web_app.url == config.app_url
    assert fake_bot.menu_calls == 2


def test_config_from_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    values = {
        'BOT_TOKEN': '123456:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890',
        'TELEGRAM_APP_URL': 'https://room0.example.org',
        'BOT_USERNAME': '@room0bot',
        'BOT_API_SECRET': 's' * 40,
    }
    for key, value in values.items():
        monkeypatch.setenv(key, value)
    config = Config.from_env()
    assert config.app_url == 'https://room0.example.org'
    assert config.username == 'room0bot'


def test_config_rejects_non_https_app_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv('BOT_TOKEN', '123456:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890')
    monkeypatch.setenv('TELEGRAM_APP_URL', 'http://room0.example.org')
    monkeypatch.setenv('BOT_USERNAME', 'room0bot')
    monkeypatch.setenv('BOT_API_SECRET', 's' * 40)
    with pytest.raises(ValueError, match='HTTPS'):
        Config.from_env()


def test_duplicate_update_is_stopped_by_redis() -> None:
    class FakeRedis:
        async def set(self, key, value, *, nx, ex):
            assert key == 'room0:telegram:update:88'
            assert value == '1' and nx is True and ex > 0
            return None

    async def exercise():
        with pytest.raises(Exception) as exc:
            await deduplicate_update(
                SimpleNamespace(update_id=88),
                SimpleNamespace(application=SimpleNamespace(bot_data={'redis': FakeRedis()})),
            )
        from telegram.ext import ApplicationHandlerStop
        assert isinstance(exc.value, ApplicationHandlerStop)

    asyncio.run(exercise())
