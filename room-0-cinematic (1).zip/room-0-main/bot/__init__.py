"""ROOM 0 Telegram polling bot."""
